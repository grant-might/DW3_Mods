# Major footstep reduction mod - install and relink

This package makes the player's own footstep sound 50% quieter (half its
normal volume) and changes nothing else.

## What it changes

Only the player's own footstep sound. The footstep is `SOUND_PLAYER00`
(sound id `0x8004583C`), played by `FIELDSTG_playStepSounds()` in the game's
field code (`src/fieldstg/actor_control.c`) every 8 frames while the player
moves. The game passes **no volume and no pan** when it plays it - every
key-on sound goes through `playSound()` at the engine ceiling - so the only
thing that sets its loudness is the SPU voice mix volume the game writes for
that one tone just before it keys the voice on.

The plugin asks the runtime's own SPU mixer to scale that one sample's voice
volume to 50/100. The
scale is applied at the instant of KEYON, so it is exact from the first output
sample, and it is applied only to the voice whose ADPCM start address is the
footstep's. Nothing else in the mix is touched.

- Measured footstep start address (both discs): SPU byte address `0x27400`
  (start-address register 3 = `0x4E80`), voice volume registers written by the
  game as `0x1D3E` left and right, one-shot VAG body of 16 bytes.
- The mixer hook lives in `runtime/src/spu.c` (`spu_set_sample_volume_scale`,
  declared in `runtime/include/spu.h`). It is inert unless a plugin arms it,
  so a build that compiles it in but enables no footstep package is stock.

## Steps (per disc, in the launcher's terms)

1. **Load mod package** -> pick `dev.footstep-major-1.0.0.zip` -> **Install**.
   The archive's root holds
   `manifest.toml`; the installer unpacks it to
   `mods/packages/<id>/1.0.0/`.
2. **Relink** - this package ships a `[[plugin]]`, so its code must be
   compiled into the runtime for the selected region (there is no dynamic mod
   loader; a package whose plugin id is not linked in makes the runtime refuse
   to launch). Add the plugin source to the region's build, once:
   - Europe (`D:\AGENT\DMW3-Recomp-OURS\modbuild\CMakeLists.txt`):
     ```
     target_sources(psx-runtime PRIVATE
       "${CMAKE_CURRENT_SOURCE_DIR}/mods_src/step_duck.c")
     ```
     (the file is `modbuild/mods_src/step_duck.c`; the build already defines
     `DW3_GAME_REGION_EU`)
   - USA (`D:\AGENT\DMW3-Recomp-USA\CMakeLists.txt`):
     ```
     target_sources(psx-runtime PRIVATE
       "${CMAKE_CURRENT_SOURCE_DIR}/mods_src/step_duck.c")
     ```
     (the file is `mods_src/step_duck.c`; the build already defines
     `DW3_GAME_REGION_US`)
   Then **Rebuild (EUR)** / **Rebuild (USA)**.
3. **Enable the feature**:
   ```toml
   # mods/state.toml (format_version = 2)
   [[package]]
   id = "dev.footstep-major"
   version = "1.0.0"

   [[feature]]
   package_id = "dev.footstep-major"
   id = "footstep"
   enabled = true
   ```
4. **Play**. With the feature disabled (or with the package uninstalled)
   the mixer is byte-for-byte stock.

## Region note

The footstep VAG body sits at the same SPU address on both discs (`0x27400`),
so one source serves both. The plugin is compiled per region
(`DW3_GAME_REGION_EU` / `DW3_GAME_REGION_US`); a missing define is a compile
error, so a wrong-region binary cannot be produced by accident.
