# Fast Travel (dev.warp-tool 1.0.1) - install notes

The package is a ZIP with `manifest.toml` at the archive root. That is the
container the runtime's installer accepts (`ModPackageManager::install_archive`):
it finds `manifest.toml` at the root, unpacks the whole archive, reads the
manifest, and publishes it to `<mods>/packages/<id>/<version>/`.

## 1. Where the files go

With the executable in `EXE_DIR` (its mods folder is `EXE_DIR/mods`), the
archive root maps onto

    EXE_DIR/mods/packages/dev.warp-tool/1.0.1/

so after install you have

    EXE_DIR/mods/packages/dev.warp-tool/1.0.1/manifest.toml
    EXE_DIR/mods/packages/dev.warp-tool/1.0.1/plugin/warp_tool.c
    EXE_DIR/mods/packages/dev.warp-tool/1.0.1/INSTALL.md

The extra files are inert. The runtime reads `manifest.toml` only. They travel
with the package so it is self-contained for the code step below.

The installer refuses a package/version directory that already exists. Remove
the old directory first, or install a newer version.

## 2. The code step (this mod is a compiled plugin)

Fast Travel is a plugin: native code registered by a constructor inside the
runtime executable (`PSX_MOD_CONSTRUCTOR` in `plugin/warp_tool.c`). The
manifest's `[[plugin]]` block is only an id reference. The runtime does not load
a binary out of the package. Installing the ZIP alone does not create the mod's
behaviour. The plugin has to be linked into the target build.

The launcher automates this step. Done by hand it is:

1. Copy `plugin/warp_tool.c` to `<project>/modbuild/mods_src/warp_tool.c`
   (the USA project: `<project>/mods_src/warp_tool.c`).
2. Make sure the build compiles it into `psx-runtime` with the right region:

       target_sources(psx-runtime PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/mods_src/warp_tool.c")
       target_compile_definitions(psx-runtime PRIVATE DW3_GAME_REGION_EU)   # or _US

3. Relink: `cmake --build build --config Release --parallel`
   Incrementally this is seconds, because only `warp_tool.c` and the final link
   are redone.
4. Copy the rebuilt executable into the build folder.

A wrong region table is not silent. The plugin refuses loudly at run time
instead of writing through bad addresses.

## 3. Turning it on and off (the state file)

`EXE_DIR/mods/state.toml`, `format_version = 2`. The runtime reads it on every
launch. To enable:

    format_version = 2

    [[package]]
    id = "dev.warp-tool"
    version = "1.0.1"

    [[feature]]
    package_id = "dev.warp-tool"
    id = "warp"
    enabled = true

Set `enabled = false` to switch it off. A missing state file runs every feature
at its manifest default. `default_enabled` is false for this mod, so a missing,
empty or malformed state file leaves it off and the game still runs.

The launcher does this through `provider.feature_enable("dev.warp-tool", "warp", 0|1)`.
