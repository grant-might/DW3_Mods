/*
 * dev.enemy-hp - Digimon World 3 / 2003: the ENEMY's HP on the battle HUD.
 *
 * WHAT IT DOES
 *   In battle the game's own HUD (FIGHTSTG_drawHud, src/fightstg/fightstg_6.c)
 *   draws BOTH sides' HP bars and the PLAYER's "current/max" HP numbers, but it
 *   prints numbers for the player's side only.  This mod draws the ENEMY's
 *   current and max HP in the same shape as the player's row - current first,
 *   then "/", then max - on the enemy's own side of the HUD, so the two rows
 *   read the same way.
 *
 * THE VALUE IS THE GAME'S OWN, PERSISTENT HP (never recomputed from stats)
 *   The battle state is the overlay global FIGHTSTG_battle (src/fightstg.h,
 *   Battle): active[2] at +0x08 and fighters[2][3] at +0x10, each BattleFighter
 *   with maxHp at +0x06 and hp at +0x08 (size 0x20).  The game writes hp when
 *   the battle starts (WFIGHTMN_initFighters copies BATTLE_SETUP.enemies[i].hp
 *   through WFIGHTMN_setStat), decrements it as damage lands
 *   (fightstg_5.c: struck->hp -= task->damage; fightstg_6.c: enemy->hp -=
 *   task->damage), restores it on heal/revive, and reads it for the AI.  This
 *   mod reads that same 16-bit field - the persistent value - and the game's
 *   own maxHp for the denominator.  Nothing is derived from stats.
 *
 *   The per-region address of FIGHTSTG_battle is the only battle-specific
 *   address needed; it comes from the matching decomp per region
 *   (config/<region>/symbols_fightstg.txt), and the region is selected by the
 *   BUILD (DW3_GAME_REGION_EU / _US), not by a runtime guess (a missing define
 *   is a compile error).  The FIGHTSTG overlay is loaded only while
 *   GAME.mode & 0xFF00 == MODE_BATTLE (0x600), so the mod only ever reads it
 *   then.
 *
 * WHERE IT IS DRAWN, AND WHY THE DISC VERSION'S PLACEMENT WAS WRONG
 *   The game's own HUD geometry (FIGHTSTG_drawHud + FIGHTSTG_hpBars +
 *   FIGHTSTG_iconX, all in fightstg_6.c, screen 320x240):
 *
 *       player: name window at (0x AE, 0x15) = (174, 21)   style 1
 *               current HP right-aligned at x 0x10B = 267, y 0x1A = 26
 *               separator  "/" window at x 0x10C = 268
 *               max HP     right-aligned at x 0x12E = 302
 *               bar  x 175..303, y 37..43
 *       enemy : name window at (0x11, 0x15) = (17, 21)      style 1
 *               bar  x  15..143, y 37..43
 *               party icons at x 15, 26, 37, y 48
 *
 *   The earlier disc mod mirrored the player's three number windows about the
 *   screen centre (x -> 0x140 - x): current at 0x35, separator at 0x34, max at
 *   0x12, all at y 0x1A.  That is wrong twice over:
 *     * the order flips - max sits at x 0x12 (left) and current at 0x35, so the
 *       pair READS BACKWARDS as "MAX/CURRENT";
 *     * it lands on the enemy's NAME, which is left-aligned from x 17 and runs
 *       straight through x 18..53 at the very same rows (name band y 21..32).
 *   Both are what the owner saw.
 *
 *   This mod instead keeps the player's row's own reading order and puts the
 *   enemy's copy on the free row immediately UNDER the enemy's HP bar, right
 *   aligned to the bar's right end (x 143, the end the player's numbers line up
 *   with on their bar).  There the text clears
 *     * the enemy's name  (name band y 21..32, above the bar),
 *     * the enemy's bar   (y 37..43, above the text),
 *     * the party icons   (x 15..47 at y 48, to the left of the text).
 *   It reads normally: current, then "/", then max.
 *
 * HOW IT IS DRAWN
 *   This is a statically linked vblank plugin: it cannot call the overlay's own
 *   text code, so it paints the digits into guest VRAM by hand, one lit pixel
 *   at a time, at vblank - the same host-side technique the warp tool uses for
 *   its panel.  Because the guest redraws its frame every vblank, the mod
 *   re-writes its pixels on EVERY vblank; a one-shot write would be gone by the
 *   next frame.  The glyphs are the runtime's public-domain 8x8 font (the same
 *   table host_osd.c uses), painted in the colour the game's own HP numbers
 *   use (amber, C(30,17,1); see COL_DIGIT) with a one-pixel dark outline so
 *   they stay legible over any battle backdrop.  The pixels - and only those -
 *   are
 *   written, so the game's frame shows through everywhere else (no opaque
 *   panel).
 *
 *   The destination is taken from gpu_get_display_info() afresh on every
 *   blit: the game alternates the display start between its two framebuffers
 *   every frame, and a destination cached at compose time lands off-screen on
 *   alternate frames.  On the OpenGL backend the guest's own staged VRAM
 *   uploads are flushed BEFORE this mod's pixels are written, so the mod's
 *   pixels cannot be merged into a larger dirty rect that would be uploaded
 *   from a stale CPU-side copy of the frame; the mod's own pixels are then
 *   flushed after.
 */

#include "mod_plugins.h"
#include "gpu_render.h"   /* gr_vram_transfer_in, gr_backend, backend enum */
#include "gpu.h"          /* gpu_get_display_info, GpuDisplayInfo */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

/* runtime/src/gpu_gl_renderer.c: upload the CPU VRAM array's staged rects into
 * the GPU-side VRAM texture now (instead of waiting for the present path). */
extern void gl_renderer_flush_cpu_uploads(void);

/* Diagnostic frame dump (the warp tool's proven recipe): dump the displayed
 * band from INSIDE the vblank callback, so the file shows the composited
 * result (the guest's frame + this mod's pixels).  An out-of-band
 * vram_peek/screenshot usually MISSES a vblank-drawn overlay. */
extern uint16_t *gpu_get_vram_ptr(void);
extern void gl_renderer_sync_cpu(void);

/* ==========================================================================
 * REGION TABLE.  The European and USA builds are different binaries, so the
 * battle overlay's global addresses differ.  Everything else the mod needs
 * (Battle/BattleFighter field offsets) has no version conditional in the decomp
 * and is shared.  Addresses from the matching decomp:
 *   config/eu/symbols_fightstg.txt   FIGHTSTG_battle = 0x800A4460
 *   config/us/symbols_fightstg.txt   FIGHTSTG_battle = 0x800A31E8
 * plus GAME and GameState.mode from config/<region>/symbols.txt and
 * include/dw3/game_state.h (mode is at +0x26C4 EU / +0x26BC US because the
 * event-flag blocks differ in size).
 * ======================================================================== */
typedef struct EhpRegion {
    const char *name;
    const char *serial;
    uint32_t game;            /* GAME base (GameState *)            */
    uint32_t game_off_mode;   /* GameState.mode offset within GAME  */
    uint32_t root_task;       /* main.c's ROOT_TASK (dev boot jump) */
    uint32_t battle;          /* FIGHTSTG_battle (Battle)           */
} EhpRegion;

static const EhpRegion kEhpRegions[] = {
    { "Europe (SLES-03936)", "SLES-03936",
      0x80048D34u, 0x26C4u, 0x8005CCBCu, 0x800A4460u },
    { "USA (SLUS-01436)", "SLUS-01436",
      0x800484E8u, 0x26BCu, 0x8005C458u, 0x800A31E8u },
};
#if defined(DW3_GAME_REGION_US)
#define EHP_REGION_INDEX 1
#elif defined(DW3_GAME_REGION_EU)
#define EHP_REGION_INDEX 0
#else
#error "enemy_hp.c: define DW3_GAME_REGION_EU or DW3_GAME_REGION_US for this build (see the region table)."
#endif

static const EhpRegion *s_reg = &kEhpRegions[EHP_REGION_INDEX];

#define GAME_BASE      (s_reg->game)
#define GAME_MODE      (GAME_BASE + s_reg->game_off_mode)   /* s32 mode      */

/* MODE_BATTLE 0x600; MODE_OVERLAY(mode) = mode & 0xFF00.  The FIGHTSTG overlay
 * (and therefore FIGHTSTG_battle) is loaded only for this mode group. */
#define MODE_OVERLAY_MASK   0xFF00u
#define MODE_BATTLE         0x0600u

/* Battle (src/fightstg.h) */
#define B_ACTIVE        0x08u   /* s32 active[2]                      */
#define B_FIGHTERS      0x10u   /* BattleFighter fighters[2][3]       */
#define B_FIGHTER_SIZE  0x20u   /* sizeof(BattleFighter)              */
#define BF_ID           0x00u   /* s16 id (the Digimon)               */
#define BF_MAXHP        0x06u   /* s16 maxHp                          */
#define BF_HP           0x08u   /* s16 hp                             */

#define ENEMY_SIDE      1       /* side 1 = the enemies               */
#define FIGHTER(base, side, slot) \
    ((base) + B_FIGHTERS + (uint32_t)((side) * 3 + (slot)) * B_FIGHTER_SIZE)

/* ==========================================================================
 * Placement.  Screen is 320x240; the game's HUD geometry is quoted above.
 *   EHP_RIGHT_EDGE  the enemy HP bar's right end (0x8F); the numbers are
 *                   right-aligned so the group ends here.
 *   EHP_ROW_Y       the row under the bar (bar occupies y 37..43; the icons
 *                   are at y 48).  Both are manifest options and can be moved
 *                   by the player without a rebuild.
 * ======================================================================== */
#define EHP_RIGHT_EDGE_DEFAULT 143
#define EHP_ROW_Y_DEFAULT       46
#define EHP_GLYPH_W              8
#define EHP_GLYPH_H              8

#define PKG_ID     "dev.enemy-hp"
#define FEATURE_ID "hp"

/* --------------------------------------------------------------------------
 * RGB555 (PS1 direct colour: bits 0-4 R, 5-9 G, 10-14 B; each channel <= 31).
 *
 * THE COLOUR IS THE GAME'S OWN BATTLE-HP NUMBER COLOUR.
 *   The player's HP numbers are TextWindows (createTextWindow(0x1005, 3, ...))
 *   and textWindowDraw paints each glyph with the CLUT row selected by the
 *   window's palette attribute (obj->palette, +0xC0) plus the glyph's clutY;
 *   the primitive's own colour field is a fixed neutral 0x80 that colours
 *   nothing.  The battle HUD never re-palettes those number windows, so their
 *   colour is constant - unlike the HP BAR, which redraws from
 *   FIGHTSTG_hpBarColors and goes green/red by quarter-HP.  A statically linked
 *   plugin cannot call the overlay's text code, so this mod paints the same
 *   colour directly: the amber the game's own digits use.  Measured from the
 *   retail battle HUD (three screenshots; the most saturated ink pixel of the
 *   "current/max" digits): rgb(240,136,10) -> RGB555 C(30,17,1).  The glyphs
 *   keep a one-pixel dark outline, as the game's own digits are dark-shaded.
 * ------------------------------------------------------------------------ */
#define C(r,g,b) ((uint16_t)(((b) << 10) | ((g) << 5) | (r)))
#define COL_DIGIT   C(30,17,1)     /* amber: the game's own HP number colour */
#define COL_OUTLINE C( 0, 0, 4)    /* near-black navy                       */

/* Runtime's public-domain 8x8 font (host_osd.c FONT8X8, ASCII 32..126), row
 * bitmasks with bit 0 = leftmost pixel. */
static const unsigned char kFont8x8[95][8] = {
    {0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00}, /*   */
    {0x18,0x3C,0x3C,0x18,0x18,0x00,0x18,0x00}, /* ! */
    {0x36,0x36,0x00,0x00,0x00,0x00,0x00,0x00}, /* " */
    {0x36,0x36,0x7F,0x36,0x7F,0x36,0x36,0x00}, /* # */
    {0x0C,0x3E,0x03,0x1E,0x30,0x1F,0x0C,0x00}, /* $ */
    {0x00,0x63,0x33,0x18,0x0C,0x66,0x63,0x00}, /* % */
    {0x1C,0x36,0x1C,0x6E,0x3B,0x33,0x6E,0x00}, /* & */
    {0x06,0x06,0x03,0x00,0x00,0x00,0x00,0x00}, /* ' */
    {0x18,0x0C,0x06,0x06,0x06,0x0C,0x18,0x00}, /* ( */
    {0x06,0x0C,0x18,0x18,0x18,0x0C,0x06,0x00}, /* ) */
    {0x00,0x66,0x3C,0xFF,0x3C,0x66,0x00,0x00}, /* * */
    {0x00,0x0C,0x0C,0x3F,0x0C,0x0C,0x00,0x00}, /* + */
    {0x00,0x00,0x00,0x00,0x00,0x0C,0x0C,0x06}, /* , */
    {0x00,0x00,0x00,0x3F,0x00,0x00,0x00,0x00}, /* - */
    {0x00,0x00,0x00,0x00,0x00,0x0C,0x0C,0x00}, /* . */
    {0x60,0x30,0x18,0x0C,0x06,0x03,0x01,0x00}, /* / */
    {0x3E,0x63,0x73,0x7B,0x6F,0x67,0x3E,0x00}, /* 0 */
    {0x0C,0x0E,0x0C,0x0C,0x0C,0x0C,0x3F,0x00}, /* 1 */
    {0x1E,0x33,0x30,0x1C,0x06,0x33,0x3F,0x00}, /* 2 */
    {0x1E,0x33,0x30,0x1C,0x30,0x33,0x1E,0x00}, /* 3 */
    {0x38,0x3C,0x36,0x33,0x7F,0x30,0x78,0x00}, /* 4 */
    {0x3F,0x03,0x1F,0x30,0x30,0x33,0x1E,0x00}, /* 5 */
    {0x1C,0x06,0x03,0x1F,0x33,0x33,0x1E,0x00}, /* 6 */
    {0x3F,0x33,0x30,0x18,0x0C,0x0C,0x0C,0x00}, /* 7 */
    {0x1E,0x33,0x33,0x1E,0x33,0x33,0x1E,0x00}, /* 8 */
    {0x1E,0x33,0x33,0x3E,0x30,0x18,0x0E,0x00}, /* 9 */
    {0x00,0x0C,0x0C,0x00,0x00,0x0C,0x0C,0x00}, /* : */
    {0x00,0x0C,0x0C,0x00,0x00,0x0C,0x0C,0x06}, /* ; */
    {0x18,0x0C,0x06,0x03,0x06,0x0C,0x18,0x00}, /* < */
    {0x00,0x00,0x3F,0x00,0x00,0x3F,0x00,0x00}, /* = */
    {0x06,0x0C,0x18,0x30,0x18,0x0C,0x06,0x00}, /* > */
    {0x1E,0x33,0x30,0x18,0x0C,0x00,0x0C,0x00}, /* ? */
    {0x3E,0x63,0x7B,0x7B,0x7B,0x03,0x1E,0x00}, /* @ */
    {0x0C,0x1E,0x33,0x33,0x3F,0x33,0x33,0x00}, /* A */
    {0x3F,0x66,0x66,0x3E,0x66,0x66,0x3F,0x00}, /* B */
    {0x3C,0x66,0x03,0x03,0x03,0x66,0x3C,0x00}, /* C */
    {0x1F,0x36,0x66,0x66,0x66,0x36,0x1F,0x00}, /* D */
    {0x7F,0x06,0x06,0x3E,0x06,0x06,0x7F,0x00}, /* E */
    {0x7F,0x06,0x06,0x3E,0x06,0x06,0x06,0x00}, /* F */
    {0x3C,0x66,0x03,0x03,0x73,0x66,0x7C,0x00}, /* G */
    {0x33,0x33,0x33,0x3F,0x33,0x33,0x33,0x00}, /* H */
    {0x1E,0x0C,0x0C,0x0C,0x0C,0x0C,0x1E,0x00}, /* I */
    {0x78,0x30,0x30,0x30,0x33,0x33,0x1E,0x00}, /* J */
    {0x67,0x66,0x36,0x1E,0x36,0x66,0x67,0x00}, /* K */
    {0x06,0x06,0x06,0x06,0x06,0x06,0x7F,0x00}, /* L */
    {0x63,0x77,0x7F,0x7F,0x6B,0x63,0x63,0x00}, /* M */
    {0x63,0x67,0x6F,0x7B,0x73,0x63,0x63,0x00}, /* N */
    {0x1C,0x36,0x63,0x63,0x63,0x36,0x1C,0x00}, /* O */
    {0x3F,0x66,0x66,0x3E,0x06,0x06,0x06,0x00}, /* P */
    {0x1E,0x33,0x33,0x33,0x3B,0x1E,0x38,0x00}, /* Q */
    {0x3F,0x66,0x66,0x3E,0x36,0x66,0x67,0x00}, /* R */
    {0x1E,0x33,0x07,0x0E,0x38,0x33,0x1E,0x00}, /* S */
    {0x3F,0x2D,0x0C,0x0C,0x0C,0x0C,0x1E,0x00}, /* T */
    {0x33,0x33,0x33,0x33,0x33,0x33,0x3F,0x00}, /* U */
    {0x33,0x33,0x33,0x33,0x33,0x1E,0x0C,0x00}, /* V */
    {0x63,0x63,0x63,0x6B,0x7F,0x77,0x63,0x00}, /* W */
    {0x63,0x63,0x36,0x1C,0x1C,0x36,0x63,0x00}, /* X */
    {0x33,0x33,0x33,0x1E,0x0C,0x0C,0x1E,0x00}, /* Y */
    {0x7F,0x63,0x31,0x18,0x4C,0x66,0x7F,0x00}, /* Z */
    {0x1E,0x06,0x06,0x06,0x06,0x06,0x1E,0x00}, /* [ */
    {0x03,0x06,0x0C,0x18,0x30,0x60,0x40,0x00}, /* \ */
    {0x1E,0x18,0x18,0x18,0x18,0x18,0x1E,0x00}, /* ] */
    {0x08,0x1C,0x36,0x63,0x00,0x00,0x00,0x00}, /* ^ */
    {0x00,0x00,0x00,0x00,0x00,0x00,0x00,0xFF}, /* _ */
    {0x0C,0x0C,0x18,0x00,0x00,0x00,0x00,0x00}, /* ` */
    {0x00,0x00,0x1E,0x30,0x3E,0x33,0x6E,0x00}, /* a */
    {0x07,0x06,0x06,0x3E,0x66,0x66,0x3B,0x00}, /* b */
    {0x00,0x00,0x1E,0x33,0x03,0x33,0x1E,0x00}, /* c */
    {0x38,0x30,0x30,0x3e,0x33,0x33,0x6E,0x00}, /* d */
    {0x00,0x00,0x1E,0x33,0x3f,0x03,0x1E,0x00}, /* e */
    {0x1C,0x36,0x06,0x0f,0x06,0x06,0x0f,0x00}, /* f */
    {0x00,0x00,0x6E,0x33,0x33,0x3E,0x30,0x1F}, /* g */
    {0x07,0x06,0x36,0x6E,0x66,0x66,0x67,0x00}, /* h */
    {0x0C,0x00,0x0E,0x0C,0x0C,0x0C,0x1E,0x00}, /* i */
    {0x30,0x00,0x30,0x30,0x30,0x33,0x33,0x1E}, /* j */
    {0x07,0x06,0x66,0x36,0x1E,0x36,0x67,0x00}, /* k */
    {0x0E,0x0C,0x0C,0x0C,0x0C,0x0C,0x1E,0x00}, /* l */
    {0x00,0x00,0x33,0x7F,0x7F,0x6B,0x63,0x00}, /* m */
    {0x00,0x00,0x1F,0x33,0x33,0x33,0x33,0x00}, /* n */
    {0x00,0x00,0x1E,0x33,0x33,0x33,0x1E,0x00}, /* o */
    {0x00,0x00,0x3B,0x66,0x66,0x3E,0x06,0x0F}, /* p */
    {0x00,0x00,0x6E,0x33,0x33,0x3E,0x30,0x78}, /* q */
    {0x00,0x00,0x3B,0x6E,0x66,0x06,0x0F,0x00}, /* r */
    {0x00,0x00,0x3E,0x03,0x1E,0x30,0x1F,0x00}, /* s */
    {0x08,0x0C,0x3E,0x0C,0x0C,0x2C,0x18,0x00}, /* t */
    {0x00,0x00,0x33,0x33,0x33,0x33,0x6E,0x00}, /* u */
    {0x00,0x00,0x33,0x33,0x33,0x1E,0x0C,0x00}, /* v */
    {0x00,0x00,0x63,0x6B,0x7F,0x7F,0x36,0x00}, /* w */
    {0x00,0x00,0x63,0x36,0x1C,0x36,0x63,0x00}, /* x */
    {0x00,0x00,0x33,0x33,0x33,0x3E,0x30,0x1F}, /* y */
    {0x00,0x00,0x3F,0x19,0x0C,0x26,0x3F,0x00}, /* z */
    {0x38,0x0C,0x0C,0x07,0x0C,0x0C,0x38,0x00}, /* { */
    {0x18,0x18,0x18,0x00,0x18,0x18,0x18,0x00}, /* | */
    {0x07,0x0C,0x0C,0x38,0x0C,0x0C,0x07,0x00}, /* } */
    {0x6E,0x3B,0x00,0x00,0x00,0x00,0x00,0x00}, /* ~ */
};

/* --------------------------------------------------------------------------
 * The composed text: a mask of lit cells in a small buffer, plus its top-left
 * screen position.  Composed only when the content changes; written to VRAM
 * every vblank.
 * ------------------------------------------------------------------------ */
#define EHP_MAX_W 128
#define EHP_MAX_H  16
static uint16_t s_cell[EHP_MAX_H][EHP_MAX_W];  /* 0 = transparent, else colour */
static int      s_cell_w, s_cell_h;
static int      s_cell_x, s_cell_y;            /* top-left, screen coords     */
static int      s_cell_valid = 0;
static char     s_text[24] = "";               /* the composed string         */
static unsigned s_sig = 0;                     /* content signature           */

static void cell_put(int x, int y, uint16_t col) {
    if (x < 0 || y < 0 || x >= EHP_MAX_W || y >= EHP_MAX_H) return;
    s_cell[y][x] = col;
}

static void cell_char(int x, int y, int ch, uint16_t col) {
    const unsigned char *g;
    int r, b;
    if (ch < 32 || ch > 126) ch = '?';
    g = kFont8x8[ch - 32];
    for (r = 0; r < EHP_GLYPH_H; r++) {
        for (b = 0; b < EHP_GLYPH_W; b++) {
            if (g[r] & (1u << b)) cell_put(x + b, y + r, col);
        }
    }
}

/* One glyph, white with a one-pixel dark outline so it reads over any scene. */
static void cell_char_outlined(int x, int y, int ch) {
    static const int off[4][2] = { {-1,0}, {1,0}, {0,-1}, {0,1} };
    int k;
    for (k = 0; k < 4; k++)
        cell_char(x + off[k][0], y + off[k][1], ch, COL_OUTLINE);
    cell_char(x, y, ch, COL_DIGIT);
}

/*
 * Compose "<text>" right-aligned so its right edge is at right_edge, with its
 * top row at row_y.  Returns 1 when something was composed.
 */
static int cell_compose(const char *text, int right_edge, int row_y) {
    int n = (int)strlen(text);
    int i, w = n * EHP_GLYPH_W;
    if (n <= 0 || w + 2 > EHP_MAX_W) return 0;
    memset(s_cell, 0, sizeof s_cell);
    /* 1-pixel outline margin on every side */
    for (i = 0; i < n; i++)
        cell_char_outlined(1 + i * EHP_GLYPH_W, 1, (unsigned char)text[i]);
    s_cell_w = w + 2;
    s_cell_h = EHP_GLYPH_H + 2;
    s_cell_x = right_edge - w;      /* the outline sits 1 px left of this   */
    s_cell_y = row_y - 1;
    if (s_cell_x < 0) s_cell_x = 0;
    s_cell_valid = 1;
    return 1;
}

/* Write the composed cells into guest VRAM at the display origin this frame
 * will present.  Only lit cells are written, so the game's frame shows through
 * everywhere else. */
static void cell_blit(void) {
    GpuDisplayInfo di;
    int x, y, dx, dy;
    if (!s_cell_valid) return;
    gpu_get_display_info(&di);
    if (di.disabled) return;
    dx = (int)di.display_x + s_cell_x;
    dy = (int)di.display_y + s_cell_y;
    for (y = 0; y < s_cell_h; y++) {
        for (x = 0; x < s_cell_w; x++) {
            uint16_t col = s_cell[y][x];
            if (col != 0) gr_vram_write(dx + x, dy + y, col);
        }
    }
}

/* Dump the displayed band (RGB555, row-major, little endian) from inside the
 * vblank callback, so the file shows what the window shows. */
static void ehp_dump(const char *prefix, unsigned frame) {
    GpuDisplayInfo di;
    uint16_t *vram;
    FILE *f;
    char path[512];
    int x, y, W, H;
    gpu_get_display_info(&di);
    if (di.disabled) return;
    W = (int)di.width; H = (int)di.height;
    if (W <= 0 || W > 1024) W = 320;
    if (H <= 0 || H > 512) H = 240;
    gl_renderer_sync_cpu();          /* no-op on the software renderer */
    vram = gpu_get_vram_ptr();
    if (!vram) return;
    snprintf(path, sizeof path, "%s_%u.raw", prefix, frame);
    f = fopen(path, "wb");
    if (!f) return;
    for (y = 0; y < H; y++) {
        const uint16_t *row = vram + (size_t)(((int)di.display_y + y) & 511) * 1024;
        for (x = 0; x < W; x++)
            fwrite(row + (((int)di.display_x + x) & 1023), 2, 1, f);
    }
    fclose(f);
}

/* ==========================================================================
 * Guest-side reads.
 * ======================================================================== */
static int ehp_in_battle(void) {
    int mode = (int)psx_mod_read_word(GAME_MODE);
    return ((unsigned)mode & MODE_OVERLAY_MASK) == MODE_BATTLE;
}

/* The enemy's live values, or 0 when the battle state does not read as one. */
static int ehp_read_enemy(int *id, int *hp, int *maxHp) {
    uint32_t base = s_reg->battle;
    int slot = (int)psx_mod_read_word(base + B_ACTIVE + ENEMY_SIDE * 4u);
    uint32_t f;
    if (slot < 0 || slot > 2) return 0;
    f = FIGHTER(base, ENEMY_SIDE, slot);
    *id    = (int)(int16_t)psx_mod_read_half(f + BF_ID);
    *maxHp = (int)(int16_t)psx_mod_read_half(f + BF_MAXHP);
    *hp    = (int)(int16_t)psx_mod_read_half(f + BF_HP);
    if (*maxHp <= 0) return 0;              /* not populated yet          */
    if (*hp < 0) *hp = 0;
    if (*hp > *maxHp) *hp = *maxHp;
    return 1;
}

/* ==========================================================================
 * Options / dev environment.
 * ======================================================================== */
static int s_right_edge = EHP_RIGHT_EDGE_DEFAULT;
static int s_row_y      = EHP_ROW_Y_DEFAULT;
static int s_boot_mode  = 0;
static int s_booted     = 0;
static int s_force      = 0;      /* DW3_ENEMYHP_SHOW=1: draw outside battle */
static const char *s_force_text = NULL; /* DW3_ENEMYHP_TEXT=<text>: fixed text */
static const char *s_log_path   = NULL;
static FILE *s_log;
static int   s_log_tried;
static const char *s_shot       = NULL;   /* DW3_ENEMYHP_SHOT=<prefix>       */
static int   s_shot_n           = 0;
static int   s_shot_step        = 60;
static unsigned s_frame;
static int s_seen_battle = 0;
static int s_battle_frames = 0;
static int s_warned = 0;

static void ehp_log(const char *line) {
    if (!s_log_path) return;
    if (!s_log) {
        if (s_log_tried) return;
        s_log_tried = 1;
        s_log = fopen(s_log_path, "w");
        if (!s_log) { fprintf(stderr, "enemy-hp: cannot open log %s\n", s_log_path); return; }
    }
    fprintf(s_log, "%s\n", line);
    fflush(s_log);
}

static void ehp_read_options(void) {
    char buf[32];
    const char *env;
    if (psx_mod_option_value(PKG_ID, FEATURE_ID, "y", buf, sizeof buf)) {
        int v = (int)strtol(buf, NULL, 0);
        if (v > 0 && v < 232) s_row_y = v;
    }
    if (psx_mod_option_value(PKG_ID, FEATURE_ID, "right", buf, sizeof buf)) {
        int v = (int)strtol(buf, NULL, 0);
        if (v > 16 && v <= 320) s_right_edge = v;
    }
    env = getenv("DW3_ENEMYHP_BOOT");   if (env && *env) s_boot_mode = (int)strtol(env, NULL, 0);
    env = getenv("DW3_ENEMYHP_Y");      if (env && *env) s_row_y = (int)strtol(env, NULL, 0);
    env = getenv("DW3_ENEMYHP_X");      if (env && *env) s_right_edge = (int)strtol(env, NULL, 0);
    env = getenv("DW3_ENEMYHP_SHOW");   if (env && *env && env[0] != '0') s_force = 1;
    s_force_text = getenv("DW3_ENEMYHP_TEXT");
    s_log_path   = getenv("DW3_ENEMYHP_LOG");
    s_shot       = getenv("DW3_ENEMYHP_SHOT");
    env = getenv("DW3_ENEMYHP_SHOT_STEP");
    if (env && *env) { s_shot_step = (int)strtol(env, NULL, 0); if (s_shot_step < 1) s_shot_step = 1; }

    fprintf(stderr,
            "enemy-hp: active for %s (%s); FIGHTSTG_battle 0x%08X, GAME 0x%08X "
            "(mode@+0x%X); enemy numbers right-aligned at x=%d, row y=%d; "
            "digit colour C(%d,%d,%d)=0x%04X (game's own HP amber); "
            "boot=%s show=%s\n",
            s_reg->name, s_reg->serial, (unsigned)s_reg->battle,
            (unsigned)GAME_BASE, (unsigned)s_reg->game_off_mode,
            s_right_edge, s_row_y,
            31 & COL_DIGIT, 31 & (COL_DIGIT >> 5), 31 & (COL_DIGIT >> 10),
            (unsigned)COL_DIGIT,
            s_boot_mode ? "on" : "off", s_force ? "on" : "off");
}

/* --------------------------------------------------------------------------
 * A LOUD, LAZY self-test of the region table.  It only judges inside a battle
 * (mode & 0xFF00 == 0x600), where FIGHTSTG_battle is guaranteed loaded, and
 * only after the battle state has had a chance to be populated.  A wrong
 * address reads unrelated overlay bytes: active[0]/active[1] fall outside 0..2
 * and stay there.  That - and only that - disables the mod.
 * ------------------------------------------------------------------------ */
static void ehp_selftest(void) {
    int a0, a1;
    if (s_warned || !ehp_in_battle()) return;
    a0 = (int)psx_mod_read_word(s_reg->battle + B_ACTIVE);
    a1 = (int)psx_mod_read_word(s_reg->battle + B_ACTIVE + 4u);
    if (a0 >= 0 && a0 <= 2 && a1 >= 0 && a1 <= 2) return;
    s_battle_frames++;
    if (s_battle_frames < 120) return;      /* give the battle time to load */
    s_warned = 1;
    fprintf(stderr,
            "enemy-hp: BATTLE STATE SELF-TEST FAILED for %s - FIGHTSTG_battle "
            "0x%08X reads active[0]=%d active[1]=%d, which is not a battle "
            "state for this region. DISABLING the mod (no pixels drawn). Is "
            "this build using the wrong region table?\n",
            s_reg->name, (unsigned)s_reg->battle, a0, a1);
}

/* ==========================================================================
 * Per-frame.
 * ======================================================================== */
static void ehp_vblank(void) {
    char text[24];
    int id = 0, hp = 0, maxHp = 0, have = 0;
    unsigned sig;

    if (!psx_mod_game_started()) return;
    s_frame++;

    if (s_boot_mode != 0 && !s_booted && (int)psx_mod_read_word(GAME_MODE) != 0) {
        s_booted = 1;
        fprintf(stderr, "enemy-hp: boot jump -> mode=0x%X (clearing ROOT_TASK)\n",
                (unsigned)s_boot_mode);
        psx_mod_write_word(GAME_BASE + s_reg->game_off_mode + 4u, (uint32_t)s_boot_mode);
        psx_mod_write_word(s_reg->root_task, 0u);
    }

    if (s_warned) { s_cell_valid = 0; return; }

    ehp_selftest();

    if (s_force_text && *s_force_text) {
        /* dev: draw a fixed string, anywhere, to check placement */
        strncpy(text, s_force_text, sizeof text - 1);
        text[sizeof text - 1] = 0;
        have = 1;
    } else if (s_force) {
        snprintf(text, sizeof text, "816/816");
        have = 1;
    } else if (ehp_in_battle()) {
        if (!s_seen_battle) {
            s_seen_battle = 1;
            fprintf(stderr, "enemy-hp: in battle (mode 0x%X); reading "
                            "FIGHTSTG_battle 0x%08X\n",
                    (unsigned)psx_mod_read_word(GAME_MODE),
                    (unsigned)s_reg->battle);
            { char l[160];
              snprintf(l, sizeof l, "frame=%u battle entry mode=0x%X battle=0x%08X",
                       s_frame, (unsigned)psx_mod_read_word(GAME_MODE),
                       (unsigned)s_reg->battle);
              ehp_log(l); }
        }
        have = ehp_read_enemy(&id, &hp, &maxHp);
        if (have) snprintf(text, sizeof text, "%d/%d", hp, maxHp);
    }

    if (!have) {
        if (s_cell_valid && s_log_path) {
            char l[160];
            snprintf(l, sizeof l, "frame=%u hide (mode=0x%X)", s_frame,
                     (unsigned)psx_mod_read_word(GAME_MODE));
            ehp_log(l);
        }
        s_cell_valid = 0;
        s_sig = 0;
        return;
    }

    sig = 0xE1000000u ^ ((unsigned)s_row_y * 0x9E3779B1u)
                      ^ ((unsigned)s_right_edge * 0x85EBCA6Bu);
    { unsigned i; for (i = 0; text[i]; i++) sig = sig * 16777619u ^ (unsigned char)text[i]; }

    if (sig != s_sig) {
        s_sig = sig;
        if (cell_compose(text, s_right_edge, s_row_y)) {
            char l[200];
            snprintf(l, sizeof l,
                     "frame=%u mode=0x%X enemy id=%d hp=%d maxHp=%d -> \"%s\" "
                     "x=%d..%d y=%d..%d col C(%d,%d,%d)=0x%04X",
                     s_frame, (unsigned)psx_mod_read_word(GAME_MODE), id, hp, maxHp,
                     text, s_cell_x, s_cell_x + s_cell_w - 1,
                     s_cell_y, s_cell_y + s_cell_h - 1,
                     31 & COL_DIGIT, 31 & (COL_DIGIT >> 5), 31 & (COL_DIGIT >> 10),
                     (unsigned)COL_DIGIT);
            ehp_log(l);
        } else {
            s_cell_valid = 0;
        }
    }

    if (!s_cell_valid) return;

    /* OpenGL: land the guest's staged uploads first so this mod's pixels cannot
     * be merged into a wider dirty rect that would upload from a stale CPU copy
     * of the frame; then write, then flush our own pixels. */
    if (gr_backend() == GR_BACKEND_OPENGL) gl_renderer_flush_cpu_uploads();
    cell_blit();
    if (gr_backend() == GR_BACKEND_OPENGL) gl_renderer_flush_cpu_uploads();

    if (s_shot && s_shot_n < 400 && (s_frame % (unsigned)s_shot_step) == 0u) {
        ehp_dump(s_shot, s_frame);
        s_shot_n++;
    }
}

static void ehp_activate(void) { ehp_read_options(); }

PSX_MOD_CONSTRUCTOR(enemy_hp_register) {
    fprintf(stderr, "enemy-hp: registering plugins\n");
    psx_mod_register_activation_plugin(PKG_ID, ehp_activate);
    psx_mod_register_vblank_plugin(PKG_ID, ehp_vblank);
}
