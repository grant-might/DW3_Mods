# dev.enemy-hp 1.0.0 - INSTALL (trusted plugin: install + relink)

This package ships a **statically linked trusted plugin**. The manifest's
`[[plugin]]` block is only an id reference; the runtime refuses to launch if a
selected package's plugin id is not compiled into the exe. So installing this
package needs a **relink** of the target build, once, per region.

Nothing else about the game changes. The plugin source is in this package
(`plugin/enemy_hp.c`); copy it beside the other mod sources and add one line to
the build's `CMakeLists.txt`.

## 1. Put the source where the build can see it

    <project>/mods_src/enemy_hp.c        <- plugin/enemy_hp.c from this package

`<project>` is `D:\AGENT\DMW3-Recomp-OURS` (Europe) or `D:\AGENT\DMW3-Recomp-USA`
(USA). The source is identical for both; the region is chosen by the build's
compile definition (see step 2).

## 2. Add the source and the region define to the build

In the project's `modbuild/CMakeLists.txt` (Europe) or `CMakeLists.txt` (USA),
where the other mod sources are listed:

    target_sources(psx-runtime PRIVATE
      "${CMAKE_CURRENT_SOURCE_DIR}/mods_src/enemy_hp.c")

The region define already exists in both projects (`DW3_GAME_REGION_EU` for
Europe, `DW3_GAME_REGION_US` for USA) because the warp/save tools use it. If it
is missing, add:

    target_compile_definitions(psx-runtime PRIVATE DW3_GAME_REGION_EU)   # Europe
    target_compile_definitions(psx-runtime PRIVATE DW3_GAME_REGION_US)   # USA

A missing define is a compile error (`#error` in enemy_hp.c) - deliberate, so a
mis-built binary can never run with a wrong region's battle-state address.

## 3. Configure, build, deploy the exe

Europe:

    cd D:\AGENT\DMW3-Recomp-OURS\modbuild
    cmake --build build --config Release --parallel
    copy build\Digimon_World_2003_Recompiled.exe  ..\modpipeline\

USA:

    cd D:\AGENT\DMW3-Recomp-USA\build
    cmake --build build --config Release --parallel

Keep the exe NAME identical - the launcher looks it up by name
(`Digimon_World_2003_Recompiled.exe` for Europe, `Digimon_World_3_Recompiled.exe`
for USA).

## 4. Install the package and enable the feature

Unzip this archive **at the root** so `manifest.toml` lands at the root of

    <exe dir>/mods/packages/dev.enemy-hp/1.0.0/manifest.toml

(`ModPackageManager::install_archive` refuses if that version already exists -
remove the old directory first). Then add to `<exe dir>/mods/state.toml`,
`format_version = 2`:

    [[package]]
    id = "dev.enemy-hp"
    version = "1.0.0"

    [[feature]]
    package_id = "dev.enemy-hp"
    id = "hp"
    enabled = true

## 5. Options (no rebuild needed)

`y`     - screen row (1..231) the enemy HP numbers' top line sits on. Default 46.
`right` - screen X the number group's right edge aligns to. Default 143.

The defaults put the numbers on the free row directly under the enemy's HP bar,
right-aligned to that bar's right end. Raise/lower `y` to move them.

## Failure behaviour

* feature disabled -> the plugin's callbacks are never invoked: no pixels, no
  writes, no log line beyond registration.
* wrong region table -> the mod logs
  `enemy-hp: BATTLE STATE SELF-TEST FAILED ...` once and draws nothing.
