/*
 * dev.save-anywhere - Digimon World 3 / 2003 "SAVE ANYWHERE".
 *
 * A trusted static plugin (format-5 [[plugin]]; mod_plugins.h) compiled into
 * the runtime under the stable plugin id "dev.save-anywhere".
 *
 * WHAT IT DOES
 *   Opens a small MODAL panel in the field (same style and input conventions
 *   as the Fast Travel tool) on a controller combo, and on confirmation makes
 *   the GAME's OWN memory-card save screen run - it does NOT hand-write save
 *   state and does NOT rebuild the save UI.
 *
 * THE MECHANISM (the whole point)
 *   The game's own save screen is STGMCARD, game mode MODE_CONTINUE = 0xC00
 *   (include/dw3/game_state.h).  Its main task reads the mode ARGUMENT to
 *   decide SAVE vs LOAD:
 *
 *       MemCardScreen.loading = (u32)GAME.funcs.getModeArg() >> 31 ^ 1;
 *       (src/stgmcard/screen.c:91)
 *
 *   a NEGATIVE argument means SAVING (loading == 0), a non-negative one means
 *   LOADING.  The game itself enters the save screen exactly this way - the
 *   debug stage select's own data table has
 *
 *       {"STMCRD", "SAVE", 0xC00, (s32)0x80000000}   (src/stagslct/stagslct.c:58)
 *
 *   i.e. requestMode(0xC00, 0x80000000).
 *
 *   A host plugin cannot call a guest function, but it CAN drive the game's
 *   own field task, exactly as the Fast Travel tool does.  FIELDSTG closes the
 *   field and requests the next mode itself:
 *
 *       FIELDSTG_closeField() -> GAME.funcs.requestMode(task->nextMode,
 *                                                      task->nextModeArg)
 *       (src/fieldstg/field.c:173 and :253; FIELDSTG_leaveFieldAfter is :590)
 *
 *   So we walk TASK_REGISTRY for the live field task (id FIELD_TASK_FIELD = 7)
 *   and write, exactly as FIELDSTG_leaveFieldAfter does:
 *
 *       task->nextMode    (task + 0x5C)  MODE_CONTINUE (0xC00)
 *       task->nextModeArg (task + 0x60)  0x80000000  (negative => SAVING)
 *       task->leaveDelay  (task + 0x68)  0
 *       task->state       (task + 0x0C)  TASK_DONE (2)
 *       task->substate    (task + 0x10)  0
 *
 *   FIELDSTG_closeField then requests mode 0xC00/0x80000000, main() commits it
 *   (src/main/system/main.c:69-77 + src/main/game/state.c:26), and the game
 *   loads and runs its own STGMCARD save screen - real slot picker, real
 *   checksums, real MEMCARD writes.  Nothing about the save format is
 *   reimplemented here.
 *
 *   On leaving the save screen the game requests GAME.fieldMode (screen.c:63-75
 *   with screen->step == 0), and FIELDSTG restores the player to
 *   FIELDSTG_state.defaultStart = GAME.fieldPos (field.c:336-345), which
 *   FIELDSTG_closeField captured when it left (field.c:254-256).  So the player
 *   comes back where they were.
 *
 * INPUT (the modal, field only) - chosen to collide with NOTHING
 *   The Fast Travel tool owns L2+R2 (and D-pad/L1/R1/X/Triangle/START while its
 *   panel is up); the runtime owns L3 (rewind) and SELECT+R3 / SELECT+R1;
 *   the game's own field uses D-pad, X, Triangle and START.  This mod therefore
 *   opens on SELECT + SQUARE (both free): hold SELECT, press SQUARE.
 *   Keyboard fallback (keybinds.ini): Right Shift + Z.
 *   Panel: D-pad up/down move, CROSS (X / X key) confirm, TRIANGLE (A) or
 *   START (Return) exit - the same conventions as Fast Travel's panel.
 *   R3 is NOT usable: it has no bit in the PSX pad word a plugin can read.
 *
 * HOW THE FIELD IS FROZEN WHILE THE PANEL IS OPEN
 *   FIELDSTG_state.innOpen (FIELDSTG_STATE + 0x50) is the game's own "the pad
 *   does not drive the field" flag (field.c:486, actor_control.c).  The modal
 *   sets it while open and restores the saved value on close.
 *
 * REGIONS
 *   Europe (SLES-03936) and USA (SLUS-01436) are different binaries; the
 *   address table below is selected by the BUILD (-DDW3_GAME_REGION_EU / _US)
 *   and a missing define is a #error.  The region self-test is LAZY and
 *   evidence-driven (same as the warp tool): an empty TASK_REGISTRY is normal
 *   for the whole front end and is never a verdict; only a live registry entry
 *   that is not a valid task pointer/id fails it, and then the mod disables
 *   itself loudly instead of writing through a bad table.
 */

#include "mod_plugins.h"
#include "gpu_render.h"   /* gr_vram_transfer_in, gr_render_display, backend */
#include "gpu.h"          /* gpu_get_display_info, GpuDisplayInfo */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

/* Runtime-internal accessor for the consolidated pad state (sio.c). PS1
 * convention: a CLEARED bit means pressed. */
extern uint16_t sio_get_pad_buttons(void);

/* runtime/src/gpu_gl_renderer.c: upload the CPU VRAM array's staged rects into
 * the GPU-side VRAM texture now (instead of waiting for the present path). */
extern void gl_renderer_flush_cpu_uploads(void);

/* ==========================================================================
 * REGION TABLE (same shape/sources as the warp tool).
 * ======================================================================== */
typedef struct SaveRegion {
    const char *name;
    const char *serial;
    uint32_t game;            /* GAME base                              */
    uint32_t game_off_mode;   /* GameState.mode offset within GAME      */
    uint32_t game_off_next;   /* GameState.nextMode offset within GAME  */
    uint32_t field_state;     /* FIELDSTG_state base                    */
    uint32_t task_registry;   /* TASK_REGISTRY base                     */
    uint32_t root_task;       /* main.c's ROOT_TASK                     */
} SaveRegion;

static const SaveRegion kRegions[] = {
    { "Europe (SLES-03936)", "SLES-03936",
      0x80048D34u, 0x26C4u, 0x26C8u, 0x80099D80u, 0x8004B610u, 0x8005CCBCu },
    { "USA (SLUS-01436)", "SLUS-01436",
      0x800484E8u, 0x26BCu, 0x26C0u, 0x800990B4u, 0x8004ADB8u, 0x8005C458u },
};
#if defined(DW3_GAME_REGION_US)
#define SAVE_REGION_INDEX 1
#elif defined(DW3_GAME_REGION_EU)
#define SAVE_REGION_INDEX 0
#else
#error "save_tool.c: define DW3_GAME_REGION_EU or DW3_GAME_REGION_US for this build."
#endif

static const SaveRegion *s_reg = &kRegions[SAVE_REGION_INDEX];

#define GAME_BASE        (s_reg->game)
#define GAME_MODE        (GAME_BASE + s_reg->game_off_mode)   /* s32 mode     */
#define GAME_NEXTMODE    (GAME_BASE + s_reg->game_off_next)   /* s32 nextMode */
#define GAME_MODEARG_OFF 0x26D0u                              /* EU; USA 0x26C8 */
/* GameState.modeArg: EU +0x26D0, USA +0x26C8 (game_state.h). Derived at
 * runtime from the mode/next offsets so the table stays one source of truth:
 * EU mode +0x26C4 -> modeArg +0x26D0 (+0x0C); USA mode +0x26BC -> +0x26C8. */
#define GAME_MODEARG     (GAME_BASE + (s_reg->game_off_mode + 0x0Cu))

#define FIELDSTG_STATE   (s_reg->field_state)            /* FieldState        */
#define FIELDSTG_INNOPEN (FIELDSTG_STATE + 0x50u)/* s32: pad does not move the player */
#define FIELDSTG_BUSY    (FIELDSTG_STATE + 0x58u)/* s32: an event/warp/battle has the player */
#define FIELDSTG_BATTLE  (FIELDSTG_STATE + 0x5Cu)/* s32: an encounter started */
#define FIELDSTG_ACTING  (FIELDSTG_STATE + 0x60u)/* s32: talks/climbs/slides/searches */

#define TASK_REGISTRY    (s_reg->task_registry)          /* TaskRegistry      */
#define ROOT_TASK        (s_reg->root_task)              /* main.c's mode task ptr */
#define TASK_MAX         100u
#define FIELD_TASK_FIELD 7                       /* the field's main task */

/* Task header offsets (include/dw3/task.h) */
#define T_OFF_ID         0x00u
#define T_OFF_STATE      0x0Cu
#define T_OFF_SUBSTATE   0x10u
/* FieldTask-only offsets (include/fieldstg.h) */
#define T_OFF_NEXTMODE   0x5Cu
#define T_OFF_NEXTARG    0x60u
#define T_OFF_LEAVEDELAY 0x68u

#define TASK_DONE        2

#define FIELDSTG_MODE_BASE 0x200                 /* FIELDSTG field stages   */

/* the game's own memory-card save screen, entered for SAVING */
#define MODE_CONTINUE       0xC00
#define MODE_CONTINUE_SAVE  0x80000000u          /* negative arg => SAVING  */

#define SAVE_MARKER_ADDR  0x1F8003F0u            /* scratchpad tail; dump peek */
#define SAVE_MARKER_VALUE 0x53415645u            /* 'SAVE' */

/* PS1 pad bits (active low) - include/dw3/pad.h */
#define PSX_PAD_SELECT   (1u << 0)
#define PSX_PAD_START    (1u << 3)
#define PSX_PAD_UP       (1u << 4)
#define PSX_PAD_RIGHT    (1u << 5)
#define PSX_PAD_DOWN     (1u << 6)
#define PSX_PAD_LEFT     (1u << 7)
#define PSX_PAD_L2       (1u << 8)
#define PSX_PAD_R2       (1u << 9)
#define PSX_PAD_L1       (1u << 10)
#define PSX_PAD_R1       (1u << 11)
#define PSX_PAD_TRIANGLE (1u << 12)
#define PSX_PAD_CIRCLE   (1u << 13)
#define PSX_PAD_CROSS    (1u << 14)
#define PSX_PAD_SQUARE   (1u << 15)

#define PKG_ID     "dev.save-anywhere"
#define FEATURE_ID "save"

/* ==========================================================================
 * Modal state (declared before the compositor, which reads s_row/s_confirm_msg).
 * ======================================================================== */
#define ROW_SAVE   0
#define ROW_CANCEL 1
#define ROW_COUNT  2

static int      s_row = ROW_SAVE;
static int      s_modal = 0;
static int      s_modal_saved_inn = 0;
static uint16_t s_prev_pad = 0xFFFF;
static unsigned s_open_count = 0;
static unsigned s_confirm_count = 0;
static const char *s_confirm_msg = "OPENING SAVE SCREEN";
static int      s_disabled = 0;
static int      s_region_checked = 0;

/* dev/test hooks */
static int      s_boot_mode = 0;   /* DW3_SAVE_BOOT=<field mode>: boot jump  */
static int      s_booted = 0;
static int      s_boot_load = 0;   /* DW3_SAVE_LOAD=1: boot into LOAD screen  */
static int      s_boot_loaded = 0;
static int      s_force_show = 0;  /* DW3_SAVE_SHOW=1: force the panel up      */
static int      s_auto_trig = 0;   /* DW3_SAVE_TRIG=1: confirm without input    */
static int      s_auto_row = ROW_SAVE;

/* forward decls of helpers used by the compositor */
static int ov_textw(const char *s);

/* ==========================================================================
 * Software text/panel compositor (same approach as the warp tool: build an
 * RGB555 panel in a static buffer, blit it into guest VRAM at vblank).
 * ======================================================================== */

/* Public-domain 8x8 ASCII 32..126 (the runtime's own OSD font), row bitmasks
 * with bit 0 = leftmost pixel. */
static const unsigned char kFont8x8[95][8] = {
    {0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00}, /*   */
    {0x18,0x3C,0x3C,0x18,0x18,0x00,0x18,0x00}, /* ! */
    {0x36,0x36,0x00,0x00,0x00,0x00,0x00,0x00}, /* " */
    {0x36,0x36,0x7F,0x36,0x7F,0x36,0x36,0x00}, /* # */
    {0x0C,0x3E,0x03,0x1E,0x30,0x1F,0x0C,0x00}, /* $ */
    {0x00,0x63,0x33,0x18,0x0C,0x66,0x63,0x00}, /* % */
    {0x1C,0x36,0x1C,0x6E,0x3B,0x33,0x6E,0x00}, /* & */
    {0x06,0x06,0x03,0x00,0x00,0x00,0x00,0x00}, /* ' */
    {0x18,0x0C,0x06,0x06,0x06,0x0C,0x18,0x00}, /* ( */
    {0x06,0x0C,0x18,0x18,0x18,0x0C,0x06,0x00}, /* ) */
    {0x00,0x66,0x3C,0xFF,0x3C,0x66,0x00,0x00}, /* * */
    {0x00,0x0C,0x0C,0x3F,0x0C,0x0C,0x00,0x00}, /* + */
    {0x00,0x00,0x00,0x00,0x00,0x0C,0x0C,0x06}, /* , */
    {0x00,0x00,0x00,0x3F,0x00,0x00,0x00,0x00}, /* - */
    {0x00,0x00,0x00,0x00,0x00,0x0C,0x0C,0x00}, /* . */
    {0x60,0x30,0x18,0x0C,0x06,0x03,0x01,0x00}, /* / */
    {0x3E,0x63,0x73,0x7B,0x6F,0x67,0x3E,0x00}, /* 0 */
    {0x0C,0x0E,0x0C,0x0C,0x0C,0x0C,0x3F,0x00}, /* 1 */
    {0x1E,0x33,0x30,0x1C,0x06,0x33,0x3F,0x00}, /* 2 */
    {0x1E,0x33,0x30,0x1C,0x30,0x33,0x1E,0x00}, /* 3 */
    {0x38,0x3C,0x36,0x33,0x7F,0x30,0x78,0x00}, /* 4 */
    {0x3F,0x03,0x1F,0x30,0x30,0x33,0x1E,0x00}, /* 5 */
    {0x1C,0x06,0x03,0x1F,0x33,0x33,0x1E,0x00}, /* 6 */
    {0x3F,0x33,0x30,0x18,0x0C,0x0C,0x0C,0x00}, /* 7 */
    {0x1E,0x33,0x33,0x1E,0x33,0x33,0x1E,0x00}, /* 8 */
    {0x1E,0x33,0x33,0x3E,0x30,0x18,0x0E,0x00}, /* 9 */
    {0x00,0x0C,0x0C,0x00,0x00,0x0C,0x0C,0x00}, /* : */
    {0x00,0x0C,0x0C,0x00,0x00,0x0C,0x0C,0x06}, /* ; */
    {0x18,0x0C,0x06,0x03,0x06,0x0C,0x18,0x00}, /* < */
    {0x00,0x00,0x3F,0x00,0x00,0x3F,0x00,0x00}, /* = */
    {0x06,0x0C,0x18,0x30,0x18,0x0C,0x06,0x00}, /* > */
    {0x1E,0x33,0x30,0x18,0x0C,0x00,0x0C,0x00}, /* ? */
    {0x3E,0x63,0x7B,0x7B,0x7B,0x03,0x1E,0x00}, /* @ */
    {0x0C,0x1E,0x33,0x33,0x3F,0x33,0x33,0x00}, /* A */
    {0x3F,0x66,0x66,0x3E,0x66,0x66,0x3F,0x00}, /* B */
    {0x3C,0x66,0x03,0x03,0x03,0x66,0x3C,0x00}, /* C */
    {0x1F,0x36,0x66,0x66,0x66,0x36,0x1F,0x00}, /* D */
    {0x7F,0x06,0x06,0x3E,0x06,0x06,0x7F,0x00}, /* E */
    {0x7F,0x06,0x06,0x3E,0x06,0x06,0x06,0x00}, /* F */
    {0x3C,0x66,0x03,0x03,0x73,0x66,0x7C,0x00}, /* G */
    {0x33,0x33,0x33,0x3F,0x33,0x33,0x33,0x00}, /* H */
    {0x1E,0x0C,0x0C,0x0C,0x0C,0x0C,0x1E,0x00}, /* I */
    {0x78,0x30,0x30,0x30,0x33,0x33,0x1E,0x00}, /* J */
    {0x67,0x66,0x36,0x1E,0x36,0x66,0x67,0x00}, /* K */
    {0x06,0x06,0x06,0x06,0x06,0x06,0x7F,0x00}, /* L */
    {0x63,0x77,0x7F,0x7F,0x6B,0x63,0x63,0x00}, /* M */
    {0x63,0x67,0x6F,0x7B,0x73,0x63,0x63,0x00}, /* N */
    {0x1C,0x36,0x63,0x63,0x63,0x36,0x1C,0x00}, /* O */
    {0x3F,0x66,0x66,0x3E,0x06,0x06,0x06,0x00}, /* P */
    {0x1E,0x33,0x33,0x33,0x3B,0x1E,0x38,0x00}, /* Q */
    {0x3F,0x66,0x66,0x3E,0x36,0x66,0x67,0x00}, /* R */
    {0x1E,0x33,0x07,0x0E,0x38,0x33,0x1E,0x00}, /* S */
    {0x3F,0x2D,0x0C,0x0C,0x0C,0x0C,0x1E,0x00}, /* T */
    {0x33,0x33,0x33,0x33,0x33,0x33,0x3F,0x00}, /* U */
    {0x33,0x33,0x33,0x33,0x33,0x1E,0x0C,0x00}, /* V */
    {0x63,0x63,0x63,0x6B,0x7F,0x77,0x63,0x00}, /* W */
    {0x63,0x63,0x36,0x1C,0x1C,0x36,0x63,0x00}, /* X */
    {0x33,0x33,0x33,0x1E,0x0C,0x0C,0x1E,0x00}, /* Y */
    {0x7F,0x63,0x31,0x18,0x4C,0x66,0x7F,0x00}, /* Z */
    {0x1E,0x06,0x06,0x06,0x06,0x06,0x1E,0x00}, /* [ */
    {0x03,0x06,0x0C,0x18,0x30,0x60,0x40,0x00}, /* \ */
    {0x1E,0x18,0x18,0x18,0x18,0x18,0x1E,0x00}, /* ] */
    {0x08,0x1C,0x36,0x63,0x00,0x00,0x00,0x00}, /* ^ */
    {0x00,0x00,0x00,0x00,0x00,0x00,0x00,0xFF}, /* _ */
    {0x0C,0x0C,0x18,0x00,0x00,0x00,0x00,0x00}, /* ` */
    {0x00,0x00,0x1E,0x30,0x3E,0x33,0x6E,0x00}, /* a */
    {0x07,0x06,0x06,0x3E,0x66,0x66,0x3B,0x00}, /* b */
    {0x00,0x00,0x1E,0x33,0x03,0x33,0x1E,0x00}, /* c */
    {0x38,0x30,0x30,0x3e,0x33,0x33,0x6E,0x00}, /* d */
    {0x00,0x00,0x1E,0x33,0x3f,0x03,0x1E,0x00}, /* e */
    {0x1C,0x36,0x06,0x0f,0x06,0x06,0x0f,0x00}, /* f */
    {0x00,0x00,0x6E,0x33,0x33,0x3E,0x30,0x1F}, /* g */
    {0x07,0x06,0x36,0x6E,0x66,0x66,0x67,0x00}, /* h */
    {0x0C,0x00,0x0E,0x0C,0x0C,0x0C,0x1E,0x00}, /* i */
    {0x30,0x00,0x30,0x30,0x30,0x33,0x33,0x1E}, /* j */
    {0x07,0x06,0x66,0x36,0x1E,0x36,0x67,0x00}, /* k */
    {0x0E,0x0C,0x0C,0x0C,0x0C,0x0C,0x1E,0x00}, /* l */
    {0x00,0x00,0x33,0x7F,0x7F,0x6B,0x63,0x00}, /* m */
    {0x00,0x00,0x1F,0x33,0x33,0x33,0x33,0x00}, /* n */
    {0x00,0x00,0x1E,0x33,0x33,0x33,0x1E,0x00}, /* o */
    {0x00,0x00,0x3B,0x66,0x66,0x3E,0x06,0x0F}, /* p */
    {0x00,0x00,0x6E,0x33,0x33,0x3E,0x30,0x78}, /* q */
    {0x00,0x00,0x3B,0x6E,0x66,0x06,0x0F,0x00}, /* r */
    {0x00,0x00,0x3E,0x03,0x1E,0x30,0x1F,0x00}, /* s */
    {0x08,0x0C,0x3E,0x0C,0x0C,0x2C,0x18,0x00}, /* t */
    {0x00,0x00,0x33,0x33,0x33,0x33,0x6E,0x00}, /* u */
    {0x00,0x00,0x33,0x33,0x33,0x1E,0x0C,0x00}, /* v */
    {0x00,0x00,0x63,0x6B,0x7F,0x7F,0x36,0x00}, /* w */
    {0x00,0x00,0x63,0x36,0x1C,0x36,0x63,0x00}, /* x */
    {0x00,0x00,0x33,0x33,0x33,0x3E,0x30,0x1F}, /* y */
    {0x00,0x00,0x3F,0x19,0x0C,0x26,0x3F,0x00}, /* z */
    {0x38,0x0C,0x0C,0x07,0x0C,0x0C,0x38,0x00}, /* { */
    {0x18,0x18,0x18,0x00,0x18,0x18,0x18,0x00}, /* | */
    {0x07,0x0C,0x0C,0x38,0x0C,0x0C,0x07,0x00}, /* } */
    {0x6E,0x3B,0x00,0x00,0x00,0x00,0x00,0x00}, /* ~ */
};

/* RGB555 (PS1 direct colour: bits 0-4 R, 5-9 G, 10-14 B). */
#define C(r,g,b) ((uint16_t)(((b) << 10) | ((g) << 5) | (r)))
#define COL_PANEL   C( 1, 2, 9)
#define COL_EDGE2   C(20,26,31)
#define COL_TEXT    C(31,31,31)
#define COL_DIM     C(15,18,24)
#define COL_HEAD    C(31,26, 6)
#define COL_CURBG   C( 2,12,31)
#define COL_CURTXT  C(31,31,14)
#define COL_OKBG    C( 0,22, 6)
#define COL_OKTXT   C(31,31,31)

#define OV_MAXW 384
#define OV_MAXH 288
static uint16_t s_ov[OV_MAXW * OV_MAXH];
static uint16_t s_pack[OV_MAXW * OV_MAXH];

static void ov_fill(int x, int y, int w, int h, uint16_t col) {
    int i, j;
    for (j = 0; j < h; j++) {
        uint16_t *row;
        int yy = y + j;
        if (yy < 0 || yy >= OV_MAXH) continue;
        row = s_ov + (size_t)yy * OV_MAXW;
        for (i = 0; i < w; i++) {
            int xx = x + i;
            if (xx < 0 || xx >= OV_MAXW) continue;
            row[xx] = col;
        }
    }
}

static void ov_char(int x, int y, int ch, uint16_t col) {
    const unsigned char *g;
    int r, b;
    if (ch < 32 || ch > 126) ch = '?';
    g = kFont8x8[ch - 32];
    for (r = 0; r < 8; r++) {
        uint16_t *row;
        int yy = y + r;
        if (yy < 0 || yy >= OV_MAXH) continue;
        row = s_ov + (size_t)yy * OV_MAXW;
        for (b = 0; b < 8; b++) {
            if (g[r] & (1u << b)) {
                int xx = x + b;
                if (xx >= 0 && xx < OV_MAXW) row[xx] = col;
            }
        }
    }
}

static void ov_text(int x, int y, const char *s, uint16_t col) {
    for (; *s; s++, x += 8) ov_char(x, y, (unsigned char)*s, col);
}
static int ov_textw(const char *s) { return 8 * (int)strlen(s); }

/* PACK once (compose time): gr_vram_transfer_in needs row pitch == w. */
static int s_pack_ox, s_pack_oy, s_pack_w, s_pack_h, s_pack_valid = 0;

static void ov_pack(int ox, int oy, int w, int h) {
    int y;
    if (w > OV_MAXW) w = OV_MAXW;
    if (h > OV_MAXH) h = OV_MAXH;
    if (w <= 0 || h <= 0) { s_pack_valid = 0; return; }
    for (y = 0; y < h; y++)
        memcpy(s_pack + (size_t)y * w, s_ov + (size_t)y * OV_MAXW,
               (size_t)w * sizeof(uint16_t));
    s_pack_ox = ox;
    s_pack_oy = oy;
    s_pack_w = w;
    s_pack_h = h;
    s_pack_valid = 1;
}

/* The displayed band's origin must be read fresh every blit: the game
 * alternates the display start between its two framebuffers. */
static int ov_target(int *dx, int *dy) {
    GpuDisplayInfo di;
    if (!s_pack_valid) return 0;
    gpu_get_display_info(&di);
    if (di.disabled) return 0;
    *dx = (int)di.display_x + s_pack_ox;
    *dy = (int)di.display_y + s_pack_oy;
    return 1;
}

static void ov_blit(void) {
    int dx, dy;
    if (!ov_target(&dx, &dy)) return;
    gr_vram_transfer_in(dx, dy, s_pack_w, s_pack_h, s_pack);
    if (gr_backend() == GR_BACKEND_OPENGL) gl_renderer_flush_cpu_uploads();
}

/* ==========================================================================
 * The modal SAVE ANYWHERE panel.
 * ======================================================================== */
#define OV_LINE 10
#define OV_PADX 6
#define OV_PADY 5
#define OV_MARGIN 8

static int s_ov_w, s_ov_h;

static int ov_build_modal(int w, int h) {
    char line[96];
    int y;
    const char *rows[ROW_COUNT] = { "SAVE GAME", "CANCEL" };
    int i;
    int n = (int)(sizeof rows / sizeof rows[0]);

    ov_fill(0, 0, w, h, COL_PANEL);
    ov_fill(0, 0, w, 2, COL_EDGE2);
    ov_fill(0, h - 2, w, 2, COL_EDGE2);
    ov_fill(0, 0, 2, h, COL_EDGE2);
    ov_fill(w - 2, 0, 2, h, COL_EDGE2);

    y = OV_PADY;
    ov_text(OV_PADX, y, "SAVE ANYWHERE", COL_HEAD);
    sprintf(line, "%d/%d", s_row + 1, n);
    ov_text(w - OV_PADX - ov_textw(line), y, line, COL_TEXT);
    y += OV_LINE;
    sprintf(line, "Region: %s", s_reg->name);
    ov_text(OV_PADX, y, line, COL_DIM);
    y += OV_LINE;

    ov_text(OV_PADX, y, "Opens the game's own memory-card", COL_TEXT);
    y += OV_LINE;
    ov_text(OV_PADX, y, "save screen. Your game is written", COL_TEXT);
    y += OV_LINE;
    ov_text(OV_PADX, y, "by the game itself - no state is", COL_TEXT);
    y += OV_LINE;
    ov_text(OV_PADX, y, "re-created or re-formatted here.", COL_TEXT);
    y += OV_LINE * 2;

    for (i = 0; i < n; i++) {
        if (i == s_row) {
            ov_fill(OV_PADX - 3, y - 1, w - 2 * (OV_PADX - 3), OV_LINE, COL_CURBG);
            sprintf(line, "> %s", rows[i]);
            ov_text(OV_PADX, y, line, COL_CURTXT);
        } else {
            sprintf(line, "   %s", rows[i]);
            ov_text(OV_PADX, y, line, COL_TEXT);
        }
        y += OV_LINE;
    }

    y = h - OV_PADY - OV_LINE * 2;
    ov_text(OV_PADX, y, "D-PAD move   TRI/START exit", COL_DIM);
    y += OV_LINE;
    ov_text(OV_PADX, y, "CROSS/X = confirm", COL_TEXT);

    if (w > s_ov_w) s_ov_w = w;
    if (h > s_ov_h) s_ov_h = h;
    return h;
}

/* The green confirmation strip shown for a couple of seconds after a confirm. */
static void ov_build_confirm(int oy, const char *msg) {
    char line[96];
    int w, h;
    sprintf(line, "%s", msg);
    w = OV_PADX * 2 + ov_textw(line);
    if (w > OV_MAXW) w = OV_MAXW;
    h = OV_PADY * 2 + 8;
    ov_fill(0, oy, w, h, COL_OKBG);
    ov_fill(0, oy, w, 2, COL_EDGE2);
    ov_fill(0, oy + h - 2, w, 2, COL_EDGE2);
    ov_text(OV_PADX, oy + OV_PADY, line, COL_OKTXT);
    if (w > s_ov_w) s_ov_w = w;
    if (oy + h > s_ov_h) s_ov_h = oy + h;
}

static void ov_modal_size(int *w, int *h) {
    GpuDisplayInfo di;
    gpu_get_display_info(&di);
    *w = (di.disabled ? 320 : (int)di.width) - 2 * OV_MARGIN;
    *h = (di.disabled ? 240 : (int)di.height) - 2 * OV_MARGIN;
    if (*w < 160) *w = 304;
    if (*h < 120) *h = 224;
    if (*w > OV_MAXW) *w = OV_MAXW;
    if (*h > OV_MAXH) *h = OV_MAXH;
}

/* Compose on content change; blit the cached packed panel EVERY vblank. */
static unsigned s_present_sig = 0;
static unsigned s_frame = 0;
static unsigned s_confirm_at = 0;
#define CONFIRM_FRAMES 120u          /* ~2 s at 60 Hz */

static void ov_tick(int modal_open) {
    int confirming = (s_confirm_at != 0u) &&
                     (s_frame - s_confirm_at < CONFIRM_FRAMES);
    unsigned sig;
    int w = 0, h = 0;

    if (!modal_open && !confirming) {
        s_present_sig = 0;
        s_pack_valid = 0;
        return;
    }

    if (modal_open) {
        ov_modal_size(&w, &h);
        sig = 0x5A000000u ^ ((unsigned)s_row * 0x9E3779B1u)
                          ^ ((unsigned)w * 0x85EBCA6Bu)
                          ^ ((unsigned)h * 0xC2B2AE35u);
    } else {
        sig = 0xC0000000u ^ 0x5A5A5A5Au;
    }

    if (sig != s_present_sig) {
        s_present_sig = sig;
        s_ov_w = 0;
        s_ov_h = 0;
        if (modal_open) {
            ov_build_modal(w, h);
        } else {
            ov_build_confirm(OV_MARGIN, s_confirm_msg);
        }
        if (s_ov_w > 0 && s_ov_h > 0)
            ov_pack(OV_MARGIN, OV_MARGIN, s_ov_w, s_ov_h);
    }
    if (s_pack_valid) ov_blit();
}

/* ==========================================================================
 * Guest-side helpers.
 * ======================================================================== */
static uint32_t save_find_field_task(void) {
    uint32_t i;
    for (i = 0; i < TASK_MAX; i++) {
        uint32_t t = psx_mod_read_word(TASK_REGISTRY + i * 4u);
        if (t == 0u) continue;
        if ((int)psx_mod_read_word(t + T_OFF_ID) == FIELD_TASK_FIELD)
            return t;
    }
    return 0u;
}

static int save_in_field(void) {
    int mode = (int)psx_mod_read_word(GAME_MODE);
    return (mode & 0xFF00) == FIELDSTG_MODE_BASE;
}

/* The field is idle: no menu, event, talk, warp or battle owns the player. */
static int save_field_idle(void) {
    if ((int)psx_mod_read_word(FIELDSTG_INNOPEN) != 0) return 0;
    if ((int)psx_mod_read_word(FIELDSTG_BUSY)    != 0) return 0;
    if ((int)psx_mod_read_word(FIELDSTG_ACTING)  != 0) return 0;
    if ((int)psx_mod_read_word(FIELDSTG_BATTLE)  != 0) return 0;
    return 1;
}

/*
 * The game-side piece: drive the field task into its leave/close transition
 * exactly as FIELDSTG_leaveFieldAfter() does, so the game's own field code
 * requests the memory-card SAVE mode (0xC00 with a negative argument).
 */
static void save_begin(void) {
    uint32_t task = save_find_field_task();
    if (task == 0u) {
        fprintf(stderr, "save-anywhere: no field task - not in the field; "
                        "nothing to trigger\n");
        return;
    }
    {
        int state    = (int)psx_mod_read_word(task + T_OFF_STATE);
        int substate = (int)psx_mod_read_word(task + T_OFF_SUBSTATE);
        psx_mod_write_word(task + T_OFF_NEXTMODE,   (uint32_t)MODE_CONTINUE);
        psx_mod_write_word(task + T_OFF_NEXTARG,    MODE_CONTINUE_SAVE);
        psx_mod_write_word(task + T_OFF_LEAVEDELAY, 0u);
        psx_mod_write_word(task + T_OFF_STATE,      (uint32_t)TASK_DONE);
        psx_mod_write_word(task + T_OFF_SUBSTATE,   0u);
        psx_mod_write_word(SAVE_MARKER_ADDR, SAVE_MARKER_VALUE);
        fprintf(stderr,
                "save-anywhere: field transition -> mode=0x%X arg=0x%08X "
                "(SAVE) task=0x%08X state %d->%d substate %d->0\n",
                (unsigned)MODE_CONTINUE, (unsigned)MODE_CONTINUE_SAVE,
                (unsigned)task, state, TASK_DONE, substate);
    }
}

/* ==========================================================================
 * Panel input helpers.
 * ======================================================================== */
#define JUST_PRESSED(p, m) (((s_prev_pad & (m)) != 0) && (((p) & (m)) == 0))
#define IS_DOWN(p, m)      (((p) & (m)) == 0)

/* Region self-test: LAZY and evidence-driven - never a boot-time verdict. */
static void save_region_validate(void) {
    uint32_t i, live = 0, bad = 0;
    if (s_region_checked || s_disabled) return;
    if (!psx_mod_game_started()) return;
    if ((s_frame % 30u) != 0u) return;

    for (i = 0; i < TASK_MAX; i++) {
        uint32_t t = psx_mod_read_word(TASK_REGISTRY + i * 4u);
        if (t == 0u) continue;
        live++;
        if (t < 0x80000000u || t >= 0x80200000u) { bad++; continue; }
        if (psx_mod_read_word(t + T_OFF_ID) > 0x40u) bad++;
    }
    if (bad != 0u) {
        s_region_checked = 1;
        s_disabled = 1;
        fprintf(stderr,
                "save-anywhere: REGION SELF-TEST FAILED for %s - TASK_REGISTRY "
                "0x%08X holds %u live entries, %u of which are not valid task "
                "pointers/ids for this region. DISABLING the mod: no panel, no "
                "save writes. Is this build using the wrong region table?\n",
                s_reg->name, (unsigned)TASK_REGISTRY, (unsigned)live, (unsigned)bad);
        return;
    }
    if (live == 0u)
        return;   /* normal: the game has not created its tasks yet */

    s_region_checked = 1;
    fprintf(stderr,
            "save-anywhere: region OK - %s (GAME 0x%08X mode@+0x%X next@+0x%X "
            "modeArg 0x%08X, FIELDSTG_state 0x%08X, TASK_REGISTRY 0x%08X with %u "
            "live tasks)\n",
            s_reg->name, (unsigned)GAME_BASE, (unsigned)s_reg->game_off_mode,
            (unsigned)s_reg->game_off_next, (unsigned)GAME_MODEARG,
            (unsigned)FIELDSTG_STATE, (unsigned)TASK_REGISTRY, (unsigned)live);
}

static void save_read_options(void) {
    char buf[32];
    const char *env;
    if (psx_mod_option_value(PKG_ID, FEATURE_ID, "boot_mode", buf, sizeof buf))
        s_boot_mode = (int)strtol(buf, NULL, 0);
    env = getenv("DW3_SAVE_BOOT");  if (env && *env) s_boot_mode = (int)strtol(env, NULL, 0);
    env = getenv("DW3_SAVE_LOAD");  if (env && *env && env[0] != '0') s_boot_load = 1;
    env = getenv("DW3_SAVE_SHOW");  if (env && *env && env[0] != '0') s_force_show = 1;
    env = getenv("DW3_SAVE_TRIG");  if (env && *env && env[0] != '0') s_auto_trig = 1;
    env = getenv("DW3_SAVE_ROW");   if (env && *env) s_auto_row = (int)strtol(env, NULL, 0);
    fprintf(stderr,
            "save-anywhere: active for %s (%s); open with SELECT+SQUARE in the "
            "field; boot=%s load=%s show=%s trig=%s\n",
            s_reg->name, s_reg->serial, s_boot_mode ? "on" : "off",
            s_boot_load ? "on" : "off", s_force_show ? "on" : "off",
            s_auto_trig ? "on" : "off");
}

static void modal_open(void) {
    s_modal_saved_inn = (int)psx_mod_read_word(FIELDSTG_INNOPEN);
    psx_mod_write_word(FIELDSTG_INNOPEN, 1u);   /* freeze the field */
    s_modal = 1;
    s_row = ROW_SAVE;
    s_open_count++;
    fprintf(stderr, "save-anywhere: panel opened (innOpen %d->1)\n",
            s_modal_saved_inn);
}

static void modal_close(const char *why) {
    psx_mod_write_word(FIELDSTG_INNOPEN, (uint32_t)s_modal_saved_inn);
    s_modal = 0;
    fprintf(stderr, "save-anywhere: panel closed (%s); innOpen restored to %d\n",
            why ? why : "exit", s_modal_saved_inn);
}

/* confirm the highlighted row */
static void modal_confirm(void) {
    if (s_row == ROW_SAVE) {
        s_confirm_count++;
        s_confirm_msg = "OPENING SAVE SCREEN";
        modal_close("confirm save");
        save_begin();
        s_confirm_at = s_frame;
    } else {
        modal_close("cancel");
    }
}

static void save_vblank(void) {
    uint16_t pad;
    int modal_now = 0;
    int in_field, idle;

    if (!psx_mod_game_started()) return;
    s_frame++;
    pad = sio_get_pad_buttons();

    save_region_validate();
    if (s_disabled) return;

    /* dev aid: boot-jump into a field stage (repeat until GAME.mode is live) */
    if (s_boot_mode != 0 && !s_booted &&
        (int)psx_mod_read_word(GAME_MODE) != 0) {
        s_booted = 1;
        fprintf(stderr, "save-anywhere: boot jump -> field mode=0x%X\n",
                (unsigned)s_boot_mode);
        psx_mod_write_word(GAME_NEXTMODE, (uint32_t)s_boot_mode);
        psx_mod_write_word(GAME_MODEARG, 0u);
        psx_mod_write_word(ROOT_TASK, 0u);
    }

    /* dev aid: boot straight into the game's own LOAD screen (0xC00, arg 0) */
    if (s_boot_load && !s_boot_loaded &&
        (int)psx_mod_read_word(GAME_MODE) != 0) {
        s_boot_loaded = 1;
        fprintf(stderr, "save-anywhere: boot jump -> LOAD screen (0xC00, arg 0)\n");
        psx_mod_write_word(GAME_NEXTMODE, (uint32_t)MODE_CONTINUE);
        psx_mod_write_word(GAME_MODEARG, 0u);
        psx_mod_write_word(ROOT_TASK, 0u);
    }

    in_field = save_in_field();
    idle = in_field && save_field_idle();

    if (s_modal && !in_field) modal_close("left the field");

    if (s_modal) {
        modal_now = 1;
        psx_mod_write_word(FIELDSTG_INNOPEN, 1u);  /* keep the field frozen */

        if (!s_auto_trig) {
            if (JUST_PRESSED(pad, PSX_PAD_UP) || JUST_PRESSED(pad, PSX_PAD_DOWN)) {
                s_row = (s_row == ROW_SAVE) ? ROW_CANCEL : ROW_SAVE;
                fprintf(stderr, "save-anywhere: row %d\n", s_row);
            }
            if (JUST_PRESSED(pad, PSX_PAD_TRIANGLE) || JUST_PRESSED(pad, PSX_PAD_START)) {
                modal_close("exit control");
            } else if (JUST_PRESSED(pad, PSX_PAD_CROSS)) {
                modal_confirm();
            }
        } else if (s_frame % 45u == 0u) {
            /* dev auto-trigger: act after ~2 s of the panel being up */
            s_row = s_auto_row;
            modal_confirm();
        }
    }

    /* Open the panel: SELECT held + SQUARE pressed - the free combo (see the
     * header). Requires an idle field that actually has a live field task. */
    if (!s_modal && idle) {
        int sel_sq_now  = IS_DOWN(pad, PSX_PAD_SELECT) && IS_DOWN(pad, PSX_PAD_SQUARE);
        int sel_sq_prev = IS_DOWN(s_prev_pad, PSX_PAD_SELECT) && IS_DOWN(s_prev_pad, PSX_PAD_SQUARE);
        if (sel_sq_now && !sel_sq_prev && save_find_field_task() != 0u) modal_open();
    }

    if (s_force_show) modal_now = 1;

    ov_tick(modal_now);
    s_prev_pad = pad;
}

static void save_activate(void) { save_read_options(); }

PSX_MOD_CONSTRUCTOR(save_anywhere_register) {
    fprintf(stderr, "save-anywhere: registering plugins\n");
    psx_mod_register_activation_plugin("dev.save-anywhere", save_activate);
    psx_mod_register_vblank_plugin("dev.save-anywhere", save_vblank);
}
