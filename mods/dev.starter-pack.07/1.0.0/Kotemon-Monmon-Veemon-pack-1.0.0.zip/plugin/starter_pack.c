/*
 * dev.starter-pack.NN  --  custom new-game starter teams for Digimon World 3 / 2003.
 *
 * One plugin design that can express ANY of the 53 starting teams of three the
 * game does not already offer.  The pool of starter-eligible Digimon is 8
 * (PARTNER_COUNT, include/dw3/game_state.h), so 8C3 = 56 teams; the game ships
 * only 3 of them, leaving 53.
 *
 * SLOT MODEL (one enabled pack per slot)
 *   The registration screen shows exactly THREE choices.  Each ENABLED starter
 *   pack fills exactly ONE of them; a choice with no pack enabled keeps the
 *   game's own original team, name and description.
 *
 *   The enabled packages are enumerated, sorted by ascending package id
 *   (dev.starter-pack.00 .. .52), and the first three take slots 0, 1, 2 in
 *   that order.  The mapping is a strictly increasing injection, so no two
 *   enabled packs can ever resolve to the same slot - collision-free BY
 *   CONSTRUCTION, not by an if-check that could be got wrong.  The same state
 *   file always yields the same slot layout (deterministic), and turning a
 *   FOURTH pack on does not move the three already placed: the extras, being
 *   higher ids than the three lowest, are ignored (three slots only) and the
 *   plugin logs exactly that.
 *
 *   A slot is written only by the pack that owns it, so UNCOVERED slots are
 *   never touched: their original team (STARTER_PARTIES row), original shown
 *   team (STPLNMET_partnerChoices row) and original NAMEET name/description
 *   survive untouched.
 *
 * MECHANISM (verified against the real disc images; addresses below)
 *   The registration screen (STPLNMET, game mode 0x500) calls
 *       GAME.funcs.setParty(choice)                    (src/stplnmet/screen.c:105)
 *   and setParty writes
 *       GAME.party[i] = STARTER_PARTIES[choice][i]     (src/main/game/party.c:50)
 *   while the three selectable packs are shown from
 *       STPLNMET_funcs.choices[choice][i] == STPLNMET_partnerChoices[choice][i]
 *   (src/stplnmet/choice.c:36,44,65,74,83).  Writing BOTH tables for a slot
 *   makes the screen show that slot's team and grant that exact team.
 *
 *   STARTER_PARTIES is main-EXE .data and always resident, so it is written each
 *   vblank (cheap, idempotent; also re-applied after a savestate reload).
 *   STPLNMET_partnerChoices is in the STPLNMET overlay, which shares RAM with
 *   every other overlay, so it is written ONLY while GAME.mode is the STPLNMET
 *   mode 0x500 - at any other time that address belongs to a different overlay
 *   and writing it would corrupt it.
 *
 *   The pack NAME / DESCRIPTION a slot prints come from strings 10-12 and 26-28
 *   of the NAMEET text file (src/stplnmet/choice.c:41-42).  That text is a
 *   FILE_CACHE heap buffer, so its address is found by content signature
 *   (find_nameet) and one name string and one description string are rewritten
 *   in place, one per covered slot.  The replacement text is emitted as
 *   FONT_GLYPH_MAP indices - the game's own font encoding, decoded with
 *   convertText(mode 0) - and every glyph used was checked to exist in the font
 *   before it was written (the generator raises on any character with no glyph).
 *
 * REGIONS  Europe (SLES-03936) and USA (SLUS-01436) are different binaries; the
 *   address table is chosen by the BUILD (-DDW3_GAME_REGION_EU / _US) and a
 *   missing define is a #error.  The self-test is lazy and evidence-driven: once
 *   the guest has started it checks STARTER_PARTIES still holds a plausible
 *   starter table (nine partner indices in 0..7, no repeats in a row) and, if
 *   not, disables itself loudly rather than writing through a bad table.
 *
 * Evidence for the addresses (config/eu|us/symbols*.txt; the nine
 * STARTER_PARTIES bytes were read straight out of both EXE images and are
 * 00 06 07 02 03 06 01 05 07 in each):
 *   STARTER_PARTIES          EU 0x8004B490   US 0x8004AC38
 *   STPLNMET_partnerChoices  EU 0x80089B6C   US 0x80089034
 *   FILE_CACHE               EU 0x80044B38   US 0x80044744
 *   GAME / GameState.mode    EU 0x80048D34/+0x26C4   US 0x800484E8/+0x26BC
 *   main.c ROOT_TASK         EU 0x8005CCBC   US 0x8005C458
 */

#include "mod_plugins.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

typedef struct StarterRegion {
    const char *name;
    const char *serial;
    uint32_t starter_parties;  /* u8[3][3], main-EXE .data    */
    uint32_t partner_choices;  /* s32[3][3], STPLNMET overlay */
    uint32_t file_cache;       /* FileCache                   */
    uint32_t game;             /* GAME base                   */
    uint32_t game_off_mode;    /* GameState.mode offset       */
    uint32_t root_task;        /* main.c ROOT_TASK            */
} StarterRegion;

static const StarterRegion kRegions[] = {
    { "Europe (SLES-03936)", "SLES-03936",
      0x8004B490u, 0x80089B6Cu, 0x80044B38u, 0x80048D34u, 0x26C4u, 0x8005CCBCu },
    { "USA (SLUS-01436)", "SLUS-01436",
      0x8004AC38u, 0x80089034u, 0x80044744u, 0x800484E8u, 0x26BCu, 0x8005C458u },
};
#if defined(DW3_GAME_REGION_US)
#define STARTER_REGION_INDEX 1
#elif defined(DW3_GAME_REGION_EU)
#define STARTER_REGION_INDEX 0
#else
#error "starter_pack.c: define DW3_GAME_REGION_EU or DW3_GAME_REGION_US for this build."
#endif
static const StarterRegion *s_reg = &kRegions[STARTER_REGION_INDEX];

#define STARTER_PARTIES  (s_reg->starter_parties)
#define PARTNER_CHOICES  (s_reg->partner_choices)
#define FILE_CACHE_BASE  (s_reg->file_cache)
#define GAME_MODE        (s_reg->game + s_reg->game_off_mode)
#define GAME_NEXTMODE    (GAME_MODE + 4u)
#define GAME_MODEARG     (GAME_MODE + 0x0Cu)
#define ROOT_TASK        (s_reg->root_task)

#define STPLNMET_MODE    0x500u          /* the registration / partner screen */
#define MODE_BAND_MASK   0xFFFFFF00u
#define PARTY_ROWS       3u              /* the three slots the screen offers */
#define PARTY_COLS       3u
#define PACK_COUNT       53

/* FileCache / FileSlot (include/dw3/file.h) */
#define CACHE_SLOTS      64u
#define SLOT_STRIDE      0x10u
#define SLOT_OFF_STATE   0x0u
#define SLOT_OFF_DATA    0xCu
#define FILE_LOADED      3

/* NAMEET string indices (src/stplnmet/choice.c) */
#define NAMEET_COUNT     31u
#define IDX_NAME0        10u
#define IDX_DESC0        26u

/* =====================================================================
 * The 53 teams, and each team's in-game pack name / description.
 * The byte arrays are FONT_GLYPH_MAP indices produced from the game's own
 * text (ASCII letters/digits are single-byte glyphs; a space is the two-byte
 * icon pair 01 01), verified glyph-by-glyph (the generator raises on any
 * character with no glyph) and sized against the measured NAMEET slot
 * capacities (name 15 bytes, description 71+ bytes).  Every one of the 53
 * names fits the 15-byte in-game name slot; the longest is 14 bytes including
 * the terminator.
 * =================================================================== */
static const uint8_t kTeams[53][3] = {
    { 0, 1, 2 },  /* Kotemon + Kumamon + Monmon */
    { 0, 1, 3 },  /* Kotemon + Kumamon + Agumon */
    { 0, 1, 4 },  /* Kotemon + Kumamon + Veemon */
    { 0, 1, 5 },  /* Kotemon + Kumamon + Guilmon */
    { 0, 1, 6 },  /* Kotemon + Kumamon + Renamon */
    { 0, 1, 7 },  /* Kotemon + Kumamon + Patamon */
    { 0, 2, 3 },  /* Kotemon + Monmon + Agumon */
    { 0, 2, 4 },  /* Kotemon + Monmon + Veemon */
    { 0, 2, 5 },  /* Kotemon + Monmon + Guilmon */
    { 0, 2, 6 },  /* Kotemon + Monmon + Renamon */
    { 0, 2, 7 },  /* Kotemon + Monmon + Patamon */
    { 0, 3, 4 },  /* Kotemon + Agumon + Veemon */
    { 0, 3, 5 },  /* Kotemon + Agumon + Guilmon */
    { 0, 3, 6 },  /* Kotemon + Agumon + Renamon */
    { 0, 3, 7 },  /* Kotemon + Agumon + Patamon */
    { 0, 4, 5 },  /* Kotemon + Veemon + Guilmon */
    { 0, 4, 6 },  /* Kotemon + Veemon + Renamon */
    { 0, 4, 7 },  /* Kotemon + Veemon + Patamon */
    { 0, 5, 6 },  /* Kotemon + Guilmon + Renamon */
    { 0, 5, 7 },  /* Kotemon + Guilmon + Patamon */
    { 1, 2, 3 },  /* Kumamon + Monmon + Agumon */
    { 1, 2, 4 },  /* Kumamon + Monmon + Veemon */
    { 1, 2, 5 },  /* Kumamon + Monmon + Guilmon */
    { 1, 2, 6 },  /* Kumamon + Monmon + Renamon */
    { 1, 2, 7 },  /* Kumamon + Monmon + Patamon */
    { 1, 3, 4 },  /* Kumamon + Agumon + Veemon */
    { 1, 3, 5 },  /* Kumamon + Agumon + Guilmon */
    { 1, 3, 6 },  /* Kumamon + Agumon + Renamon */
    { 1, 3, 7 },  /* Kumamon + Agumon + Patamon */
    { 1, 4, 5 },  /* Kumamon + Veemon + Guilmon */
    { 1, 4, 6 },  /* Kumamon + Veemon + Renamon */
    { 1, 4, 7 },  /* Kumamon + Veemon + Patamon */
    { 1, 5, 6 },  /* Kumamon + Guilmon + Renamon */
    { 1, 6, 7 },  /* Kumamon + Renamon + Patamon */
    { 2, 3, 4 },  /* Monmon + Agumon + Veemon */
    { 2, 3, 5 },  /* Monmon + Agumon + Guilmon */
    { 2, 3, 7 },  /* Monmon + Agumon + Patamon */
    { 2, 4, 5 },  /* Monmon + Veemon + Guilmon */
    { 2, 4, 6 },  /* Monmon + Veemon + Renamon */
    { 2, 4, 7 },  /* Monmon + Veemon + Patamon */
    { 2, 5, 6 },  /* Monmon + Guilmon + Renamon */
    { 2, 5, 7 },  /* Monmon + Guilmon + Patamon */
    { 2, 6, 7 },  /* Monmon + Renamon + Patamon */
    { 3, 4, 5 },  /* Agumon + Veemon + Guilmon */
    { 3, 4, 6 },  /* Agumon + Veemon + Renamon */
    { 3, 4, 7 },  /* Agumon + Veemon + Patamon */
    { 3, 5, 6 },  /* Agumon + Guilmon + Renamon */
    { 3, 5, 7 },  /* Agumon + Guilmon + Patamon */
    { 3, 6, 7 },  /* Agumon + Renamon + Patamon */
    { 4, 5, 6 },  /* Veemon + Guilmon + Renamon */
    { 4, 5, 7 },  /* Veemon + Guilmon + Patamon */
    { 4, 6, 7 },  /* Veemon + Renamon + Patamon */
    { 5, 6, 7 },  /* Guilmon + Renamon + Patamon */
};

static const uint8_t kPackName[53][15] = {
    { 0x20, 0x37, 0x2C, 0x2A, 0x30, 0x28, 0x33, 0x01, 0x01, 0x1D, 0x28, 0x2A, 0x32, 0x00 },
    { 0x20, 0x37, 0x2C, 0x2A, 0x30, 0x28, 0x33, 0x01, 0x01, 0x1D, 0x28, 0x2A, 0x32, 0x00 },
    { 0x20, 0x37, 0x2C, 0x2A, 0x30, 0x28, 0x33, 0x01, 0x01, 0x1D, 0x28, 0x2A, 0x32, 0x00 },
    { 0x20, 0x37, 0x2C, 0x2A, 0x30, 0x28, 0x33, 0x01, 0x01, 0x1D, 0x28, 0x2A, 0x32, 0x00 },
    { 0x20, 0x37, 0x2C, 0x2A, 0x30, 0x28, 0x33, 0x01, 0x01, 0x1D, 0x28, 0x2A, 0x32, 0x00 },
    { 0x20, 0x37, 0x2C, 0x2A, 0x30, 0x28, 0x33, 0x01, 0x01, 0x1D, 0x28, 0x2A, 0x32, 0x00 },
    { 0x20, 0x37, 0x2C, 0x2A, 0x30, 0x28, 0x33, 0x01, 0x01, 0x1D, 0x28, 0x2A, 0x32, 0x00 },
    { 0x20, 0x37, 0x2C, 0x2A, 0x30, 0x28, 0x33, 0x01, 0x01, 0x1D, 0x28, 0x2A, 0x32, 0x00 },
    { 0x20, 0x37, 0x2C, 0x2A, 0x30, 0x28, 0x33, 0x01, 0x01, 0x1D, 0x28, 0x2A, 0x32, 0x00 },
    { 0x20, 0x37, 0x2C, 0x2A, 0x30, 0x28, 0x33, 0x01, 0x01, 0x1D, 0x28, 0x2A, 0x32, 0x00 },
    { 0x20, 0x37, 0x2C, 0x2A, 0x30, 0x28, 0x33, 0x01, 0x01, 0x1D, 0x28, 0x2A, 0x32, 0x00 },
    { 0x20, 0x37, 0x2C, 0x2A, 0x30, 0x28, 0x33, 0x01, 0x01, 0x1D, 0x28, 0x2A, 0x32, 0x00 },
    { 0x20, 0x37, 0x2C, 0x2A, 0x30, 0x28, 0x33, 0x01, 0x01, 0x1D, 0x28, 0x2A, 0x32, 0x00 },
    { 0x20, 0x37, 0x2C, 0x2A, 0x30, 0x28, 0x33, 0x01, 0x01, 0x1D, 0x28, 0x2A, 0x32, 0x00 },
    { 0x20, 0x37, 0x2C, 0x2A, 0x30, 0x28, 0x33, 0x01, 0x01, 0x1D, 0x28, 0x2A, 0x32, 0x00 },
    { 0x20, 0x37, 0x2C, 0x2A, 0x30, 0x28, 0x33, 0x01, 0x01, 0x1D, 0x28, 0x2A, 0x32, 0x00 },
    { 0x20, 0x37, 0x2C, 0x2A, 0x30, 0x28, 0x33, 0x01, 0x01, 0x1D, 0x28, 0x2A, 0x32, 0x00 },
    { 0x20, 0x37, 0x2C, 0x2A, 0x30, 0x28, 0x33, 0x01, 0x01, 0x1D, 0x28, 0x2A, 0x32, 0x00 },
    { 0x20, 0x37, 0x2C, 0x2A, 0x30, 0x28, 0x33, 0x01, 0x01, 0x1D, 0x28, 0x2A, 0x32, 0x00 },
    { 0x20, 0x37, 0x2C, 0x2A, 0x30, 0x28, 0x33, 0x01, 0x01, 0x1D, 0x28, 0x2A, 0x32, 0x00 },
    { 0x20, 0x37, 0x2C, 0x2A, 0x30, 0x28, 0x33, 0x01, 0x01, 0x1D, 0x28, 0x2A, 0x32, 0x00 },
    { 0x20, 0x37, 0x2C, 0x2A, 0x30, 0x28, 0x33, 0x01, 0x01, 0x1D, 0x28, 0x2A, 0x32, 0x00 },
    { 0x20, 0x37, 0x2C, 0x2A, 0x30, 0x28, 0x33, 0x01, 0x01, 0x1D, 0x28, 0x2A, 0x32, 0x00 },
    { 0x20, 0x37, 0x2C, 0x2A, 0x30, 0x28, 0x33, 0x01, 0x01, 0x1D, 0x28, 0x2A, 0x32, 0x00 },
    { 0x20, 0x37, 0x2C, 0x2A, 0x30, 0x28, 0x33, 0x01, 0x01, 0x1D, 0x28, 0x2A, 0x32, 0x00 },
    { 0x20, 0x37, 0x2C, 0x2A, 0x30, 0x28, 0x33, 0x01, 0x01, 0x1D, 0x28, 0x2A, 0x32, 0x00 },
    { 0x20, 0x37, 0x2C, 0x2A, 0x30, 0x28, 0x33, 0x01, 0x01, 0x1D, 0x28, 0x2A, 0x32, 0x00 },
    { 0x20, 0x37, 0x2C, 0x2A, 0x30, 0x28, 0x33, 0x01, 0x01, 0x1D, 0x28, 0x2A, 0x32, 0x00 },
    { 0x20, 0x37, 0x2C, 0x2A, 0x30, 0x28, 0x33, 0x01, 0x01, 0x1D, 0x28, 0x2A, 0x32, 0x00 },
    { 0x20, 0x37, 0x2C, 0x2A, 0x30, 0x28, 0x33, 0x01, 0x01, 0x1D, 0x28, 0x2A, 0x32, 0x00 },
    { 0x20, 0x37, 0x2C, 0x2A, 0x30, 0x28, 0x33, 0x01, 0x01, 0x1D, 0x28, 0x2A, 0x32, 0x00 },
    { 0x20, 0x37, 0x2C, 0x2A, 0x30, 0x28, 0x33, 0x01, 0x01, 0x1D, 0x28, 0x2A, 0x32, 0x00 },
    { 0x20, 0x37, 0x2C, 0x2A, 0x30, 0x28, 0x33, 0x01, 0x01, 0x1D, 0x28, 0x2A, 0x32, 0x00 },
    { 0x20, 0x37, 0x2C, 0x2A, 0x30, 0x28, 0x33, 0x01, 0x01, 0x1D, 0x28, 0x2A, 0x32, 0x00 },
    { 0x20, 0x37, 0x2C, 0x2A, 0x30, 0x28, 0x33, 0x01, 0x01, 0x1D, 0x28, 0x2A, 0x32, 0x00 },
    { 0x20, 0x37, 0x2C, 0x2A, 0x30, 0x28, 0x33, 0x01, 0x01, 0x1D, 0x28, 0x2A, 0x32, 0x00 },
    { 0x20, 0x37, 0x2C, 0x2A, 0x30, 0x28, 0x33, 0x01, 0x01, 0x1D, 0x28, 0x2A, 0x32, 0x00 },
    { 0x20, 0x37, 0x2C, 0x2A, 0x30, 0x28, 0x33, 0x01, 0x01, 0x1D, 0x28, 0x2A, 0x32, 0x00 },
    { 0x20, 0x37, 0x2C, 0x2A, 0x30, 0x28, 0x33, 0x01, 0x01, 0x1D, 0x28, 0x2A, 0x32, 0x00 },
    { 0x20, 0x37, 0x2C, 0x2A, 0x30, 0x28, 0x33, 0x01, 0x01, 0x1D, 0x28, 0x2A, 0x32, 0x00 },
    { 0x20, 0x37, 0x2C, 0x2A, 0x30, 0x28, 0x33, 0x01, 0x01, 0x1D, 0x28, 0x2A, 0x32, 0x00 },
    { 0x20, 0x37, 0x2C, 0x2A, 0x30, 0x28, 0x33, 0x01, 0x01, 0x1D, 0x28, 0x2A, 0x32, 0x00 },
    { 0x20, 0x37, 0x2C, 0x2A, 0x30, 0x28, 0x33, 0x01, 0x01, 0x1D, 0x28, 0x2A, 0x32, 0x00 },
    { 0x20, 0x37, 0x2C, 0x2A, 0x30, 0x28, 0x33, 0x01, 0x01, 0x1D, 0x28, 0x2A, 0x32, 0x00 },
    { 0x20, 0x37, 0x2C, 0x2A, 0x30, 0x28, 0x33, 0x01, 0x01, 0x1D, 0x28, 0x2A, 0x32, 0x00 },
    { 0x20, 0x37, 0x2C, 0x2A, 0x30, 0x28, 0x33, 0x01, 0x01, 0x1D, 0x28, 0x2A, 0x32, 0x00 },
    { 0x20, 0x37, 0x2C, 0x2A, 0x30, 0x28, 0x33, 0x01, 0x01, 0x1D, 0x28, 0x2A, 0x32, 0x00 },
    { 0x20, 0x37, 0x2C, 0x2A, 0x30, 0x28, 0x33, 0x01, 0x01, 0x1D, 0x28, 0x2A, 0x32, 0x00 },
    { 0x20, 0x37, 0x2C, 0x2A, 0x30, 0x28, 0x33, 0x01, 0x01, 0x1D, 0x28, 0x2A, 0x32, 0x00 },
    { 0x20, 0x37, 0x2C, 0x2A, 0x30, 0x28, 0x33, 0x01, 0x01, 0x1D, 0x28, 0x2A, 0x32, 0x00 },
    { 0x20, 0x37, 0x2C, 0x2A, 0x30, 0x28, 0x33, 0x01, 0x01, 0x1D, 0x28, 0x2A, 0x32, 0x00 },
    { 0x20, 0x37, 0x2C, 0x2A, 0x30, 0x28, 0x33, 0x01, 0x01, 0x1D, 0x28, 0x2A, 0x32, 0x00 },
    { 0x20, 0x37, 0x2C, 0x2A, 0x30, 0x28, 0x33, 0x01, 0x01, 0x1D, 0x28, 0x2A, 0x32, 0x00 },
};

static const uint8_t kPackDesc[53][72] = {
    { 0x18, 0x36, 0x3B, 0x2C, 0x34, 0x36, 0x35, 0x01, 0x01, 0x18, 0x3C, 0x34, 0x28, 0x34, 0x36, 0x35, 0x01, 0x01, 0x1A, 0x36, 0x35, 0x34, 0x36, 0x35, 0x00 },
    { 0x18, 0x36, 0x3B, 0x2C, 0x34, 0x36, 0x35, 0x01, 0x01, 0x18, 0x3C, 0x34, 0x28, 0x34, 0x36, 0x35, 0x01, 0x01, 0x0E, 0x2E, 0x3C, 0x34, 0x36, 0x35, 0x00 },
    { 0x18, 0x36, 0x3B, 0x2C, 0x34, 0x36, 0x35, 0x01, 0x01, 0x18, 0x3C, 0x34, 0x28, 0x34, 0x36, 0x35, 0x01, 0x01, 0x23, 0x2C, 0x2C, 0x34, 0x36, 0x35, 0x00 },
    { 0x18, 0x36, 0x3B, 0x2C, 0x34, 0x36, 0x35, 0x01, 0x01, 0x18, 0x3C, 0x34, 0x28, 0x34, 0x36, 0x35, 0x01, 0x01, 0x14, 0x3C, 0x30, 0x33, 0x34, 0x36, 0x35, 0x00 },
    { 0x18, 0x36, 0x3B, 0x2C, 0x34, 0x36, 0x35, 0x01, 0x01, 0x18, 0x3C, 0x34, 0x28, 0x34, 0x36, 0x35, 0x01, 0x01, 0x1F, 0x2C, 0x35, 0x28, 0x34, 0x36, 0x35, 0x00 },
    { 0x18, 0x36, 0x3B, 0x2C, 0x34, 0x36, 0x35, 0x01, 0x01, 0x18, 0x3C, 0x34, 0x28, 0x34, 0x36, 0x35, 0x01, 0x01, 0x1D, 0x28, 0x3B, 0x28, 0x34, 0x36, 0x35, 0x00 },
    { 0x18, 0x36, 0x3B, 0x2C, 0x34, 0x36, 0x35, 0x01, 0x01, 0x1A, 0x36, 0x35, 0x34, 0x36, 0x35, 0x01, 0x01, 0x0E, 0x2E, 0x3C, 0x34, 0x36, 0x35, 0x00 },
    { 0x18, 0x36, 0x3B, 0x2C, 0x34, 0x36, 0x35, 0x01, 0x01, 0x1A, 0x36, 0x35, 0x34, 0x36, 0x35, 0x01, 0x01, 0x23, 0x2C, 0x2C, 0x34, 0x36, 0x35, 0x00 },
    { 0x18, 0x36, 0x3B, 0x2C, 0x34, 0x36, 0x35, 0x01, 0x01, 0x1A, 0x36, 0x35, 0x34, 0x36, 0x35, 0x01, 0x01, 0x14, 0x3C, 0x30, 0x33, 0x34, 0x36, 0x35, 0x00 },
    { 0x18, 0x36, 0x3B, 0x2C, 0x34, 0x36, 0x35, 0x01, 0x01, 0x1A, 0x36, 0x35, 0x34, 0x36, 0x35, 0x01, 0x01, 0x1F, 0x2C, 0x35, 0x28, 0x34, 0x36, 0x35, 0x00 },
    { 0x18, 0x36, 0x3B, 0x2C, 0x34, 0x36, 0x35, 0x01, 0x01, 0x1A, 0x36, 0x35, 0x34, 0x36, 0x35, 0x01, 0x01, 0x1D, 0x28, 0x3B, 0x28, 0x34, 0x36, 0x35, 0x00 },
    { 0x18, 0x36, 0x3B, 0x2C, 0x34, 0x36, 0x35, 0x01, 0x01, 0x0E, 0x2E, 0x3C, 0x34, 0x36, 0x35, 0x01, 0x01, 0x23, 0x2C, 0x2C, 0x34, 0x36, 0x35, 0x00 },
    { 0x18, 0x36, 0x3B, 0x2C, 0x34, 0x36, 0x35, 0x01, 0x01, 0x0E, 0x2E, 0x3C, 0x34, 0x36, 0x35, 0x01, 0x01, 0x14, 0x3C, 0x30, 0x33, 0x34, 0x36, 0x35, 0x00 },
    { 0x18, 0x36, 0x3B, 0x2C, 0x34, 0x36, 0x35, 0x01, 0x01, 0x0E, 0x2E, 0x3C, 0x34, 0x36, 0x35, 0x01, 0x01, 0x1F, 0x2C, 0x35, 0x28, 0x34, 0x36, 0x35, 0x00 },
    { 0x18, 0x36, 0x3B, 0x2C, 0x34, 0x36, 0x35, 0x01, 0x01, 0x0E, 0x2E, 0x3C, 0x34, 0x36, 0x35, 0x01, 0x01, 0x1D, 0x28, 0x3B, 0x28, 0x34, 0x36, 0x35, 0x00 },
    { 0x18, 0x36, 0x3B, 0x2C, 0x34, 0x36, 0x35, 0x01, 0x01, 0x23, 0x2C, 0x2C, 0x34, 0x36, 0x35, 0x01, 0x01, 0x14, 0x3C, 0x30, 0x33, 0x34, 0x36, 0x35, 0x00 },
    { 0x18, 0x36, 0x3B, 0x2C, 0x34, 0x36, 0x35, 0x01, 0x01, 0x23, 0x2C, 0x2C, 0x34, 0x36, 0x35, 0x01, 0x01, 0x1F, 0x2C, 0x35, 0x28, 0x34, 0x36, 0x35, 0x00 },
    { 0x18, 0x36, 0x3B, 0x2C, 0x34, 0x36, 0x35, 0x01, 0x01, 0x23, 0x2C, 0x2C, 0x34, 0x36, 0x35, 0x01, 0x01, 0x1D, 0x28, 0x3B, 0x28, 0x34, 0x36, 0x35, 0x00 },
    { 0x18, 0x36, 0x3B, 0x2C, 0x34, 0x36, 0x35, 0x01, 0x01, 0x14, 0x3C, 0x30, 0x33, 0x34, 0x36, 0x35, 0x01, 0x01, 0x1F, 0x2C, 0x35, 0x28, 0x34, 0x36, 0x35, 0x00 },
    { 0x18, 0x36, 0x3B, 0x2C, 0x34, 0x36, 0x35, 0x01, 0x01, 0x14, 0x3C, 0x30, 0x33, 0x34, 0x36, 0x35, 0x01, 0x01, 0x1D, 0x28, 0x3B, 0x28, 0x34, 0x36, 0x35, 0x00 },
    { 0x18, 0x3C, 0x34, 0x28, 0x34, 0x36, 0x35, 0x01, 0x01, 0x1A, 0x36, 0x35, 0x34, 0x36, 0x35, 0x01, 0x01, 0x0E, 0x2E, 0x3C, 0x34, 0x36, 0x35, 0x00 },
    { 0x18, 0x3C, 0x34, 0x28, 0x34, 0x36, 0x35, 0x01, 0x01, 0x1A, 0x36, 0x35, 0x34, 0x36, 0x35, 0x01, 0x01, 0x23, 0x2C, 0x2C, 0x34, 0x36, 0x35, 0x00 },
    { 0x18, 0x3C, 0x34, 0x28, 0x34, 0x36, 0x35, 0x01, 0x01, 0x1A, 0x36, 0x35, 0x34, 0x36, 0x35, 0x01, 0x01, 0x14, 0x3C, 0x30, 0x33, 0x34, 0x36, 0x35, 0x00 },
    { 0x18, 0x3C, 0x34, 0x28, 0x34, 0x36, 0x35, 0x01, 0x01, 0x1A, 0x36, 0x35, 0x34, 0x36, 0x35, 0x01, 0x01, 0x1F, 0x2C, 0x35, 0x28, 0x34, 0x36, 0x35, 0x00 },
    { 0x18, 0x3C, 0x34, 0x28, 0x34, 0x36, 0x35, 0x01, 0x01, 0x1A, 0x36, 0x35, 0x34, 0x36, 0x35, 0x01, 0x01, 0x1D, 0x28, 0x3B, 0x28, 0x34, 0x36, 0x35, 0x00 },
    { 0x18, 0x3C, 0x34, 0x28, 0x34, 0x36, 0x35, 0x01, 0x01, 0x0E, 0x2E, 0x3C, 0x34, 0x36, 0x35, 0x01, 0x01, 0x23, 0x2C, 0x2C, 0x34, 0x36, 0x35, 0x00 },
    { 0x18, 0x3C, 0x34, 0x28, 0x34, 0x36, 0x35, 0x01, 0x01, 0x0E, 0x2E, 0x3C, 0x34, 0x36, 0x35, 0x01, 0x01, 0x14, 0x3C, 0x30, 0x33, 0x34, 0x36, 0x35, 0x00 },
    { 0x18, 0x3C, 0x34, 0x28, 0x34, 0x36, 0x35, 0x01, 0x01, 0x0E, 0x2E, 0x3C, 0x34, 0x36, 0x35, 0x01, 0x01, 0x1F, 0x2C, 0x35, 0x28, 0x34, 0x36, 0x35, 0x00 },
    { 0x18, 0x3C, 0x34, 0x28, 0x34, 0x36, 0x35, 0x01, 0x01, 0x0E, 0x2E, 0x3C, 0x34, 0x36, 0x35, 0x01, 0x01, 0x1D, 0x28, 0x3B, 0x28, 0x34, 0x36, 0x35, 0x00 },
    { 0x18, 0x3C, 0x34, 0x28, 0x34, 0x36, 0x35, 0x01, 0x01, 0x23, 0x2C, 0x2C, 0x34, 0x36, 0x35, 0x01, 0x01, 0x14, 0x3C, 0x30, 0x33, 0x34, 0x36, 0x35, 0x00 },
    { 0x18, 0x3C, 0x34, 0x28, 0x34, 0x36, 0x35, 0x01, 0x01, 0x23, 0x2C, 0x2C, 0x34, 0x36, 0x35, 0x01, 0x01, 0x1F, 0x2C, 0x35, 0x28, 0x34, 0x36, 0x35, 0x00 },
    { 0x18, 0x3C, 0x34, 0x28, 0x34, 0x36, 0x35, 0x01, 0x01, 0x23, 0x2C, 0x2C, 0x34, 0x36, 0x35, 0x01, 0x01, 0x1D, 0x28, 0x3B, 0x28, 0x34, 0x36, 0x35, 0x00 },
    { 0x18, 0x3C, 0x34, 0x28, 0x34, 0x36, 0x35, 0x01, 0x01, 0x14, 0x3C, 0x30, 0x33, 0x34, 0x36, 0x35, 0x01, 0x01, 0x1F, 0x2C, 0x35, 0x28, 0x34, 0x36, 0x35, 0x00 },
    { 0x18, 0x3C, 0x34, 0x28, 0x34, 0x36, 0x35, 0x01, 0x01, 0x1F, 0x2C, 0x35, 0x28, 0x34, 0x36, 0x35, 0x01, 0x01, 0x1D, 0x28, 0x3B, 0x28, 0x34, 0x36, 0x35, 0x00 },
    { 0x1A, 0x36, 0x35, 0x34, 0x36, 0x35, 0x01, 0x01, 0x0E, 0x2E, 0x3C, 0x34, 0x36, 0x35, 0x01, 0x01, 0x23, 0x2C, 0x2C, 0x34, 0x36, 0x35, 0x00 },
    { 0x1A, 0x36, 0x35, 0x34, 0x36, 0x35, 0x01, 0x01, 0x0E, 0x2E, 0x3C, 0x34, 0x36, 0x35, 0x01, 0x01, 0x14, 0x3C, 0x30, 0x33, 0x34, 0x36, 0x35, 0x00 },
    { 0x1A, 0x36, 0x35, 0x34, 0x36, 0x35, 0x01, 0x01, 0x0E, 0x2E, 0x3C, 0x34, 0x36, 0x35, 0x01, 0x01, 0x1D, 0x28, 0x3B, 0x28, 0x34, 0x36, 0x35, 0x00 },
    { 0x1A, 0x36, 0x35, 0x34, 0x36, 0x35, 0x01, 0x01, 0x23, 0x2C, 0x2C, 0x34, 0x36, 0x35, 0x01, 0x01, 0x14, 0x3C, 0x30, 0x33, 0x34, 0x36, 0x35, 0x00 },
    { 0x1A, 0x36, 0x35, 0x34, 0x36, 0x35, 0x01, 0x01, 0x23, 0x2C, 0x2C, 0x34, 0x36, 0x35, 0x01, 0x01, 0x1F, 0x2C, 0x35, 0x28, 0x34, 0x36, 0x35, 0x00 },
    { 0x1A, 0x36, 0x35, 0x34, 0x36, 0x35, 0x01, 0x01, 0x23, 0x2C, 0x2C, 0x34, 0x36, 0x35, 0x01, 0x01, 0x1D, 0x28, 0x3B, 0x28, 0x34, 0x36, 0x35, 0x00 },
    { 0x1A, 0x36, 0x35, 0x34, 0x36, 0x35, 0x01, 0x01, 0x14, 0x3C, 0x30, 0x33, 0x34, 0x36, 0x35, 0x01, 0x01, 0x1F, 0x2C, 0x35, 0x28, 0x34, 0x36, 0x35, 0x00 },
    { 0x1A, 0x36, 0x35, 0x34, 0x36, 0x35, 0x01, 0x01, 0x14, 0x3C, 0x30, 0x33, 0x34, 0x36, 0x35, 0x01, 0x01, 0x1D, 0x28, 0x3B, 0x28, 0x34, 0x36, 0x35, 0x00 },
    { 0x1A, 0x36, 0x35, 0x34, 0x36, 0x35, 0x01, 0x01, 0x1F, 0x2C, 0x35, 0x28, 0x34, 0x36, 0x35, 0x01, 0x01, 0x1D, 0x28, 0x3B, 0x28, 0x34, 0x36, 0x35, 0x00 },
    { 0x0E, 0x2E, 0x3C, 0x34, 0x36, 0x35, 0x01, 0x01, 0x23, 0x2C, 0x2C, 0x34, 0x36, 0x35, 0x01, 0x01, 0x14, 0x3C, 0x30, 0x33, 0x34, 0x36, 0x35, 0x00 },
    { 0x0E, 0x2E, 0x3C, 0x34, 0x36, 0x35, 0x01, 0x01, 0x23, 0x2C, 0x2C, 0x34, 0x36, 0x35, 0x01, 0x01, 0x1F, 0x2C, 0x35, 0x28, 0x34, 0x36, 0x35, 0x00 },
    { 0x0E, 0x2E, 0x3C, 0x34, 0x36, 0x35, 0x01, 0x01, 0x23, 0x2C, 0x2C, 0x34, 0x36, 0x35, 0x01, 0x01, 0x1D, 0x28, 0x3B, 0x28, 0x34, 0x36, 0x35, 0x00 },
    { 0x0E, 0x2E, 0x3C, 0x34, 0x36, 0x35, 0x01, 0x01, 0x14, 0x3C, 0x30, 0x33, 0x34, 0x36, 0x35, 0x01, 0x01, 0x1F, 0x2C, 0x35, 0x28, 0x34, 0x36, 0x35, 0x00 },
    { 0x0E, 0x2E, 0x3C, 0x34, 0x36, 0x35, 0x01, 0x01, 0x14, 0x3C, 0x30, 0x33, 0x34, 0x36, 0x35, 0x01, 0x01, 0x1D, 0x28, 0x3B, 0x28, 0x34, 0x36, 0x35, 0x00 },
    { 0x0E, 0x2E, 0x3C, 0x34, 0x36, 0x35, 0x01, 0x01, 0x1F, 0x2C, 0x35, 0x28, 0x34, 0x36, 0x35, 0x01, 0x01, 0x1D, 0x28, 0x3B, 0x28, 0x34, 0x36, 0x35, 0x00 },
    { 0x23, 0x2C, 0x2C, 0x34, 0x36, 0x35, 0x01, 0x01, 0x14, 0x3C, 0x30, 0x33, 0x34, 0x36, 0x35, 0x01, 0x01, 0x1F, 0x2C, 0x35, 0x28, 0x34, 0x36, 0x35, 0x00 },
    { 0x23, 0x2C, 0x2C, 0x34, 0x36, 0x35, 0x01, 0x01, 0x14, 0x3C, 0x30, 0x33, 0x34, 0x36, 0x35, 0x01, 0x01, 0x1D, 0x28, 0x3B, 0x28, 0x34, 0x36, 0x35, 0x00 },
    { 0x23, 0x2C, 0x2C, 0x34, 0x36, 0x35, 0x01, 0x01, 0x1F, 0x2C, 0x35, 0x28, 0x34, 0x36, 0x35, 0x01, 0x01, 0x1D, 0x28, 0x3B, 0x28, 0x34, 0x36, 0x35, 0x00 },
    { 0x14, 0x3C, 0x30, 0x33, 0x34, 0x36, 0x35, 0x01, 0x01, 0x1F, 0x2C, 0x35, 0x28, 0x34, 0x36, 0x35, 0x01, 0x01, 0x1D, 0x28, 0x3B, 0x28, 0x34, 0x36, 0x35, 0x00 },
};

static const char *s_team_names[53] = { "Kotemon + Kumamon + Monmon", "Kotemon + Kumamon + Agumon", "Kotemon + Kumamon + Veemon", "Kotemon + Kumamon + Guilmon", "Kotemon + Kumamon + Renamon", "Kotemon + Kumamon + Patamon", "Kotemon + Monmon + Agumon", "Kotemon + Monmon + Veemon", "Kotemon + Monmon + Guilmon", "Kotemon + Monmon + Renamon", "Kotemon + Monmon + Patamon", "Kotemon + Agumon + Veemon", "Kotemon + Agumon + Guilmon", "Kotemon + Agumon + Renamon", "Kotemon + Agumon + Patamon", "Kotemon + Veemon + Guilmon", "Kotemon + Veemon + Renamon", "Kotemon + Veemon + Patamon", "Kotemon + Guilmon + Renamon", "Kotemon + Guilmon + Patamon", "Kumamon + Monmon + Agumon", "Kumamon + Monmon + Veemon", "Kumamon + Monmon + Guilmon", "Kumamon + Monmon + Renamon", "Kumamon + Monmon + Patamon", "Kumamon + Agumon + Veemon", "Kumamon + Agumon + Guilmon", "Kumamon + Agumon + Renamon", "Kumamon + Agumon + Patamon", "Kumamon + Veemon + Guilmon", "Kumamon + Veemon + Renamon", "Kumamon + Veemon + Patamon", "Kumamon + Guilmon + Renamon", "Kumamon + Renamon + Patamon", "Monmon + Agumon + Veemon", "Monmon + Agumon + Guilmon", "Monmon + Agumon + Patamon", "Monmon + Veemon + Guilmon", "Monmon + Veemon + Renamon", "Monmon + Veemon + Patamon", "Monmon + Guilmon + Renamon", "Monmon + Guilmon + Patamon", "Monmon + Renamon + Patamon", "Agumon + Veemon + Guilmon", "Agumon + Veemon + Renamon", "Agumon + Veemon + Patamon", "Agumon + Guilmon + Renamon", "Agumon + Guilmon + Patamon", "Agumon + Renamon + Patamon", "Veemon + Guilmon + Renamon", "Veemon + Guilmon + Patamon", "Veemon + Renamon + Patamon", "Guilmon + Renamon + Patamon" };

/* -------------------------------------------------------------- slot model */
/* s_present[t] is set by t's own activation callback, which the runtime calls
 * for EVERY enabled package and for no other.  So the live enabled set is
 * exactly { t : s_present[t] }.  s_slot_of[] is derived from it once. */
static int      s_present[PACK_COUNT];   /* 1 = package enabled this launch      */
static int      s_slot_of[PACK_COUNT];   /* package index -> slot 0..2, or -1    */
static int      s_map_ready = 0;         /* slot map built once                  */
static int      s_slot_count = 0;        /* slots covered (0..3)                 */
static int      s_extra = 0;             /* enabled packages beyond the three    */
static int      s_checked  = 0;          /* region self-test ran                 */
static int      s_disabled = 0;          /* wrong region / collision: do nothing */
static int      s_force    = -1;         /* DW3_STARTER_TEAM=0..52 (test hook)   */
static int      s_boot_mode = 0;         /* DW3_STARTER_BOOT=<mode> (test hook)  */
static int      s_booted   = 0;
static unsigned s_frame    = 0;

/* ------------------------------------------------------------------ text */
static uint32_t slot_cap(uint32_t data, uint32_t index) {
    uint32_t next = psx_mod_read_word(data + 4u + 4u * (index + 1u));
    uint32_t here = psx_mod_read_word(data + 4u + 4u * index);
    if (next <= here + 1u) return 0u;
    return next - here - 1u;   /* content bytes before the terminator */
}

static void put_string(uint32_t data, uint32_t index, const uint8_t *s) {
    uint32_t cap = slot_cap(data, index);
    uint32_t base = data + psx_mod_read_word(data + 4u + 4u * index);
    uint32_t i = 0u;
    if (cap == 0u) return;
    while (s[i] != 0u && i < cap) { psx_mod_write_byte(base + i, s[i]); i++; }
    for (; i <= cap; i++) psx_mod_write_byte(base + i, 0u);   /* terminator + pad */
}

/* Find the loaded NAMEET buffer by content signature (string 7/8/9 are the
 * pack letters A/B/C in every language, so this is language-independent). */
static uint32_t find_nameet(void) {
    uint32_t i;
    for (i = 0u; i < CACHE_SLOTS; i++) {
        uint32_t slot = FILE_CACHE_BASE + 4u + i * SLOT_STRIDE;
        uint32_t data, o7, o8, o9;
        if ((int)psx_mod_read_half(slot + SLOT_OFF_STATE) != FILE_LOADED) continue;
        data = psx_mod_read_word(slot + SLOT_OFF_DATA);
        if (data < 0x80000000u || data >= 0x80200000u) continue;
        if (psx_mod_read_word(data) != NAMEET_COUNT) continue;
        o7 = psx_mod_read_word(data + 4u + 4u * 7u);
        o8 = psx_mod_read_word(data + 4u + 4u * 8u);
        o9 = psx_mod_read_word(data + 4u + 4u * 9u);
        if (psx_mod_read_byte(data + o7) != 0x0Eu) continue;  /* 'A' */
        if (psx_mod_read_byte(data + o8) != 0x0Fu) continue;  /* 'B' */
        if (psx_mod_read_byte(data + o9) != 0x10u) continue;  /* 'C' */
        return data;
    }
    return 0u;
}

/* Rewrite exactly ONE slot's name and ONE slot's description, in place.  The
 * other slots' strings are left untouched so an uncovered slot keeps the
 * game's own text. */
static void patch_nameet_slot(int t, int slot) {
    uint32_t data;
    if (slot < 0 || (uint32_t)slot >= PARTY_ROWS) return;
    data = find_nameet();
    if (data == 0u) return;
    put_string(data, IDX_NAME0 + (uint32_t)slot, kPackName[t]);
    put_string(data, IDX_DESC0 + (uint32_t)slot, kPackDesc[t]);
}

/* ------------------------------------------------------------- the writes */
static int in_stplnmet(void) {
    return (psx_mod_read_word(GAME_MODE) & MODE_BAND_MASK) == STPLNMET_MODE;
}

static int lowest_enabled(void) {
    int i;
    for (i = 0; i < PACK_COUNT; i++) if (s_present[i]) return i;
    return -1;
}

/* Build the enabled-pack -> slot map once.  Ascending package index -> slots
 * 0,1,2; a strictly increasing assignment, so collisions are impossible. */
static void build_slot_map(void) {
    int i, collision = 0;
    if (s_map_ready) return;
    s_map_ready = 1;
    for (i = 0; i < PACK_COUNT; i++) s_slot_of[i] = -1;

    fprintf(stderr, "starter-pack: slot map for %s\n", s_reg->name);
    for (i = 0; i < PACK_COUNT; i++) {
        if (!s_present[i]) continue;
        if (s_slot_count < (int)PARTY_ROWS) {
            s_slot_of[i] = s_slot_count;
            fprintf(stderr, "starter-pack:   slot %d <- dev.starter-pack.%02d (%s)\n",
                    s_slot_count, i, s_team_names[i]);
            s_slot_count++;
        } else {
            fprintf(stderr, "starter-pack:   IGNORED dev.starter-pack.%02d (%s) - "
                            "all three slots already taken\n", i, s_team_names[i]);
            s_extra++;
        }
    }
    for (i = s_slot_count; i < (int)PARTY_ROWS; i++)
        fprintf(stderr, "starter-pack:   slot %d <- GAME ORIGINAL (no pack enabled)\n", i);
    if (s_slot_count == 0)
        fprintf(stderr, "starter-pack: no packs enabled - all three slots keep the "
                        "game's original teams, names and descriptions\n");

    /* Collision check: two enabled packs must never share a slot.  The mapping
     * above cannot produce one, but prove it rather than assert it. */
    for (i = 0; i < PACK_COUNT && !collision; i++) {
        int j;
        if (s_slot_of[i] < 0) continue;
        for (j = i + 1; j < PACK_COUNT; j++) {
            if (s_slot_of[j] < 0) continue;
            if (s_slot_of[i] == s_slot_of[j]) { collision = 1; break; }
        }
    }
    if (collision) {
        s_disabled = 1;
        fprintf(stderr, "starter-pack: SLOT COLLISION - two enabled packs resolved to the "
                        "same slot. DISABLING: no writes.\n");
        return;
    }
    if (s_slot_count > 0)
        fprintf(stderr, "starter-pack: slot collision check: none (%d pack(s) -> slots 0..%d)\n",
                s_slot_count, s_slot_count - 1);
    if (s_extra)
        fprintf(stderr, "starter-pack: %d pack(s) beyond the first three ignored "
                        "(three slots only)\n", s_extra);
}

/* one-shot: prove the address table matches the live game before trusting it */
static void starter_region_check(void) {
    uint32_t i;
    int plausible = 1;
    if (s_checked) return;
    if (!psx_mod_game_started()) return;
    s_checked = 1;
    for (i = 0u; i < 9u; i++)
        if (psx_mod_read_byte(STARTER_PARTIES + i) > 7u) { plausible = 0; break; }
    if (plausible)
        for (i = 0u; i < PARTY_ROWS; i++) {
            uint8_t a = psx_mod_read_byte(STARTER_PARTIES + i * 3u);
            uint8_t b = psx_mod_read_byte(STARTER_PARTIES + i * 3u + 1u);
            uint8_t c = psx_mod_read_byte(STARTER_PARTIES + i * 3u + 2u);
            if (a == b || b == c || a == c) { plausible = 0; break; }
        }
    if (!plausible) {
        s_disabled = 1;
        fprintf(stderr, "starter-pack: REGION SELF-TEST FAILED for %s - 0x%08X does "
                        "not hold a starter table (wrong region table?). DISABLING: "
                        "no writes.\n", s_reg->name, (unsigned)STARTER_PARTIES);
        return;
    }
    fprintf(stderr, "starter-pack: region OK - %s (STARTER_PARTIES 0x%08X, "
                    "STPLNMET_partnerChoices 0x%08X, FILE_CACHE 0x%08X)\n",
            s_reg->name, (unsigned)STARTER_PARTIES, (unsigned)PARTNER_CHOICES,
            (unsigned)FILE_CACHE_BASE);
}

/* Apply team t to exactly slot.  Only this slot's row of STARTER_PARTIES, its
 * row of STPLNMET_partnerChoices and its one NAMEET name/description pair are
 * touched; every other slot is left exactly as the game has it. */
static void apply_slot(int t, int slot) {
    const uint8_t *team = kTeams[t];
    uint32_t c;
    uint32_t row = STARTER_PARTIES + (uint32_t)slot * PARTY_COLS;
    /* 1. the granted team: this slot's row of STARTER_PARTIES (always resident) */
    for (c = 0u; c < PARTY_COLS; c++)
        if (psx_mod_read_byte(row + c) != team[c])
            psx_mod_write_byte(row + c, team[c]);
    /* 2. the shown team + text: STPLNMET overlay, only while it is the live overlay */
    if (!in_stplnmet()) return;
    for (c = 0u; c < PARTY_COLS; c++) {
        uint32_t a = PARTNER_CHOICES + ((uint32_t)slot * PARTY_COLS + c) * 4u;
        if (psx_mod_read_word(a) != team[c])
            psx_mod_write_word(a, (uint32_t)team[c]);
    }
    patch_nameet_slot(t, slot);
}

static void starter_frame(int t) {
    int slot;
    if (!psx_mod_game_started()) return;
    s_frame++;
    starter_region_check();
    if (s_disabled) return;
    if (s_boot_mode != 0 && !s_booted && (int)psx_mod_read_word(GAME_MODE) != 0) {
        s_booted = 1;
        psx_mod_write_word(GAME_NEXTMODE, (uint32_t)s_boot_mode);
        psx_mod_write_word(GAME_MODEARG, 0u);
        psx_mod_write_word(ROOT_TASK, 0u);
        fprintf(stderr, "starter-pack: boot jump -> mode 0x%X\n", s_boot_mode);
    }
    build_slot_map();
    if (s_disabled) return;

    if (s_force >= 0) {
        /* dev hook: one forced team into slot 0, done by the lowest enabled id
         * only, so the hook can never write two slots. */
        if (t != lowest_enabled() || s_force >= PACK_COUNT) return;
        apply_slot(s_force, 0);
        return;
    }
    slot = s_slot_of[t];
    if (slot < 0) return;      /* not enabled, or an ignored extra: no slot, no writes */
    apply_slot(t, slot);
}

static void starter_activate(int t) {
    const char *env = getenv("DW3_STARTER_TEAM");
    const char *boot = getenv("DW3_STARTER_BOOT");
    if (t >= 0 && t < PACK_COUNT) s_present[t] = 1;
    if (env && *env) s_force = (int)strtol(env, NULL, 0);
    if (boot && *boot) s_boot_mode = (int)strtol(boot, NULL, 0);
    fprintf(stderr, "starter-pack: package dev.starter-pack.%02d active (%s) for %s\n",
            t, (t >= 0 && t < PACK_COUNT) ? s_team_names[t] : "?", s_reg->name);
}

static void sp_act_0(void) { starter_activate(0); }
static void sp_vb_0(void)  { starter_frame(0); }
static void sp_act_1(void) { starter_activate(1); }
static void sp_vb_1(void)  { starter_frame(1); }
static void sp_act_2(void) { starter_activate(2); }
static void sp_vb_2(void)  { starter_frame(2); }
static void sp_act_3(void) { starter_activate(3); }
static void sp_vb_3(void)  { starter_frame(3); }
static void sp_act_4(void) { starter_activate(4); }
static void sp_vb_4(void)  { starter_frame(4); }
static void sp_act_5(void) { starter_activate(5); }
static void sp_vb_5(void)  { starter_frame(5); }
static void sp_act_6(void) { starter_activate(6); }
static void sp_vb_6(void)  { starter_frame(6); }
static void sp_act_7(void) { starter_activate(7); }
static void sp_vb_7(void)  { starter_frame(7); }
static void sp_act_8(void) { starter_activate(8); }
static void sp_vb_8(void)  { starter_frame(8); }
static void sp_act_9(void) { starter_activate(9); }
static void sp_vb_9(void)  { starter_frame(9); }
static void sp_act_10(void) { starter_activate(10); }
static void sp_vb_10(void)  { starter_frame(10); }
static void sp_act_11(void) { starter_activate(11); }
static void sp_vb_11(void)  { starter_frame(11); }
static void sp_act_12(void) { starter_activate(12); }
static void sp_vb_12(void)  { starter_frame(12); }
static void sp_act_13(void) { starter_activate(13); }
static void sp_vb_13(void)  { starter_frame(13); }
static void sp_act_14(void) { starter_activate(14); }
static void sp_vb_14(void)  { starter_frame(14); }
static void sp_act_15(void) { starter_activate(15); }
static void sp_vb_15(void)  { starter_frame(15); }
static void sp_act_16(void) { starter_activate(16); }
static void sp_vb_16(void)  { starter_frame(16); }
static void sp_act_17(void) { starter_activate(17); }
static void sp_vb_17(void)  { starter_frame(17); }
static void sp_act_18(void) { starter_activate(18); }
static void sp_vb_18(void)  { starter_frame(18); }
static void sp_act_19(void) { starter_activate(19); }
static void sp_vb_19(void)  { starter_frame(19); }
static void sp_act_20(void) { starter_activate(20); }
static void sp_vb_20(void)  { starter_frame(20); }
static void sp_act_21(void) { starter_activate(21); }
static void sp_vb_21(void)  { starter_frame(21); }
static void sp_act_22(void) { starter_activate(22); }
static void sp_vb_22(void)  { starter_frame(22); }
static void sp_act_23(void) { starter_activate(23); }
static void sp_vb_23(void)  { starter_frame(23); }
static void sp_act_24(void) { starter_activate(24); }
static void sp_vb_24(void)  { starter_frame(24); }
static void sp_act_25(void) { starter_activate(25); }
static void sp_vb_25(void)  { starter_frame(25); }
static void sp_act_26(void) { starter_activate(26); }
static void sp_vb_26(void)  { starter_frame(26); }
static void sp_act_27(void) { starter_activate(27); }
static void sp_vb_27(void)  { starter_frame(27); }
static void sp_act_28(void) { starter_activate(28); }
static void sp_vb_28(void)  { starter_frame(28); }
static void sp_act_29(void) { starter_activate(29); }
static void sp_vb_29(void)  { starter_frame(29); }
static void sp_act_30(void) { starter_activate(30); }
static void sp_vb_30(void)  { starter_frame(30); }
static void sp_act_31(void) { starter_activate(31); }
static void sp_vb_31(void)  { starter_frame(31); }
static void sp_act_32(void) { starter_activate(32); }
static void sp_vb_32(void)  { starter_frame(32); }
static void sp_act_33(void) { starter_activate(33); }
static void sp_vb_33(void)  { starter_frame(33); }
static void sp_act_34(void) { starter_activate(34); }
static void sp_vb_34(void)  { starter_frame(34); }
static void sp_act_35(void) { starter_activate(35); }
static void sp_vb_35(void)  { starter_frame(35); }
static void sp_act_36(void) { starter_activate(36); }
static void sp_vb_36(void)  { starter_frame(36); }
static void sp_act_37(void) { starter_activate(37); }
static void sp_vb_37(void)  { starter_frame(37); }
static void sp_act_38(void) { starter_activate(38); }
static void sp_vb_38(void)  { starter_frame(38); }
static void sp_act_39(void) { starter_activate(39); }
static void sp_vb_39(void)  { starter_frame(39); }
static void sp_act_40(void) { starter_activate(40); }
static void sp_vb_40(void)  { starter_frame(40); }
static void sp_act_41(void) { starter_activate(41); }
static void sp_vb_41(void)  { starter_frame(41); }
static void sp_act_42(void) { starter_activate(42); }
static void sp_vb_42(void)  { starter_frame(42); }
static void sp_act_43(void) { starter_activate(43); }
static void sp_vb_43(void)  { starter_frame(43); }
static void sp_act_44(void) { starter_activate(44); }
static void sp_vb_44(void)  { starter_frame(44); }
static void sp_act_45(void) { starter_activate(45); }
static void sp_vb_45(void)  { starter_frame(45); }
static void sp_act_46(void) { starter_activate(46); }
static void sp_vb_46(void)  { starter_frame(46); }
static void sp_act_47(void) { starter_activate(47); }
static void sp_vb_47(void)  { starter_frame(47); }
static void sp_act_48(void) { starter_activate(48); }
static void sp_vb_48(void)  { starter_frame(48); }
static void sp_act_49(void) { starter_activate(49); }
static void sp_vb_49(void)  { starter_frame(49); }
static void sp_act_50(void) { starter_activate(50); }
static void sp_vb_50(void)  { starter_frame(50); }
static void sp_act_51(void) { starter_activate(51); }
static void sp_vb_51(void)  { starter_frame(51); }
static void sp_act_52(void) { starter_activate(52); }
static void sp_vb_52(void)  { starter_frame(52); }

typedef struct SpPlugin {
    const char *id;
    void (*activate)(void);
    void (*vblank)(void);
} SpPlugin;

static const SpPlugin kPlugins[53] = {
    { "dev.starter-pack.00", sp_act_0, sp_vb_0 },
    { "dev.starter-pack.01", sp_act_1, sp_vb_1 },
    { "dev.starter-pack.02", sp_act_2, sp_vb_2 },
    { "dev.starter-pack.03", sp_act_3, sp_vb_3 },
    { "dev.starter-pack.04", sp_act_4, sp_vb_4 },
    { "dev.starter-pack.05", sp_act_5, sp_vb_5 },
    { "dev.starter-pack.06", sp_act_6, sp_vb_6 },
    { "dev.starter-pack.07", sp_act_7, sp_vb_7 },
    { "dev.starter-pack.08", sp_act_8, sp_vb_8 },
    { "dev.starter-pack.09", sp_act_9, sp_vb_9 },
    { "dev.starter-pack.10", sp_act_10, sp_vb_10 },
    { "dev.starter-pack.11", sp_act_11, sp_vb_11 },
    { "dev.starter-pack.12", sp_act_12, sp_vb_12 },
    { "dev.starter-pack.13", sp_act_13, sp_vb_13 },
    { "dev.starter-pack.14", sp_act_14, sp_vb_14 },
    { "dev.starter-pack.15", sp_act_15, sp_vb_15 },
    { "dev.starter-pack.16", sp_act_16, sp_vb_16 },
    { "dev.starter-pack.17", sp_act_17, sp_vb_17 },
    { "dev.starter-pack.18", sp_act_18, sp_vb_18 },
    { "dev.starter-pack.19", sp_act_19, sp_vb_19 },
    { "dev.starter-pack.20", sp_act_20, sp_vb_20 },
    { "dev.starter-pack.21", sp_act_21, sp_vb_21 },
    { "dev.starter-pack.22", sp_act_22, sp_vb_22 },
    { "dev.starter-pack.23", sp_act_23, sp_vb_23 },
    { "dev.starter-pack.24", sp_act_24, sp_vb_24 },
    { "dev.starter-pack.25", sp_act_25, sp_vb_25 },
    { "dev.starter-pack.26", sp_act_26, sp_vb_26 },
    { "dev.starter-pack.27", sp_act_27, sp_vb_27 },
    { "dev.starter-pack.28", sp_act_28, sp_vb_28 },
    { "dev.starter-pack.29", sp_act_29, sp_vb_29 },
    { "dev.starter-pack.30", sp_act_30, sp_vb_30 },
    { "dev.starter-pack.31", sp_act_31, sp_vb_31 },
    { "dev.starter-pack.32", sp_act_32, sp_vb_32 },
    { "dev.starter-pack.33", sp_act_33, sp_vb_33 },
    { "dev.starter-pack.34", sp_act_34, sp_vb_34 },
    { "dev.starter-pack.35", sp_act_35, sp_vb_35 },
    { "dev.starter-pack.36", sp_act_36, sp_vb_36 },
    { "dev.starter-pack.37", sp_act_37, sp_vb_37 },
    { "dev.starter-pack.38", sp_act_38, sp_vb_38 },
    { "dev.starter-pack.39", sp_act_39, sp_vb_39 },
    { "dev.starter-pack.40", sp_act_40, sp_vb_40 },
    { "dev.starter-pack.41", sp_act_41, sp_vb_41 },
    { "dev.starter-pack.42", sp_act_42, sp_vb_42 },
    { "dev.starter-pack.43", sp_act_43, sp_vb_43 },
    { "dev.starter-pack.44", sp_act_44, sp_vb_44 },
    { "dev.starter-pack.45", sp_act_45, sp_vb_45 },
    { "dev.starter-pack.46", sp_act_46, sp_vb_46 },
    { "dev.starter-pack.47", sp_act_47, sp_vb_47 },
    { "dev.starter-pack.48", sp_act_48, sp_vb_48 },
    { "dev.starter-pack.49", sp_act_49, sp_vb_49 },
    { "dev.starter-pack.50", sp_act_50, sp_vb_50 },
    { "dev.starter-pack.51", sp_act_51, sp_vb_51 },
    { "dev.starter-pack.52", sp_act_52, sp_vb_52 },
};

PSX_MOD_CONSTRUCTOR(starter_pack_register) {
    unsigned i;
    fprintf(stderr, "starter-pack: registering 53 starter-package plugins\n");
    for (i = 0; i < 53u; i++) {
        psx_mod_register_activation_plugin(kPlugins[i].id, kPlugins[i].activate);
        psx_mod_register_vblank_plugin(kPlugins[i].id, kPlugins[i].vblank);
    }
}
