/*
 * dev.warp-tool - Digimon World 3 / 2003 field fast-travel tool.
 *
 * A trusted static plugin (format-5 [[plugin]]; mod_plugins.h / mod_plugins.h)
 * compiled into the runtime under the stable plugin id "dev.warp-tool".  It
 * does two things:
 *
 *   1. THE WARP.  It reproduces, from the host side, the two effects of
 *      FIELDSTG_leaveFieldAfter() on the live field task (the game's own field
 *      transition), so the game relocates the player itself:
 *          task->nextMode     (task + 0x5C)  s32  the stage (mode) to leave for
 *          task->nextModeArg  (task + 0x60)  s32
 *          task->leaveDelay   (task + 0x68)  s32  0 = close as soon as it can
 *          task->state        (task + 0x0C)  s32  TASK_DONE (2)
 *          task->substate     (task + 0x10)  s32  0
 *      The task is the one the game's own retail warp uses,
 *      TASK_REGISTRY.funcs.find(FIELD_TASK_FIELD = 7).
 *
 *   2. THE FAST-TRAVEL SCREEN (this version).  It is a MODAL screen of our
 *      own, opened by a trigger in the field, drawn by the runtime into guest
 *      VRAM at vblank, and shown as an opaque full-screen panel headed
 *      "FAST TRAVEL".  It is never drawn over the game's own menus: the only
 *      thing the tool draws while a game menu is up is nothing at all.
 *
 * WHY IT NO LONGER DRAWS OVER THE GAME'S MENUS
 *   The first version painted the destination list while the game's own START
 *   (field) menu was open, so it covered the party/START menu.  That is gone.
 *   The list is now a modal screen with its own trigger, and the field's own
 *   menus are never drawn over.
 *
 * HOW THE FIELD IS FROZEN WHILE THE SCREEN IS OPEN
 *   FIELDSTG_state.innOpen (FIELDSTG_STATE + 0x50) is the exact flag the game
 *   itself uses to stop the pad driving the field: actor_control.c only moves
 *   or acts on the player while innOpen == 0, and field.c only opens the START
 *   menu while innOpen != 1.  The modal sets innOpen = 1 while it is open and
 *   restores the saved value on close, so the game's own input does not also
 *   act on the field, and on exit the field is left exactly as it was.
 *
 * DESTINATIONS
 *   The game's own list of scenes: STAGSLCT_entries[] (src/stagslct/stagslct.c,
 *   the debug stage select - "a menu of every scene of the game").  Every EU
 *   row whose scene is a FIELDSTG field stage (scene & 0xFF00 == 0x200) names
 *   one field stage, and that scene IS the stage's mode - the value
 *   FIELDSTG_leaveFieldAfter's `mode` argument takes.  The list below is those
 *   rows, grouped by region.  No entry is invented.
 *
 * INPUT (the modal, field only)
 *   L2+R2               : open the FAST TRAVEL screen (edge)
 *   D-pad up/down       : move the cursor 1
 *   L1 / R1             : page up / down
 *   CROSS (X)           : warp to the highlighted destination
 *   TRIANGLE / START    : close the screen (field left untouched)
 *
 * WHY NOT THE GAME'S OWN STAGE-SELECT SCREEN
 *   Requesting MODE_STAGE_SELECT (0x1500) does make main() load STAGSLCT.PRO
 *   into OVERLAY_ADDRESS (verified: the overlay area changes from FIELDSTG's
 *   code to STAGSLCT's data), but the screen cannot be entered in this
 *   recompiled build: the STAGSLCT code at 0x800850CC does
 *       lw   v0, 0x38(s7)      -- a function pointer read from guest RAM
 *       jalr v0
 *   and that pointer reads as phys 0x140, so the runtime stops at
 *   "FATAL: FAIL-FAST unknown dispatch: addr=0x00000140 ra=0x800850CC".
 *   The pointer lives in main-exe data this build never initialises; a
 *   statically-linked mod plugin cannot supply it.  Hence this modal screen.
 */

#include "mod_plugins.h"
#include "gpu_render.h"   /* gr_vram_transfer_in, gr_render_display, backend */
#include "gpu.h"          /* gpu_get_display_info, GpuDisplayInfo */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

/* Runtime-internal accessor for the consolidated pad state (sio.c). PS1
 * convention: a CLEARED bit means pressed. */
extern uint16_t sio_get_pad_buttons(void);

/* runtime/src/gpu_gl_renderer.c: upload the CPU VRAM array's staged rects into
 * the GPU-side VRAM texture now (instead of waiting for the present path). */
extern void gl_renderer_flush_cpu_uploads(void);

/* ==========================================================================
 * REGION TABLE.  The European and USA builds are different binaries: the
 * globals move and - because the event-flag blocks in GameState differ in
 * size - so do the offsets of the fields at the END of GameState.  The
 * addresses/offsets come from the matching decomp per region:
 *   config/eu/symbols.txt  config/us/symbols.txt
 *   include/dw3/game_state.h  (#if VERSION_US / #elif VERSION_EU)
 *   include/field_map.h, include/fieldstg.h, include/dw3/task.h
 * Everything else (Task/FieldTask/FieldState field offsets) has no version
 * conditional in the decomp, so it is shared.
 *
 * The region is chosen by the BUILD (each project defines its own), not by a
 * runtime guess: there is no region marker in guest RAM to read (the PS-X EXE
 * header, which holds the disc id, is not loaded - the runtime maps the file
 * from 0x800 upward), and a wrong runtime derivation would silently produce
 * wrong addresses.  A missing define is a compile error; a table that does
 * not validate against the live game disables the mod loudly (see
 * warp_select_region / warp_region_validate).
 * ======================================================================== */
typedef struct WarpRegion {
    const char *name;
    const char *serial;
    uint32_t game;            /* GAME base                              */
    uint32_t game_off_mode;   /* GameState.mode offset within GAME      */
    uint32_t game_off_next;   /* GameState.nextMode offset within GAME  */
    uint32_t field_state;     /* FIELDSTG_state base                    */
    uint32_t task_registry;   /* TASK_REGISTRY base                     */
    uint32_t root_task;       /* main.c's ROOT_TASK                     */
} WarpRegion;

static const WarpRegion kWarpRegions[] = {
    { "Europe (SLES-03936)", "SLES-03936",
      0x80048D34u, 0x26C4u, 0x26C8u, 0x80099D80u, 0x8004B610u, 0x8005CCBCu },
    { "USA (SLUS-01436)", "SLUS-01436",
      0x800484E8u, 0x26BCu, 0x26C0u, 0x800990B4u, 0x8004ADB8u, 0x8005C458u },
};
#if defined(DW3_GAME_REGION_US)
#define WARP_REGION_INDEX 1
#elif defined(DW3_GAME_REGION_EU)
#define WARP_REGION_INDEX 0
#else
#error "warp_tool.c: define DW3_GAME_REGION_EU or DW3_GAME_REGION_US for this build (see the region table)."
#endif

static const WarpRegion *s_reg = &kWarpRegions[WARP_REGION_INDEX];

#define GAME_BASE        (s_reg->game)                   /* GameState *       */
#define GAME_MODE        (GAME_BASE + s_reg->game_off_mode)   /* s32 mode     */
#define GAME_NEXTMODE    (GAME_BASE + s_reg->game_off_next)   /* s32 nextMode */

#define FIELDSTG_STATE   (s_reg->field_state)            /* FieldState        */
#define FIELDSTG_INNOPEN (FIELDSTG_STATE + 0x50u)/* s32: pad does not move the player */
#define FIELDSTG_BUSY    (FIELDSTG_STATE + 0x58u)/* s32: an event/warp/battle has the player */
#define FIELDSTG_BATTLE  (FIELDSTG_STATE + 0x5Cu)/* s32: an encounter started */
#define FIELDSTG_ACTING  (FIELDSTG_STATE + 0x60u)/* s32: talks/climbs/slides/searches */

#define TASK_REGISTRY    (s_reg->task_registry)          /* TaskRegistry      */
#define ROOT_TASK        (s_reg->root_task)              /* main.c's mode task ptr */
#define TASK_MAX         100u
#define FIELD_TASK_FIELD 7                       /* the field's main task */

/* Task header offsets (include/dw3/task.h) */
#define T_OFF_ID         0x00u
#define T_OFF_STATE      0x0Cu
#define T_OFF_SUBSTATE   0x10u
/* FieldTask-only offsets (include/fieldstg.h) */
#define T_OFF_NEXTMODE   0x5Cu
#define T_OFF_NEXTARG    0x60u
#define T_OFF_LEAVEDELAY 0x68u

#define TASK_DONE        2

#define FIELDSTG_MODE_BASE 0x200                 /* FIELDSTG field stages   */

#define WARP_MARKER_ADDR  0x1F8003F0u            /* scratchpad tail; dump peek */
#define WARP_MARKER_VALUE 0x57415250u            /* 'WARP' */

/* PS1 pad bits (active low) - include/dw3/pad.h */
#define PSX_PAD_SELECT   (1u << 0)
#define PSX_PAD_START    (1u << 3)
#define PSX_PAD_UP       (1u << 4)
#define PSX_PAD_RIGHT    (1u << 5)
#define PSX_PAD_DOWN     (1u << 6)
#define PSX_PAD_LEFT     (1u << 7)
#define PSX_PAD_L2       (1u << 8)
#define PSX_PAD_R2       (1u << 9)
#define PSX_PAD_L1       (1u << 10)
#define PSX_PAD_R1       (1u << 11)
#define PSX_PAD_TRIANGLE (1u << 12)
#define PSX_PAD_CIRCLE   (1u << 13)
#define PSX_PAD_CROSS    (1u << 14)
#define PSX_PAD_SQUARE   (1u << 15)

#define PKG_ID     "dev.warp-tool"
#define FEATURE_ID "warp"

/* --------------------------------------------------------------------------- */
/* Destination list: every FIELDSTG field stage (scene & 0xFF00 == 0x200) in    */
/* the EU STAGSLCT_entries[] table, grouped by region.  `mode` is the scene     */
/* value unmodified.                                                            */
/* --------------------------------------------------------------------------- */
typedef struct WarpDest {
    uint16_t    mode;
    const char *name;
    const char *region;
} WarpDest;

static const WarpDest kDests[] = {
    { 0x200, "Asuka City 1", "Asuka City" },
    { 0x201, "Asuka City 2", "Asuka City" },
    { 0x202, "Asuka Bridge", "Asuka City" },
    { 0x203, "Main Lobby", "Asuka City" },
    { 0x204, "Main Lobby (Demo)", "Asuka City" },
    { 0x205, "Asuka City 3", "Asuka City" },
    { 0x206, "Digimon Lab", "Asuka City" },
    { 0x207, "Login Room", "Asuka City" },
    { 0x208, "Arena Reception", "Asuka City" },
    { 0x209, "Digimon Arena", "Asuka City" },
    { 0x20A, "Asuka Hotel 1F", "Asuka City" },
    { 0x20B, "Underground Passage", "Asuka City" },
    { 0x20C, "Asuka Hotel 2F", "Asuka City" },
    { 0x20D, "Smith's Shop", "Asuka City" },
    { 0x20E, "Junk Shop", "Asuka City" },
    { 0x20F, "Ram Chop", "Asuka City" },
    { 0x210, "Cargo Tower", "Asuka City" },
    { 0x211, "Yellow Cruiser", "Asuka City" },
    { 0x212, "Underwater Tunnel", "Asuka City" },
    { 0x213, "El Dorado", "Asuka City" },
    { 0x214, "Admin Centre 1F", "Asuka City" },
    { 0x215, "Stairs to Basement 1", "Asuka City" },
    { 0x284, "Stairs to Basement 2", "Asuka City" },
    { 0x216, "Prison Tower", "Asuka City" },
    { 0x217, "Admin Centre 2F", "Asuka City" },
    { 0x218, "Master Room", "Asuka City" },
    { 0x219, "A.o.A Command Room", "Asuka City" },
    { 0x21A, "Admin Centre B1F", "Asuka City" },
    { 0x21B, "Asuka Aqueduct", "Asuka City" },
    { 0x21C, "Control Room", "Asuka City" },
    { 0x21D, "Central Park", "Asuka City" },
    { 0x21E, "Wire Forest Entrance", "Asuka City" },
    { 0x21F, "Shell Beach", "Wire Forest & Coast" },
    { 0x220, "Plug Cape", "Wire Forest & Coast" },
    { 0x221, "Wire Forest West", "Wire Forest & Coast" },
    { 0x222, "Wire Forest East", "Wire Forest & Coast" },
    { 0x223, "Forest Hotel", "Wire Forest & Coast" },
    { 0x224, "Forest Hotel Cellar", "Wire Forest & Coast" },
    { 0x225, "Protocol Forest", "Wire Forest & Coast" },
    { 0x226, "Protocol Ruins", "Wire Forest & Coast" },
    { 0x227, "Hangyomon Pond", "Wire Forest & Coast" },
    { 0x228, "Duel Island", "Wire Forest & Coast" },
    { 0x229, "Windy Plains", "Chinlon & Tyranno" },
    { 0x22A, "Keler Forest", "Chinlon & Tyranno" },
    { 0x22B, "Tyranno Valley", "Chinlon & Tyranno" },
    { 0x22C, "East Station", "Chinlon & Tyranno" },
    { 0x22D, "Deeper Crack", "Chinlon & Tyranno" },
    { 0x22E, "Chinlon City", "Chinlon & Tyranno" },
    { 0x22F, "Breeze Tower", "Chinlon & Tyranno" },
    { 0x230, "Chinlon Tower", "Chinlon & Tyranno" },
    { 0x231, "Gale Tower", "Chinlon & Tyranno" },
    { 0x232, "South Station", "Chinlon & Tyranno" },
    { 0x233, "Bulk Swamp", "Chinlon & Tyranno" },
    { 0x234, "Bulk Bridge", "Chinlon & Tyranno" },
    { 0x235, "Bios Swamp", "Chinlon & Tyranno" },
    { 0x236, "Altar of Justice", "Chinlon & Tyranno" },
    { 0x237, "Peaceful Swamp", "Chinlon & Tyranno" },
    { 0x238, "Swamp Hotel", "Chinlon & Tyranno" },
    { 0x239, "Shaman House", "Chinlon & Tyranno" },
    { 0x23A, "Jungle Graveyard", "Chinlon & Tyranno" },
    { 0x23B, "Phoenix Cove", "Chinlon & Tyranno" },
    { 0x23C, "Itha Jungle", "Chinlon & Tyranno" },
    { 0x23D, "South Cape", "Chinlon & Tyranno" },
    { 0x23E, "Suzaku City", "Suzaku" },
    { 0x23F, "Suzaku Hotel", "Suzaku" },
    { 0x240, "Suzaku Hall", "Suzaku" },
    { 0x241, "Suzaku Underground Lake", "Suzaku" },
    { 0x242, "Jungle Shrine", "Suzaku" },
    { 0x243, "Catacomb 1", "Suzaku" },
    { 0x244, "Catacomb 2", "Suzaku" },
    { 0x245, "Bug Maze", "Suzaku" },
    { 0x246, "Bug Maze Bottom", "Suzaku" },
    { 0x247, "South Wind Wasteland", "Suzaku" },
    { 0x248, "Noise Desert", "Suzaku" },
    { 0x249, "Peltier Oasis", "Suzaku" },
    { 0x24A, "North Wind Wasteland W", "Suzaku" },
    { 0x24B, "North Wind Wasteland E", "Suzaku" },
    { 0x24C, "Bullet Valley", "Suzaku" },
    { 0x24D, "Dumdum Factory", "Suzaku" },
    { 0x24E, "Duct Room 01", "Byakko" },
    { 0x24F, "Duct Room 02", "Byakko" },
    { 0x250, "Duct Room 03", "Byakko" },
    { 0x251, "Duct Room 04", "Byakko" },
    { 0x252, "Operation Room", "Byakko" },
    { 0x253, "Secret Stairs", "Byakko" },
    { 0x254, "Sewers", "Byakko" },
    { 0x255, "Secret Room 1", "Byakko" },
    { 0x256, "Secret Room 2", "Byakko" },
    { 0x257, "Noise Desert South", "Byakko" },
    { 0x258, "Mugen Desert 1", "Byakko" },
    { 0x259, "Mugen Desert 2", "Byakko" },
    { 0x25A, "Mirage Tower", "Byakko" },
    { 0x25B, "Mirage Hall", "Byakko" },
    { 0x25C, "Mirage Room", "Byakko" },
    { 0x25D, "Byakko City", "Byakko" },
    { 0x25E, "Byakko Dome", "Byakko" },
    { 0x25F, "Storage Room", "Byakko" },
    { 0x260, "Underground Cave", "Byakko" },
    { 0x261, "Boot Mountain", "Genbu & Krohn" },
    { 0x262, "Snow Mountain", "Genbu & Krohn" },
    { 0x263, "Mountain Hotel", "Genbu & Krohn" },
    { 0x264, "Freeze Mountain", "Genbu & Krohn" },
    { 0x265, "Kron Mine", "Genbu & Krohn" },
    { 0x266, "Ice Lake", "Genbu & Krohn" },
    { 0x267, "Legendary Gym", "Genbu & Krohn" },
    { 0x268, "Kron Pit", "Genbu & Krohn" },
    { 0x269, "Kron Weapon Shop", "Genbu & Krohn" },
    { 0x26A, "Ice Dungeon", "Genbu & Krohn" },
    { 0x26B, "Fire Dungeon", "Genbu & Krohn" },
    { 0x26C, "Dark Dungeon", "Genbu & Krohn" },
    { 0x26D, "Chamber Room", "Genbu & Krohn" },
    { 0x26E, "Battle Gate", "Genbu & Krohn" },
    { 0x26F, "Genbu City", "Genbu & Krohn" },
    { 0x2D7, "Street Corner", "Magasta" },
    { 0x2D8, "Online Centre", "Magasta" },
    { 0x2D9, "Chamber Room", "Magasta" },
    { 0x2DA, "Magasta B1F", "Magasta" },
    { 0x2DB, "Magasta B2F", "Magasta" },
    { 0x2DC, "Magasta 1F", "Magasta" },
    { 0x2DD, "Gunslinger 1F", "Magasta" },
    { 0x2DE, "Gunslinger 2F", "Magasta" },
    { 0x2DF, "Command Room", "Magasta" },
    { 0x2E0, "Seabed 1", "Magasta" },
    { 0x2E1, "Seabed 2", "Magasta" },
    { 0x2E2, "Seabed 3", "Magasta" },
    { 0x2E3, "Seabed 4", "Magasta" },
    { 0x2E4, "Seabed 5", "Magasta" },
    { 0x2E5, "Seabed 6", "Magasta" },
    { 0x2E6, "Seabed 7", "Magasta" },
    { 0x2E7, "Seabed 8", "Magasta" },
    { 0x2E8, "Depths 1", "Magasta" },
    { 0x2E9, "Depths 2", "Magasta" },
    { 0x2EA, "Depths 3", "Magasta" },
    { 0x2EB, "Depths 4", "Magasta" },
    { 0x2EC, "Depths 5", "Magasta" },
    { 0x2ED, "Depths 6", "Magasta" },
    { 0x2EE, "Depths 7", "Magasta" },
    { 0x270, "Amaterasu 0x270", "Amaterasu alternates" },
    { 0x271, "Amaterasu 0x271", "Amaterasu alternates" },
    { 0x272, "Amaterasu 0x272", "Amaterasu alternates" },
    { 0x273, "Amaterasu 0x273", "Amaterasu alternates" },
    { 0x274, "Amaterasu 0x274", "Amaterasu alternates" },
    { 0x275, "Amaterasu 0x275", "Amaterasu alternates" },
    { 0x276, "Amaterasu 0x276", "Amaterasu alternates" },
    { 0x277, "Amaterasu 0x277", "Amaterasu alternates" },
    { 0x278, "Amaterasu 0x278", "Amaterasu alternates" },
    { 0x279, "Amaterasu 0x279", "Amaterasu alternates" },
    { 0x27A, "Amaterasu 0x27A", "Amaterasu alternates" },
    { 0x27B, "Amaterasu 0x27B", "Amaterasu alternates" },
    { 0x27C, "Amaterasu 0x27C", "Amaterasu alternates" },
    { 0x27D, "Amaterasu 0x27D", "Amaterasu alternates" },
    { 0x27E, "Amaterasu 0x27E", "Amaterasu alternates" },
    { 0x27F, "Amaterasu 0x27F", "Amaterasu alternates" },
    { 0x280, "Amaterasu 0x280", "Amaterasu alternates" },
    { 0x281, "Amaterasu 0x281", "Amaterasu alternates" },
    { 0x282, "Amaterasu 0x282", "Amaterasu alternates" },
    { 0x283, "Amaterasu 0x283", "Amaterasu alternates" },
    { 0x285, "Amaterasu 0x285", "Amaterasu alternates" },
    { 0x286, "Amaterasu 0x286", "Amaterasu alternates" },
    { 0x287, "Amaterasu 0x287", "Amaterasu alternates" },
    { 0x288, "Amaterasu 0x288", "Amaterasu alternates" },
    { 0x289, "Amaterasu 0x289", "Amaterasu alternates" },
    { 0x28A, "Amaterasu 0x28A", "Amaterasu alternates" },
    { 0x28B, "Amaterasu 0x28B", "Amaterasu alternates" },
    { 0x28C, "Amaterasu 0x28C", "Amaterasu alternates" },
    { 0x28D, "Amaterasu 0x28D", "Amaterasu alternates" },
    { 0x28E, "Amaterasu 0x28E", "Amaterasu alternates" },
    { 0x28F, "Amaterasu 0x28F", "Amaterasu alternates" },
    { 0x290, "Amaterasu 0x290", "Amaterasu alternates" },
    { 0x291, "Amaterasu 0x291", "Amaterasu alternates" },
    { 0x292, "Amaterasu 0x292", "Amaterasu alternates" },
    { 0x293, "Amaterasu 0x293", "Amaterasu alternates" },
    { 0x294, "Amaterasu 0x294", "Amaterasu alternates" },
    { 0x295, "Amaterasu 0x295", "Amaterasu alternates" },
    { 0x296, "Amaterasu 0x296", "Amaterasu alternates" },
    { 0x297, "Amaterasu 0x297", "Amaterasu alternates" },
    { 0x298, "Amaterasu 0x298", "Amaterasu alternates" },
    { 0x299, "Amaterasu 0x299", "Amaterasu alternates" },
    { 0x29A, "Amaterasu 0x29A", "Amaterasu alternates" },
    { 0x29B, "Amaterasu 0x29B", "Amaterasu alternates" },
    { 0x29C, "Amaterasu 0x29C", "Amaterasu alternates" },
    { 0x29D, "Amaterasu 0x29D", "Amaterasu alternates" },
    { 0x29E, "Amaterasu 0x29E", "Amaterasu alternates" },
    { 0x29F, "Amaterasu 0x29F", "Amaterasu alternates" },
    { 0x2A0, "Amaterasu 0x2A0", "Amaterasu alternates" },
    { 0x2A1, "Amaterasu 0x2A1", "Amaterasu alternates" },
    { 0x2A2, "Amaterasu 0x2A2", "Amaterasu alternates" },
    { 0x2A3, "Amaterasu 0x2A3", "Amaterasu alternates" },
    { 0x2A4, "Amaterasu 0x2A4", "Amaterasu alternates" },
    { 0x2A5, "Amaterasu 0x2A5", "Amaterasu alternates" },
    { 0x2A6, "Amaterasu 0x2A6", "Amaterasu alternates" },
    { 0x2A7, "Amaterasu 0x2A7", "Amaterasu alternates" },
    { 0x2A8, "Amaterasu 0x2A8", "Amaterasu alternates" },
    { 0x2A9, "Amaterasu 0x2A9", "Amaterasu alternates" },
    { 0x2AA, "Amaterasu 0x2AA", "Amaterasu alternates" },
    { 0x2AB, "Amaterasu 0x2AB", "Amaterasu alternates" },
    { 0x2AC, "Amaterasu 0x2AC", "Amaterasu alternates" },
    { 0x2AD, "Amaterasu 0x2AD", "Amaterasu alternates" },
    { 0x2AE, "Amaterasu 0x2AE", "Amaterasu alternates" },
    { 0x2AF, "Amaterasu 0x2AF", "Amaterasu alternates" },
    { 0x2B0, "Amaterasu 0x2B0", "Amaterasu alternates" },
    { 0x2B1, "Amaterasu 0x2B1", "Amaterasu alternates" },
    { 0x2B2, "Amaterasu 0x2B2", "Amaterasu alternates" },
    { 0x2B3, "Amaterasu 0x2B3", "Amaterasu alternates" },
    { 0x2B4, "Amaterasu 0x2B4", "Amaterasu alternates" },
    { 0x2B5, "Amaterasu 0x2B5", "Amaterasu alternates" },
    { 0x2B6, "Amaterasu 0x2B6", "Amaterasu alternates" },
    { 0x2B7, "Amaterasu 0x2B7", "Amaterasu alternates" },
    { 0x2B8, "Amaterasu 0x2B8", "Amaterasu alternates" },
    { 0x2B9, "Amaterasu 0x2B9", "Amaterasu alternates" },
    { 0x2BA, "Amaterasu 0x2BA", "Amaterasu alternates" },
    { 0x2BB, "Amaterasu 0x2BB", "Amaterasu alternates" },
    { 0x2BC, "Amaterasu 0x2BC", "Amaterasu alternates" },
    { 0x2BD, "Amaterasu 0x2BD", "Amaterasu alternates" },
    { 0x2BE, "Amaterasu 0x2BE", "Amaterasu alternates" },
    { 0x2BF, "Amaterasu 0x2BF", "Amaterasu alternates" },
    { 0x2C0, "Amaterasu 0x2C0", "Amaterasu alternates" },
    { 0x2C1, "Amaterasu 0x2C1", "Amaterasu alternates" },
    { 0x2C2, "Amaterasu 0x2C2", "Amaterasu alternates" },
    { 0x2C3, "Amaterasu 0x2C3", "Amaterasu alternates" },
    { 0x2C4, "Amaterasu 0x2C4", "Amaterasu alternates" },
    { 0x2C5, "Amaterasu 0x2C5", "Amaterasu alternates" },
    { 0x2C6, "Amaterasu 0x2C6", "Amaterasu alternates" },
    { 0x2C7, "Amaterasu 0x2C7", "Amaterasu alternates" },
    { 0x2C8, "Amaterasu 0x2C8", "Amaterasu alternates" },
    { 0x2C9, "Amaterasu 0x2C9", "Amaterasu alternates" },
    { 0x2CA, "Amaterasu 0x2CA", "Amaterasu alternates" },
    { 0x2CB, "Amaterasu 0x2CB", "Amaterasu alternates" },
    { 0x2CC, "Amaterasu 0x2CC", "Amaterasu alternates" },
    { 0x2CD, "Amaterasu 0x2CD", "Amaterasu alternates" },
    { 0x2CE, "Amaterasu 0x2CE", "Amaterasu alternates" },
    { 0x2CF, "Amaterasu 0x2CF", "Amaterasu alternates" },
    { 0x2D0, "Amaterasu 0x2D0", "Amaterasu alternates" },
    { 0x2D1, "Amaterasu 0x2D1", "Amaterasu alternates" },
    { 0x2D2, "Amaterasu 0x2D2", "Amaterasu alternates" },
    { 0x2D3, "Amaterasu 0x2D3", "Amaterasu alternates" },
    { 0x2D4, "Amaterasu 0x2D4", "Amaterasu alternates" },
    { 0x2D5, "Amaterasu 0x2D5", "Amaterasu alternates" },
    { 0x2D6, "Amaterasu 0x2D6", "Amaterasu alternates" },
};
#define DEST_COUNT ((int)(sizeof kDests / sizeof kDests[0]))

/* --- the modal's own state ------------------------------------------------ */
static int      s_dest_index = 6;    /* default Digimon Lab (0x206) */
static int      s_modal = 0;         /* our FAST TRAVEL screen is open */
static int      s_modal_saved_inn = 0;
static uint16_t s_prev_pad = 0xFFFF; /* PS1 active-low pad, previous vblank */
static int      s_rep_dir = 0;       /* auto-repeat: -1 up, +1 down */
static int      s_rep_timer = 0;
static unsigned s_warp_count = 0;
static unsigned s_modal_count = 0;

/*
 * The panel is COMPOSED only when its content changes and BLITTED only then
 * too.  s_present_sig is a hash of "what the screen should be showing"; when
 * it matches the last presented hash the vblank callback does NO VRAM or GL
 * work at all.  (Re-composing and re-uploading the whole 304x224 panel every
 * vblank put a CPU->VRAM transfer plus a GL texture upload + FBO blit into
 * the frame, immediately before the present, 60 times a second while the
 * screen was open - the one per-frame host cost the mod added.)
 */
static unsigned s_present_sig = 0;   /* 0 = nothing presented            */
static int      s_disabled = 0;      /* region self-test failed          */
static int      s_region_checked = 0;/* the self-test has run            */
static unsigned s_present_count = 0; /* diagnostic: real panels presented */

static int      s_boot_mode = 0;
static int      s_booted = 0;
static int      s_force_show = 0;    /* DW3_WARP_SHOW=1: force the modal up */
static int      s_allow_menu = 0;    /* DW3_WARP_MENU=1: legacy in-menu dev picker */
static const char *s_shot = NULL;    /* DW3_WARP_SHOT=<prefix>: dump the frame */
static int      s_shot_n = 0;
static int      s_shot_step = 45;    /* DW3_WARP_SHOT_STEP: dump every Nth frame */
static unsigned s_frame = 0;
static unsigned s_confirm_at = 0;
#define CONFIRM_FRAMES 150u          /* ~2.5 s at 60 Hz */

/* ==========================================================================
 * Software text/panel compositor.  Builds an RGB555 panel in a static buffer,
 * then blits it once into guest VRAM with the runtime's transfer path.
 * ======================================================================== */

/* Public-domain 8x8 ASCII 32..126 (same table the runtime's own OSD uses,
 * host_osd.c), row bitmasks with bit 0 = leftmost pixel. */
static const unsigned char kFont8x8[95][8] = {
    {0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00}, /*   */
    {0x18,0x3C,0x3C,0x18,0x18,0x00,0x18,0x00}, /* ! */
    {0x36,0x36,0x00,0x00,0x00,0x00,0x00,0x00}, /* " */
    {0x36,0x36,0x7F,0x36,0x7F,0x36,0x36,0x00}, /* # */
    {0x0C,0x3E,0x03,0x1E,0x30,0x1F,0x0C,0x00}, /* $ */
    {0x00,0x63,0x33,0x18,0x0C,0x66,0x63,0x00}, /* % */
    {0x1C,0x36,0x1C,0x6E,0x3B,0x33,0x6E,0x00}, /* & */
    {0x06,0x06,0x03,0x00,0x00,0x00,0x00,0x00}, /* ' */
    {0x18,0x0C,0x06,0x06,0x06,0x0C,0x18,0x00}, /* ( */
    {0x06,0x0C,0x18,0x18,0x18,0x0C,0x06,0x00}, /* ) */
    {0x00,0x66,0x3C,0xFF,0x3C,0x66,0x00,0x00}, /* * */
    {0x00,0x0C,0x0C,0x3F,0x0C,0x0C,0x00,0x00}, /* + */
    {0x00,0x00,0x00,0x00,0x00,0x0C,0x0C,0x06}, /* , */
    {0x00,0x00,0x00,0x3F,0x00,0x00,0x00,0x00}, /* - */
    {0x00,0x00,0x00,0x00,0x00,0x0C,0x0C,0x00}, /* . */
    {0x60,0x30,0x18,0x0C,0x06,0x03,0x01,0x00}, /* / */
    {0x3E,0x63,0x73,0x7B,0x6F,0x67,0x3E,0x00}, /* 0 */
    {0x0C,0x0E,0x0C,0x0C,0x0C,0x0C,0x3F,0x00}, /* 1 */
    {0x1E,0x33,0x30,0x1C,0x06,0x33,0x3F,0x00}, /* 2 */
    {0x1E,0x33,0x30,0x1C,0x30,0x33,0x1E,0x00}, /* 3 */
    {0x38,0x3C,0x36,0x33,0x7F,0x30,0x78,0x00}, /* 4 */
    {0x3F,0x03,0x1F,0x30,0x30,0x33,0x1E,0x00}, /* 5 */
    {0x1C,0x06,0x03,0x1F,0x33,0x33,0x1E,0x00}, /* 6 */
    {0x3F,0x33,0x30,0x18,0x0C,0x0C,0x0C,0x00}, /* 7 */
    {0x1E,0x33,0x33,0x1E,0x33,0x33,0x1E,0x00}, /* 8 */
    {0x1E,0x33,0x33,0x3E,0x30,0x18,0x0E,0x00}, /* 9 */
    {0x00,0x0C,0x0C,0x00,0x00,0x0C,0x0C,0x00}, /* : */
    {0x00,0x0C,0x0C,0x00,0x00,0x0C,0x0C,0x06}, /* ; */
    {0x18,0x0C,0x06,0x03,0x06,0x0C,0x18,0x00}, /* < */
    {0x00,0x00,0x3F,0x00,0x00,0x3F,0x00,0x00}, /* = */
    {0x06,0x0C,0x18,0x30,0x18,0x0C,0x06,0x00}, /* > */
    {0x1E,0x33,0x30,0x18,0x0C,0x00,0x0C,0x00}, /* ? */
    {0x3E,0x63,0x7B,0x7B,0x7B,0x03,0x1E,0x00}, /* @ */
    {0x0C,0x1E,0x33,0x33,0x3F,0x33,0x33,0x00}, /* A */
    {0x3F,0x66,0x66,0x3E,0x66,0x66,0x3F,0x00}, /* B */
    {0x3C,0x66,0x03,0x03,0x03,0x66,0x3C,0x00}, /* C */
    {0x1F,0x36,0x66,0x66,0x66,0x36,0x1F,0x00}, /* D */
    {0x7F,0x06,0x06,0x3E,0x06,0x06,0x7F,0x00}, /* E */
    {0x7F,0x06,0x06,0x3E,0x06,0x06,0x06,0x00}, /* F */
    {0x3C,0x66,0x03,0x03,0x73,0x66,0x7C,0x00}, /* G */
    {0x33,0x33,0x33,0x3F,0x33,0x33,0x33,0x00}, /* H */
    {0x1E,0x0C,0x0C,0x0C,0x0C,0x0C,0x1E,0x00}, /* I */
    {0x78,0x30,0x30,0x30,0x33,0x33,0x1E,0x00}, /* J */
    {0x67,0x66,0x36,0x1E,0x36,0x66,0x67,0x00}, /* K */
    {0x06,0x06,0x06,0x06,0x06,0x06,0x7F,0x00}, /* L */
    {0x63,0x77,0x7F,0x7F,0x6B,0x63,0x63,0x00}, /* M */
    {0x63,0x67,0x6F,0x7B,0x73,0x63,0x63,0x00}, /* N */
    {0x1C,0x36,0x63,0x63,0x63,0x36,0x1C,0x00}, /* O */
    {0x3F,0x66,0x66,0x3E,0x06,0x06,0x06,0x00}, /* P */
    {0x1E,0x33,0x33,0x33,0x3B,0x1E,0x38,0x00}, /* Q */
    {0x3F,0x66,0x66,0x3E,0x36,0x66,0x67,0x00}, /* R */
    {0x1E,0x33,0x07,0x0E,0x38,0x33,0x1E,0x00}, /* S */
    {0x3F,0x2D,0x0C,0x0C,0x0C,0x0C,0x1E,0x00}, /* T */
    {0x33,0x33,0x33,0x33,0x33,0x33,0x3F,0x00}, /* U */
    {0x33,0x33,0x33,0x33,0x33,0x1E,0x0C,0x00}, /* V */
    {0x63,0x63,0x63,0x6B,0x7F,0x77,0x63,0x00}, /* W */
    {0x63,0x63,0x36,0x1C,0x1C,0x36,0x63,0x00}, /* X */
    {0x33,0x33,0x33,0x1E,0x0C,0x0C,0x1E,0x00}, /* Y */
    {0x7F,0x63,0x31,0x18,0x4C,0x66,0x7F,0x00}, /* Z */
    {0x1E,0x06,0x06,0x06,0x06,0x06,0x1E,0x00}, /* [ */
    {0x03,0x06,0x0C,0x18,0x30,0x60,0x40,0x00}, /* \ */
    {0x1E,0x18,0x18,0x18,0x18,0x18,0x1E,0x00}, /* ] */
    {0x08,0x1C,0x36,0x63,0x00,0x00,0x00,0x00}, /* ^ */
    {0x00,0x00,0x00,0x00,0x00,0x00,0x00,0xFF}, /* _ */
    {0x0C,0x0C,0x18,0x00,0x00,0x00,0x00,0x00}, /* ` */
    {0x00,0x00,0x1E,0x30,0x3E,0x33,0x6E,0x00}, /* a */
    {0x07,0x06,0x06,0x3E,0x66,0x66,0x3B,0x00}, /* b */
    {0x00,0x00,0x1E,0x33,0x03,0x33,0x1E,0x00}, /* c */
    {0x38,0x30,0x30,0x3e,0x33,0x33,0x6E,0x00}, /* d */
    {0x00,0x00,0x1E,0x33,0x3f,0x03,0x1E,0x00}, /* e */
    {0x1C,0x36,0x06,0x0f,0x06,0x06,0x0f,0x00}, /* f */
    {0x00,0x00,0x6E,0x33,0x33,0x3E,0x30,0x1F}, /* g */
    {0x07,0x06,0x36,0x6E,0x66,0x66,0x67,0x00}, /* h */
    {0x0C,0x00,0x0E,0x0C,0x0C,0x0C,0x1E,0x00}, /* i */
    {0x30,0x00,0x30,0x30,0x30,0x33,0x33,0x1E}, /* j */
    {0x07,0x06,0x66,0x36,0x1E,0x36,0x67,0x00}, /* k */
    {0x0E,0x0C,0x0C,0x0C,0x0C,0x0C,0x1E,0x00}, /* l */
    {0x00,0x00,0x33,0x7F,0x7F,0x6B,0x63,0x00}, /* m */
    {0x00,0x00,0x1F,0x33,0x33,0x33,0x33,0x00}, /* n */
    {0x00,0x00,0x1E,0x33,0x33,0x33,0x1E,0x00}, /* o */
    {0x00,0x00,0x3B,0x66,0x66,0x3E,0x06,0x0F}, /* p */
    {0x00,0x00,0x6E,0x33,0x33,0x3E,0x30,0x78}, /* q */
    {0x00,0x00,0x3B,0x6E,0x66,0x06,0x0F,0x00}, /* r */
    {0x00,0x00,0x3E,0x03,0x1E,0x30,0x1F,0x00}, /* s */
    {0x08,0x0C,0x3E,0x0C,0x0C,0x2C,0x18,0x00}, /* t */
    {0x00,0x00,0x33,0x33,0x33,0x33,0x6E,0x00}, /* u */
    {0x00,0x00,0x33,0x33,0x33,0x1E,0x0C,0x00}, /* v */
    {0x00,0x00,0x63,0x6B,0x7F,0x7F,0x36,0x00}, /* w */
    {0x00,0x00,0x63,0x36,0x1C,0x36,0x63,0x00}, /* x */
    {0x00,0x00,0x33,0x33,0x33,0x3E,0x30,0x1F}, /* y */
    {0x00,0x00,0x3F,0x19,0x0C,0x26,0x3F,0x00}, /* z */
    {0x38,0x0C,0x0C,0x07,0x0C,0x0C,0x38,0x00}, /* { */
    {0x18,0x18,0x18,0x00,0x18,0x18,0x18,0x00}, /* | */
    {0x07,0x0C,0x0C,0x38,0x0C,0x0C,0x07,0x00}, /* } */
    {0x6E,0x3B,0x00,0x00,0x00,0x00,0x00,0x00}, /* ~ */
};

/* RGB555 (PS1 direct colour: bits 0-4 R, 5-9 G, 10-14 B). */
#define C(r,g,b) ((uint16_t)(((b) << 10) | ((g) << 5) | (r)))
#define COL_PANEL   C( 1, 2, 9)    /* opaque navy, the modal background     */
#define COL_EDGE2   C(20,26,31)    /* bright frame of the modal             */
#define COL_TEXT    C(31,31,31)    /* white                                 */
#define COL_DIM     C(15,18,24)    /* grey                                  */
#define COL_HEAD    C(31,26, 6)    /* amber "FAST TRAVEL" header            */
#define COL_CURBG   C( 2,12,31)    /* selected-row background               */
#define COL_CURTXT  C(31,31,14)    /* selected-row text (bright yellow)     */
#define COL_OKBG    C( 0,22, 6)    /* confirmation strip background         */
#define COL_OKTXT   C(31,31,31)    /* confirmation strip text               */

#define OV_MAXW 384
#define OV_MAXH 288
static uint16_t s_ov[OV_MAXW * OV_MAXH];
static uint16_t s_pack[OV_MAXW * OV_MAXH];

static void ov_fill(int x, int y, int w, int h, uint16_t col) {
    int i, j;
    for (j = 0; j < h; j++) {
        uint16_t *row;
        int yy = y + j;
        if (yy < 0 || yy >= OV_MAXH) continue;
        row = s_ov + (size_t)yy * OV_MAXW;
        for (i = 0; i < w; i++) {
            int xx = x + i;
            if (xx < 0 || xx >= OV_MAXW) continue;
            row[xx] = col;
        }
    }
}

static void ov_char(int x, int y, int ch, uint16_t col) {
    const unsigned char *g;
    int r, b;
    if (ch < 32 || ch > 126) ch = '?';
    g = kFont8x8[ch - 32];
    for (r = 0; r < 8; r++) {
        uint16_t *row;
        int yy = y + r;
        if (yy < 0 || yy >= OV_MAXH) continue;
        row = s_ov + (size_t)yy * OV_MAXW;
        for (b = 0; b < 8; b++) {
            if (g[r] & (1u << b)) {
                int xx = x + b;
                if (xx >= 0 && xx < OV_MAXW) row[xx] = col;
            }
        }
    }
}

static void ov_text(int x, int y, const char *s, uint16_t col) {
    for (; *s; s++, x += 8) ov_char(x, y, (unsigned char)*s, col);
}
static int ov_textw(const char *s) { return 8 * (int)strlen(s); }

/* Copy the composed panel into the displayed framebuffer at (ox,oy).
 * PACK once (compose time) - gr_vram_transfer_in needs row pitch == w and the
 * re-blit path must not repeat this copy every vblank. */
static int  s_pack_ox, s_pack_oy, s_pack_w, s_pack_h, s_pack_valid = 0;

static void ov_pack(int ox, int oy, int w, int h) {
    int y;
    if (w > OV_MAXW) w = OV_MAXW;
    if (h > OV_MAXH) h = OV_MAXH;
    if (w <= 0 || h <= 0) { s_pack_valid = 0; return; }
    for (y = 0; y < h; y++)
        memcpy(s_pack + (size_t)y * w, s_ov + (size_t)y * OV_MAXW,
               (size_t)w * sizeof(uint16_t));
    s_pack_ox = ox;
    s_pack_oy = oy;
    s_pack_w = w;
    s_pack_h = h;
    s_pack_valid = 1;
}

/* The displayed band's origin must be read fresh every blit: the game
 * alternates the display start between its two framebuffers, so a destination
 * cached at compose time lands off-screen on alternate frames. */
static int ov_target(int *dx, int *dy) {
    GpuDisplayInfo di;
    if (!s_pack_valid) return 0;
    gpu_get_display_info(&di);
    if (di.disabled) return 0;
    *dx = (int)di.display_x + s_pack_ox;
    *dy = (int)di.display_y + s_pack_oy;
    return 1;
}

/* Blit the packed panel: CPU->VRAM transfer, then flush the GL upload so the
 * FBO is authoritative with our pixels before the present syncs it back. */
static void ov_blit(void) {
    int dx, dy;
    if (!ov_target(&dx, &dy)) return;
    gr_vram_transfer_in(dx, dy, s_pack_w, s_pack_h, s_pack);
    if (gr_backend() == GR_BACKEND_OPENGL) gl_renderer_flush_cpu_uploads();
}

/* ==========================================================================
 * The modal FAST TRAVEL screen.  Opaque, full-display panel; the game's own
 * frame is underneath and never shows through.
 * ======================================================================== */
#define OV_LINE 10
#define OV_PADX 6
#define OV_PADY 5
#define OV_MARGIN 8

static int s_ov_w, s_ov_h;

/* Build the modal panel at the given panel size; returns its height. */
static int ov_build_modal(int w, int h) {
    char line[96];
    int i, y, rows, first, n = DEST_COUNT;
    const int hdr = 2, ftr = 2;

    rows = (h - OV_PADY * 2 - OV_LINE * (hdr + ftr)) / OV_LINE;
    if (rows < 1) rows = 1;
    first = s_dest_index - rows / 2;
    if (first < 0) first = 0;
    if (first + rows > n) first = n - rows;
    if (first < 0) first = 0;

    ov_fill(0, 0, w, h, COL_PANEL);
    ov_fill(0, 0, w, 2, COL_EDGE2);
    ov_fill(0, h - 2, w, 2, COL_EDGE2);
    ov_fill(0, 0, 2, h, COL_EDGE2);
    ov_fill(w - 2, 0, 2, h, COL_EDGE2);

    y = OV_PADY;
    ov_text(OV_PADX, y, "FAST TRAVEL", COL_HEAD);
    sprintf(line, "%d/%d", s_dest_index + 1, n);
    ov_text(w - OV_PADX - ov_textw(line), y, line, COL_TEXT);
    y += OV_LINE;
    sprintf(line, "Region: %s", kDests[s_dest_index].region);
    ov_text(OV_PADX, y, line, COL_DIM);
    sprintf(line, "%d-%d", first + 1, first + rows);
    ov_text(w - OV_PADX - ov_textw(line), y, line, COL_DIM);
    y += OV_LINE;

    for (i = 0; i < rows; i++) {
        int idx = first + i;
        const char *nm;
        if (idx >= n) break;
        nm = kDests[idx].name;
        if (idx == s_dest_index) {
            ov_fill(OV_PADX - 3, y - 1, w - 2 * (OV_PADX - 3), OV_LINE, COL_CURBG);
            sprintf(line, "> %s", nm);
            ov_text(OV_PADX, y, line, COL_CURTXT);
        } else {
            sprintf(line, "   %s", nm);
            ov_text(OV_PADX, y, line, COL_TEXT);
        }
        y += OV_LINE;
    }

    y = h - OV_PADY - OV_LINE * ftr;
    ov_text(OV_PADX, y, "D-PAD move   L1/R1 page   TRI: exit", COL_DIM);
    y += OV_LINE;
    sprintf(line, "CROSS/X = WARP to %s", kDests[s_dest_index].name);
    ov_text(OV_PADX, y, line, COL_TEXT);

    if (w > s_ov_w) s_ov_w = w;
    if (h > s_ov_h) s_ov_h = h;
    return h;
}

/* The green confirmation strip ("WARPED TO <name>"). */
static void ov_build_confirm(int oy) {
    char line[96];
    int w, h;
    sprintf(line, "WARPED TO %s", kDests[s_dest_index].name);
    w = OV_PADX * 2 + ov_textw(line);
    if (w > OV_MAXW) w = OV_MAXW;
    h = OV_PADY * 2 + 8;
    ov_fill(0, oy, w, h, COL_OKBG);
    ov_fill(0, oy, w, 2, COL_EDGE2);
    ov_fill(0, oy + h - 2, w, 2, COL_EDGE2);
    ov_text(OV_PADX, oy + OV_PADY, line, COL_OKTXT);
    if (w > s_ov_w) s_ov_w = w;
    if (oy + h > s_ov_h) s_ov_h = oy + h;
}

/* Panel geometry for the current display. */
static void ov_modal_size(int *w, int *h) {
    GpuDisplayInfo di;
    gpu_get_display_info(&di);
    *w = (di.disabled ? 320 : (int)di.width) - 2 * OV_MARGIN;
    *h = (di.disabled ? 240 : (int)di.height) - 2 * OV_MARGIN;
    if (*w < 160) *w = 304;
    if (*h < 120) *h = 224;
    if (*w > OV_MAXW) *w = OV_MAXW;
    if (*h > OV_MAXH) *h = OV_MAXH;
}

/* --- diagnostic: is the panel really in the PRESENTED frame? --------------
 * DW3_WARP_DIAG=<file> appends one line per vblank while the screen is up:
 *
 *   f=<frame> dx=<display_x> dy=<display_y> be=<backend> sig=<hex> comp=<0|1> blit=<N> fbo=<0|1|-1> mcur=<n> malt=<n>
 *
 * 'comp' is 1 on the vblanks that recomposed the panel (content changed), 'blit'
 * is what it actually did (1 re-blit from the cache), and 'fbo' asks
 * gl_renderer_fbo_peek whether the packed panel really is in the GPU-side
 * framebuffer at the display origin - the surface the present scans out - and
 * is -1 where there is no GL context (headless: the CPU array is the surface).
 * fbo_peek reads FBO truth WITHOUT writing CPU VRAM, so the probe cannot change
 * what the next vblank sees.  mcur/malt are full-band compares of the CPU VRAM
 * array against the packed panel at the origin this frame presents (mcur) and at
 * the other origin of the display-start pair (malt); mcur==0 means the panel is
 * present in the frame that will be scanned out. */
extern int gl_renderer_fbo_peek(int x, int y, int w, int h, uint16_t *out);
extern uint16_t *gpu_get_vram_ptr(void);
static const char *s_diag_path;
static FILE *s_diag;
static int   s_diag_tried;
static void ov_diag(const char *path, unsigned frame, unsigned sig,
                    int comp, int blit)
{
    GpuDisplayInfo di;
    uint16_t px[16 * 16];
    int x, y, i, j, present = -1;
    uint16_t *vram;
    int dy_alt, miss_cur = -1, miss_alt = -1;
    if (!s_diag) {
        if (s_diag_tried || !path) return;
        s_diag_tried = 1;
        s_diag = fopen(path, "w");
        if (!s_diag) return;
    }
    gpu_get_display_info(&di);
    x = (int)di.display_x + s_pack_ox + 4;
    y = (int)di.display_y + s_pack_oy + 4;
    if (s_pack_valid && !di.disabled &&
        x >= 0 && y >= 0 && x + 16 <= 1024 && y + 16 <= 512 &&
        gl_renderer_fbo_peek(x, y, 16, 16, px)) {
        present = 1;
        for (i = 0; i < 16 && present; i++)
            for (j = 0; j < 16; j++)
                if (px[i * 16 + j] !=
                    s_pack[(size_t)(4 + i) * s_pack_w + (4 + j)]) { present = 0; break; }
    }
    /* Full-band compare of the CPU VRAM array against the packed panel, at the
     * band origin this frame WILL present (mcur) and at the other origin of the
     * 0/256 pair (malt).  A panel parked at the non-displayed origin is a panel
     * nobody sees: that is exactly the flicker signature. */
    vram = gpu_get_vram_ptr();
    if (vram && s_pack_valid && !di.disabled && s_pack_w > 0 && s_pack_h > 0) {
        miss_cur = 0;
        for (i = 0; i < s_pack_h; i++) {
            const uint16_t *row = vram + (size_t)(((int)di.display_y + s_pack_oy + i) & 511) * 1024;
            const uint16_t *pk  = s_pack + (size_t)i * s_pack_w;
            for (j = 0; j < s_pack_w; j++)
                if (row[((int)di.display_x + s_pack_ox + j) & 1023] != pk[j]) miss_cur++;
        }
        dy_alt = ((int)di.display_y == 0) ? 256 : 0;
        miss_alt = 0;
        for (i = 0; i < s_pack_h; i++) {
            const uint16_t *row = vram + (size_t)((dy_alt + s_pack_oy + i) & 511) * 1024;
            const uint16_t *pk  = s_pack + (size_t)i * s_pack_w;
            for (j = 0; j < s_pack_w; j++)
                if (row[((int)di.display_x + s_pack_ox + j) & 1023] != pk[j]) miss_alt++;
        }
    }
    fprintf(s_diag,
            "f=%u dx=%d dy=%d be=%d sig=%08X comp=%d blit=%d fbo=%d mcur=%d malt=%d\n",
            frame, (int)di.display_x, (int)di.display_y, (int)gr_backend(), sig,
            comp, blit, present, miss_cur, miss_alt);
    fflush(s_diag);
}

/* Compose the panel ONLY when its content changes; BLIT the cached panel on
 * EVERY vblank.
 *
 * The recompose is the expensive half (a ~68k-pixel 1555->panel composition,
 * two ~400 KB transfers and an FBO blit per frame) and it is what stalled the
 * runtime, so it happens once per content change.  The blit of the already
 * composed, already packed panel is cheap (one memcpy of ~136 KB - 304x224
 * pixels at 2 bytes - plus the one GL upload flush the OpenGL backend needs)
 * and it is UNCONDITIONAL BY DESIGN:
 * version 1 composed AND blitted every vblank and looked right, and the only
 * thing wrong with it was the recompose.
 *
 * A conditional blit (the earlier `if (!ov_intact())`) flickered.  Its test
 * sampled the CPU VRAM array, but on the GL present path (s_cpu_auth_dual=0)
 * the guest rasterizes into the GPU framebuffer and never writes that array,
 * so the probe's "the panel is still there" verdict was about a surface the
 * present does not scan out.  Every "still there" verdict was a frame with no
 * panel in the buffer that gets displayed, and - because the game alternates
 * the display start between its two framebuffers EVERY frame (measured dy=0 on
 * even frames, dy=256 on odd ones) - those frames are exactly alternate frames,
 * i.e. a steady one-on/one-off flash. */
static void ov_tick(int modal_open) {
    int confirming = (s_confirm_at != 0u) &&
                     (s_frame - s_confirm_at < CONFIRM_FRAMES);
    unsigned sig;
    int w = 0, h = 0, composed = 0;

    if (!modal_open && !confirming) {
        s_present_sig = 0;          /* screen gone; the guest redraws it */
        s_pack_valid = 0;
        return;
    }

    if (modal_open) {
        ov_modal_size(&w, &h);
        /* content = modal + selected row + region + panel geometry */
        sig = 0x4D000000u ^ ((unsigned)s_dest_index * 0x9E3779B1u)
                          ^ ((unsigned)w * 0x85EBCA6Bu)
                          ^ ((unsigned)h * 0xC2B2AE35u);
    } else {
        /* the "WARPED TO ..." strip: static for the whole confirm window, so
         * quantise the countdown away - one compose for ~2.5 s, not 150. */
        sig = 0xC0000000u ^ ((unsigned)s_dest_index * 0x9E3779B1u);
    }

    if (sig != s_present_sig) {                 /* content changed: compose once */
        s_present_sig = sig;
        s_ov_w = 0;
        s_ov_h = 0;
        if (modal_open) {
            ov_build_modal(w, h);
        } else {
            ov_build_confirm(OV_MARGIN);
        }
        if (s_ov_w > 0 && s_ov_h > 0)
            ov_pack(OV_MARGIN, OV_MARGIN, s_ov_w, s_ov_h);
        composed = 1;
    }

    /* Every vblank: re-blit the cached packed panel at the display origin this
     * frame will actually present (ov_target re-reads gpu_get_display_info()
     * per blit, so the alternating framebuffer is handled by construction). */
    if (s_pack_valid) {
        ov_blit();
        s_present_count++;
    }
    ov_diag(s_diag_path, s_frame, sig, composed, 1);
}


/* ==========================================================================
 * Guest-side helpers.
 * ======================================================================== */

/* The live field task (FIELD_TASK_FIELD), or 0. */
static uint32_t warp_find_field_task(void) {
    uint32_t i;
    for (i = 0; i < TASK_MAX; i++) {
        uint32_t t = psx_mod_read_word(TASK_REGISTRY + i * 4u);
        if (t == 0u) continue;
        if ((int)psx_mod_read_word(t + T_OFF_ID) == FIELD_TASK_FIELD)
            return t;
    }
    return 0u;
}

static int warp_in_field(void) {
    int mode = (int)psx_mod_read_word(GAME_MODE);
    return (mode & 0xFF00) == FIELDSTG_MODE_BASE;
}

/* The field is idle: no menu, event, talk, warp or battle owns the player. */
static int warp_field_idle(void) {
    if ((int)psx_mod_read_word(FIELDSTG_INNOPEN) != 0) return 0;
    if ((int)psx_mod_read_word(FIELDSTG_BUSY)    != 0) return 0;
    if ((int)psx_mod_read_word(FIELDSTG_ACTING)  != 0) return 0;
    if ((int)psx_mod_read_word(FIELDSTG_BATTLE)  != 0) return 0;
    return 1;
}

/*
 * The game-side piece: drive the field task into its leave/close transition
 * exactly as FIELDSTG_leaveFieldAfter() does, so the game's own field code
 * relocates the player.
 */
static void warp_leave_field(uint32_t mode, const char *label) {
    uint32_t task = warp_find_field_task();
    if (task == 0u) {
        fprintf(stderr, "warp-tool: no field task - not in the field; "
                        "nothing to trigger\n");
        return;
    }
    {
        int state    = (int)psx_mod_read_word(task + T_OFF_STATE);
        int substate = (int)psx_mod_read_word(task + T_OFF_SUBSTATE);
        psx_mod_write_word(task + T_OFF_NEXTMODE,   mode);
        psx_mod_write_word(task + T_OFF_NEXTARG,    0u);
        psx_mod_write_word(task + T_OFF_LEAVEDELAY, 0u);
        psx_mod_write_word(task + T_OFF_STATE,      (uint32_t)TASK_DONE);
        psx_mod_write_word(task + T_OFF_SUBSTATE,   0u);
        psx_mod_write_word(WARP_MARKER_ADDR, WARP_MARKER_VALUE);
        fprintf(stderr,
                "warp-tool: field transition -> mode=0x%X (%s) task=0x%08X "
                "state %d->%d substate %d->0 nextMode=0x%X leaveDelay=0\n",
                (unsigned)mode, label ? label : "?", (unsigned)task,
                state, TASK_DONE, substate, (unsigned)mode);
    }
}

static void warp_to_mode(int mode, const char *label) {
    if (mode <= 0) { fprintf(stderr, "warp-tool: no destination selected\n"); return; }
    s_warp_count++;
    fprintf(stderr, "warp-tool: warp #%u -> mode=0x%X (%s)\n",
            s_warp_count, (unsigned)mode, label ? label : "?");
    warp_leave_field((uint32_t)mode, label);
    s_confirm_at = s_frame;
}

static void warp_select(int delta) {
    s_dest_index += delta;
    if (s_dest_index < 0) s_dest_index = DEST_COUNT - 1;
    if (s_dest_index >= DEST_COUNT) s_dest_index = 0;
    fprintf(stderr, "warp-tool: destination %d/%d = 0x%X (%s) [%s]\n",
            s_dest_index + 1, DEST_COUNT, (unsigned)kDests[s_dest_index].mode,
            kDests[s_dest_index].name, kDests[s_dest_index].region);
}



/* Diagnostic: dump the displayed band (RGB555, row-major, little endian) so
 * the composited frame - what the window shows - can be read back as a PNG. */
extern uint16_t *gpu_get_vram_ptr(void);
extern void gl_renderer_sync_cpu(void);
static void ov_dump(const char *prefix, unsigned frame) {
    GpuDisplayInfo di;
    uint16_t *vram;
    FILE *f;
    char path[512];
    int x, y, W, H;
    gpu_get_display_info(&di);
    if (di.disabled) return;
    W = (int)di.width; H = (int)di.height;
    if (W <= 0 || W > 1024) W = 320;
    if (H <= 0 || H > 512) H = 240;
    gl_renderer_sync_cpu();          /* no-op on the software renderer */
    vram = gpu_get_vram_ptr();
    if (!vram) return;
    snprintf(path, sizeof path, "%s_%u.raw", prefix, frame);
    f = fopen(path, "wb");
    if (!f) return;
    for (y = 0; y < H; y++) {
        const uint16_t *row = vram + (size_t)(((int)di.display_y + y) & 511) * 1024;
        for (x = 0; x < W; x++)
            fwrite(row + (((int)di.display_x + x) & 1023), 2, 1, f);
    }
    fclose(f);
}

static void modal_open(void) {
    s_modal_saved_inn = (int)psx_mod_read_word(FIELDSTG_INNOPEN);
    psx_mod_write_word(FIELDSTG_INNOPEN, 1u);   /* freeze the field */
    s_modal = 1;
    s_modal_count++;
    fprintf(stderr,
            "warp-tool: FAST TRAVEL opened (innOpen %d->1, %d destinations) "
            "selected %d/%d = 0x%X (%s)\n",
            s_modal_saved_inn, DEST_COUNT, s_dest_index + 1, DEST_COUNT,
            (unsigned)kDests[s_dest_index].mode, kDests[s_dest_index].name);
}

static void modal_close(const char *why) {
    psx_mod_write_word(FIELDSTG_INNOPEN, (uint32_t)s_modal_saved_inn);
    s_modal = 0;
    s_rep_dir = 0;
    fprintf(stderr, "warp-tool: FAST TRAVEL closed (%s); innOpen restored to %d\n",
            why ? why : "exit", s_modal_saved_inn);
}

/* --- per frame ------------------------------------------------------------ */

static void warp_read_options(void) {
    char buf[32];
    const char *env;
    if (psx_mod_option_value(PKG_ID, FEATURE_ID, "place", buf, sizeof buf)) {
        int v = (int)strtol(buf, NULL, 0);
        int i;
        for (i = 0; i < DEST_COUNT; i++)
            if (kDests[i].mode == v) { s_dest_index = i; break; }
    }
    env = getenv("DW3_WARP_BOOT");
    if (env && *env) s_boot_mode = (int)strtol(env, NULL, 0);
    env = getenv("DW3_WARP_SHOW");
    if (env && *env && env[0] != '0') s_force_show = 1;
    env = getenv("DW3_WARP_MENU");
    if (env && *env && env[0] != '0') s_allow_menu = 1;
    s_shot = getenv("DW3_WARP_SHOT");
    s_diag_path = getenv("DW3_WARP_DIAG");
    env = getenv("DW3_WARP_SHOT_STEP");
    if (env && *env) { s_shot_step = (int)strtol(env, NULL, 0); if (s_shot_step < 1) s_shot_step = 1; }
    fprintf(stderr,
            "warp-tool: active for %s (%s); %d destinations; open with L2+R2 "
            "in the field; boot=%s show=%s menu=%s\n",
            s_reg->name, s_reg->serial, DEST_COUNT,
            s_boot_mode ? "on" : "off",
            s_force_show ? "on" : "off", s_allow_menu ? "on" : "off");
}

#define JUST_PRESSED(p, m) (((s_prev_pad & (m)) != 0) && (((p) & (m)) == 0))
#define IS_DOWN(p, m)      (((p) & (m)) == 0)

/*
 * Region self-test.  EVIDENCE-DRIVEN and LAZY - it never decides at boot.
 *
 * A correct build's TASK_REGISTRY is legitimately EMPTY for the whole front
 * end: main() creates the game's mode/field tasks only once the player is past
 * the title.  A fixed early frame count (an earlier revision judged "empty at
 * frame 3600 == wrong region") therefore rejected a CORRECT build and disabled
 * the mod before the player could ever reach a field.  Measured on the EU disc
 * (staged build, no boot jump): TASK_REGISTRY stays empty from boot through
 * CNTY_SEL (mode 0x1600) and the title (0xE00/0xC00) and only fills at the
 * first field mode (0x20A, frame 5832, 12 live tasks).  Boot-time-empty is
 * NORMAL, not a fault.
 *
 * So the verdict is deferred until there is something to judge - the registry
 * holds live task pointers, which is exactly when the mod could act - and then
 * only a POSITIVE inconsistency fails it: a live entry whose pointer is
 * outside guest RAM, or whose task-header id is not a plausible task id.  A
 * table for the wrong region reads unrelated data at these bases and trips
 * that check, so the mod still disables itself LOUDLY rather than writing
 * through a bad table.  An EMPTY registry is never a verdict: the mod simply
 * keeps waiting (and the warp path independently refuses unless a live task
 * with id == FIELD_TASK_FIELD exists).
 *
 * Residual, stated plainly: there is no region marker in guest RAM to read
 * (see the file header), so a wrong table whose bases happen to read as
 * all-zero is indistinguishable from "not booted yet"; in that case the mod
 * stays inert - it never draws and never writes - instead of shouting.
 */
static void warp_region_validate(void) {
    uint32_t i, live = 0, bad = 0;
    if (s_region_checked || s_disabled) return;
    if (!psx_mod_game_started()) return;
    if ((s_frame % 30u) != 0u) return;   /* the registry cannot fill per-frame */

    for (i = 0; i < TASK_MAX; i++) {
        uint32_t t = psx_mod_read_word(TASK_REGISTRY + i * 4u);
        if (t == 0u) continue;
        live++;
        if (t < 0x80000000u || t >= 0x80200000u) { bad++; continue; }
        if (psx_mod_read_word(t + T_OFF_ID) > 0x40u) bad++;
    }
    if (bad != 0u) {
        s_region_checked = 1;
        s_disabled = 1;
        fprintf(stderr,
                "warp-tool: REGION SELF-TEST FAILED for %s - TASK_REGISTRY "
                "0x%08X holds %u live entries, %u of which are not valid task "
                "pointers/ids for this region. DISABLING the mod: no panel, no "
                "warp writes. Is this build using the wrong region table?\n",
                s_reg->name, (unsigned)TASK_REGISTRY, (unsigned)live,
                (unsigned)bad);
        return;
    }
    if (live == 0u)
        return;   /* normal: the game has not created its tasks yet */

    s_region_checked = 1;
    fprintf(stderr,
            "warp-tool: region OK - %s (GAME 0x%08X mode@+0x%X next@+0x%X, "
            "FIELDSTG_state 0x%08X, TASK_REGISTRY 0x%08X with %u live tasks)\n",
            s_reg->name, (unsigned)GAME_BASE, (unsigned)s_reg->game_off_mode,
            (unsigned)s_reg->game_off_next, (unsigned)FIELDSTG_STATE,
            (unsigned)TASK_REGISTRY, (unsigned)live);
}

static void warp_vblank(void) {
    uint16_t pad;
    int modal_now = 0;
    int in_field, idle;

    if (!psx_mod_game_started()) return;
    s_frame++;
    pad = sio_get_pad_buttons();

    warp_region_validate();
    if (s_disabled) return;

    /* Developer aid: jump into a field stage at boot. */
    if (s_boot_mode != 0 && !s_booted &&
        (int)psx_mod_read_word(GAME_MODE) != 0) {
        s_booted = 1;
        fprintf(stderr, "warp-tool: boot jump -> mode=0x%X (clearing ROOT_TASK)\n",
                (unsigned)s_boot_mode);
        psx_mod_write_word(GAME_NEXTMODE, (uint32_t)s_boot_mode);
        psx_mod_write_word(ROOT_TASK, 0u);
    }

    in_field = warp_in_field();
    idle = in_field && warp_field_idle();

    /* Our modal only lives in the field.  If the mode left the field (a warp,
     * a battle, ...), close it and restore the field's flag. */
    if (s_modal && !in_field) modal_close("left the field");

    if (s_modal) {
        modal_now = 1;
        psx_mod_write_word(FIELDSTG_INNOPEN, 1u);   /* keep the field frozen */

        /* navigation */
        if (JUST_PRESSED(pad, PSX_PAD_UP))   { warp_select(-1); s_rep_dir = -1; s_rep_timer = 0; }
        else if (JUST_PRESSED(pad, PSX_PAD_DOWN)) { warp_select( 1); s_rep_dir =  1; s_rep_timer = 0; }
        else if (IS_DOWN(pad, PSX_PAD_UP) || IS_DOWN(pad, PSX_PAD_DOWN)) {
            if (s_rep_dir == 0) { s_rep_dir = IS_DOWN(pad, PSX_PAD_UP) ? -1 : 1; s_rep_timer = 0; }
            s_rep_timer++;                      /* first repeat after ~0.4s, then ~0.1s */
            if (s_rep_timer >= 24 && (s_rep_timer % 6) == 0) warp_select(s_rep_dir);
        } else { s_rep_dir = 0; s_rep_timer = 0; }

        if (JUST_PRESSED(pad, PSX_PAD_L1)) { int i; for (i=0;i<10;i++) warp_select(-1); }
        if (JUST_PRESSED(pad, PSX_PAD_R1)) { int i; for (i=0;i<10;i++) warp_select( 1); }

        if (JUST_PRESSED(pad, PSX_PAD_TRIANGLE) || JUST_PRESSED(pad, PSX_PAD_START)) {
            modal_close("exit control");
        } else if (JUST_PRESSED(pad, PSX_PAD_CROSS)) {
            int mode = kDests[s_dest_index].mode;
            const char *nm = kDests[s_dest_index].name;
            modal_close("warp");          /* restore innOpen BEFORE the warp */
            warp_to_mode(mode, nm);
        }
    }

    /* Open the screen: L2+R2 together, pressed this vblank, in an idle field
     * that actually has a live FIELD task.  Without id 7 there is nothing the
     * warp could drive, so do not open a modal we cannot act on. */
    if (!s_modal && idle) {
        int both_now  = IS_DOWN(pad, PSX_PAD_L2) && IS_DOWN(pad, PSX_PAD_R2);
        int both_prev = IS_DOWN(s_prev_pad, PSX_PAD_L2) && IS_DOWN(s_prev_pad, PSX_PAD_R2);
        if (both_now && !both_prev && warp_find_field_task() != 0u) modal_open();
    }

    /* legacy dev path (DW3_WARP_MENU=1): a picker drawn while the game's own
     * START menu is open.  OFF by default - it necessarily draws over that
     * menu, which is exactly what the modal exists to avoid. */
    if (!s_modal && s_allow_menu &&
        (int)psx_mod_read_word(FIELDSTG_INNOPEN) == 1) {
        modal_now = 1;
        if (JUST_PRESSED(pad, PSX_PAD_R2)) warp_select(1);
        if (JUST_PRESSED(pad, PSX_PAD_L2)) warp_select(-1);
        if (JUST_PRESSED(pad, PSX_PAD_L1) || JUST_PRESSED(pad, PSX_PAD_CIRCLE))
            warp_to_mode(kDests[s_dest_index].mode, kDests[s_dest_index].name);
    }

    if (s_force_show) modal_now = 1;

    ov_tick(modal_now);

    /* diagnostic frame dump */
    if (s_shot && s_shot_n < 400 && (s_frame % (unsigned)s_shot_step) == 0u) {
        ov_dump(s_shot, s_frame);
        s_shot_n++;
    }

    s_prev_pad = pad;
}

static void warp_activate(void) { warp_read_options(); }

PSX_MOD_CONSTRUCTOR(warp_tool_register) {
    fprintf(stderr, "warp-tool: registering plugins\n");
    psx_mod_register_activation_plugin("dev.warp-tool", warp_activate);
    psx_mod_register_vblank_plugin("dev.warp-tool", warp_vblank);
}
