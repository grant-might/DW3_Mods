# dev.text-speed-2x 1.0.0 - installer contract

This package is a **ZIP whose archive root contains `manifest.toml`**.

## 1. Where the files go

    EXE_DIR/mods/packages/dev.text-speed-2x/1.0.0/manifest.toml
    EXE_DIR/mods/packages/dev.text-speed-2x/1.0.0/plugin/text_speed.c
    EXE_DIR/mods/packages/dev.text-speed-2x/1.0.0/INSTALL.md

## 2. The code step (this mod is a compiled plugin)

`dev.text-speed-2x` is a trusted static plugin (format-5 `[[plugin]]`); the
runtime will not load native code from the package. Link `plugin/text_speed.c`
into the target build:

1. Copy `plugin/text_speed.c` to `<project>/modbuild/mods_src/`
   (USA: `<project>/mods_src/`). One file carries all four multipliers.
2. Ensure the build compiles it into `psx-runtime` with the region define:

       target_sources(psx-runtime PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/mods_src/text_speed.c")
       target_compile_definitions(psx-runtime PRIVATE DW3_GAME_REGION_EU)   # or _US

3. Relink (`cmake --build build --config Release --parallel`) and redeploy the exe.

The plugin prints a registration line at startup and an "active for" line when
the feature is selected, e.g.

    text-speed: 2x active for Europe (SLES-03936) (SLES-03936); patch 0x8001ACD0 := 0x24420002 (2 characters per typewriter tick, exact)

If neither line appears the plugin is not linked in or the feature is off -
which looks exactly like an unmodified game on screen, so check the log first.

## 3. Turning it on / off (the state file)

`EXE_DIR/mods/state.toml`, `format_version = 2`. Enable exactly ONE:

    format_version = 2

    [[package]]
    id = "dev.text-speed-2x"
    version = "1.0.0"

    [[feature]]
    package_id = "dev.text-speed-2x"
    id = "speed"
    enabled = true

`default_enabled = false`, so a missing/empty/malformed state leaves it off.
Enabling two text-speed packages at once makes them fight over the same
instruction (last writer each frame wins) - enable only one.

## 4. WHAT IT CHANGES, PRECISELY

One instruction in `updateTextWindow` - the `addiu $v0,$v0,1` that increments
`TextWindow.visibleEnd` (EU `0x8001ACD0`, USA `0x8001A94C`) - is rewritten to
`addiu $v0,$v0,2`. Everything else is untouched.

Base rate (from the decomp): a tick fires every `typeDelay+1` frames and reveals
one character, so

    talk box / message box : typeDelay 6 -> 1 char / 7 frames
    field area banner      : typeDelay 5 -> 1 char / 6 frames

Patched, each tick reveals 2 characters, so the rate is exactly 2x.
