/*
 * dev.text-speed-{2x,4x} - Digimon World 3 / 2003 faster dialogue text.
 *
 * WHAT IT DOES
 *   The game's typewriter (updateTextWindow, main/text/text_window.c) reveals
 *   the message one character per "tick".  A tick fires when the window's own
 *   frame counter passes its typeDelay:
 *
 *       if (++obj->typeTimer > obj->typeDelay) {
 *           obj->typeTimer = 0;
 *           obj->visibleEnd++;                 <-- one more character
 *           if (obj->typeSound) SOUND.playSound(obj->typeSound);
 *       }
 *
 *   The draw loop shows (visibleEnd - start) characters, so `visibleEnd++`
 *   IS "reveal the next character".  talk boxes and message boxes set
 *   typeDelay = 6 (7 frames per character); the field area banner sets 5
 *   (6 frames per character).
 *
 * HOW IT SPEEDS UP
 *   This mod does NOT shorten the delay (which would only have whole-frame
 *   steps and could not express every multiplier).  It advances MORE THAN ONE CHARACTER
 *   PER TICK, which makes every integer multiplier exact:
 *
 *       original : addiu $v0,$v0,1        (0x24420001)  -> 1 char / tick
 *       Nx       : addiu $v0,$v0,N                       -> N chars / tick
 *
 *   The tick CADENCE is untouched, so prompts, waits for the player, page
 *   breaks, portraits and the typing sound all keep their normal timing; each
 *   tick simply reveals N characters instead of one.  The achieved rate is
 *   therefore exactly N x the base for every integer N (2 and 4 are both
 *   represented exactly; no rounding, no substitute).
 *
 *   The instruction is replaced at runtime with psx_mod_write_code_word()
 *   (mod_plugins.h), the API written for exactly this ("replace one guest
 *   instruction and route that address through the runtime's executable-RAM
 *   path").  Writing the word marks the page executable-dirty; the runtime's
 *   text-divergence guard then refuses the compiled body and runs
 *   updateTextWindow through the dirty-RAM interpreter, which executes the
 *   patched instruction (psxrecomp/runtime/src/memory.c
 *   dirty_ram_text_native_ok_ranges_from + OpenBIOS_dispatch.c
 *   psx_dispatch_impl -> dirty_ram_dispatch).  No other function is affected:
 *   the guard is per emitted code range.
 *
 * REGION
 *   EU and USA are different binaries; the patch address differs.  The BUILD
 *   selects the table (-DDW3_GAME_REGION_EU / _US); a missing define is a
 *   compile error.  Every application re-checks that the live word is the
 *   expected original before writing, so a table that does not match the
 *   running disc is refused instead of corrupting unrelated code.
 *
 * ONE FEATURE PER PACKAGE
 *   Two packages (dev.text-speed-2x and dev.text-speed-4x) each carry their
 *   own plugin id, so the runtime only calls the callbacks of the ENABLED
 *   package.  Enable exactly one at a time; if two are enabled they fight over
 *   the immediate (last writer each frame wins) - documented in each INSTALL.md.
 */

#include "mod_plugins.h"

#include <stdint.h>
#include <stdio.h>

typedef struct TextSpeedRegion {
    const char *name;
    const char *serial;
    uint32_t    patch;   /* address of the `addiu $v0,$v0,1` in updateTextWindow */
} TextSpeedRegion;

static const TextSpeedRegion kRegions[] = {
    /* Europe SLES-03936: updateTextWindow @ 0x8001AC14, range len 0x224;
     * the visibleEnd++ is at 0x8001ACD0. */
    { "Europe (SLES-03936)", "SLES-03936", 0x8001ACD0u },
    /* USA SLUS-01436: updateTextWindow @ 0x8001A890, range len 0x224;
     * the visibleEnd++ is at 0x8001A94C. */
    { "USA (SLUS-01436)",    "SLUS-01436", 0x8001A94Cu },
};

#if defined(DW3_GAME_REGION_US)
#define TS_REGION 1
#elif defined(DW3_GAME_REGION_EU)
#define TS_REGION 0
#else
#error "text_speed.c: define DW3_GAME_REGION_EU or DW3_GAME_REGION_US for this build."
#endif

static const TextSpeedRegion *s_reg = &kRegions[TS_REGION];

#define TS_ORIGINAL_INSN 0x24420001u   /* addiu $v0,$v0,1 (obj->visibleEnd++) */
#define TS_INSN_FOR(n)   (0x24420000u | ((uint32_t)(n) & 0xFFFFu))

/*
 * Apply the multiplier, idempotently, once per frame while the feature is on.
 * - before the EXE image is loaded the word is not the expected original, so
 *   nothing is written (and no false "wrong region" warning);
 * - after a save-state restore reverts the word, the next frame re-applies it;
 * - a word that is neither our value nor the exact original means this table
 *   does not belong to the running image: warn ONCE and stop touching it.
 */
static void ts_ensure(uint32_t mult)
{
    const uint32_t want = TS_INSN_FOR(mult);
    uint32_t cur;

    if (!psx_mod_game_started()) return;

    cur = psx_mod_read_word(s_reg->patch);
    if (cur == want) return;              /* already applied */
    if (cur != TS_ORIGINAL_INSN) {
        static int warned;
        if (!warned) {
            warned = 1;
            fprintf(stderr,
                    "text-speed: %ux: address 0x%08X holds 0x%08X, expected the "
                    "original 0x%08X - refusing to patch (wrong region table for "
                    "this disc?). Text speed left unchanged.\n",
                    (unsigned)mult, (unsigned)s_reg->patch, (unsigned)cur,
                    (unsigned)TS_ORIGINAL_INSN);
        }
        return;
    }
    psx_mod_write_code_word(s_reg->patch, want);
}

#define TS_DEFINE(N)                                                            \
    static void ts_activate_##N(void)                                           \
    {                                                                           \
        fprintf(stderr,                                                         \
                "text-speed: %dx active for %s (%s); patch 0x%08X := 0x%08X "   \
                "(%u characters per typewriter tick, exact)\n",                 \
                (int)(N), s_reg->name, s_reg->serial,                           \
                (unsigned)s_reg->patch, (unsigned)TS_INSN_FOR(N), (int)(N));    \
    }                                                                           \
    static void ts_vblank_##N(void) { ts_ensure((N)); }                         \
    PSX_MOD_CONSTRUCTOR(ts_register_##N)                                        \
    {                                                                           \
        psx_mod_register_activation_plugin("dev.text-speed-" #N "x",            \
                                           ts_activate_##N);                    \
        psx_mod_register_vblank_plugin("dev.text-speed-" #N "x", ts_vblank_##N);\
    }

TS_DEFINE(2)
TS_DEFINE(4)
