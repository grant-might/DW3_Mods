# dev.exp-2x 1.0.0 - installer contract

This package is a **ZIP whose archive root contains `manifest.toml`** - exactly
the container the runtime's own installer accepts
(`ModPackageManager::install_archive`). It extracts to
`<exe dir>/mods/packages/dev.exp-2x/1.0.0/`.

## 1. Files

    EXE_DIR/mods/packages/dev.exp-2x/1.0.0/manifest.toml
    EXE_DIR/mods/packages/dev.exp-2x/1.0.0/plugin/exp_tool.c
    EXE_DIR/mods/packages/dev.exp-2x/1.0.0/INSTALL.md

Only `manifest.toml` is read at runtime; the rest keeps the package
self-contained for the code step.

## 2. The code step (this mod is a compiled plugin)

`dev.exp-2x` is a trusted plugin: native code registered by PSX_MOD_CONSTRUCTOR
inside the runtime executable. The manifest `[[plugin]]` block is only an **id
reference**; the runtime never loads a binary from a package. Installing the ZIP
alone does not create the behaviour - the plugin must be linked in:

1. Copy `plugin/exp_tool.c` to `<project>/modbuild/mods_src/exp_tool.c`
   (USA: `<project>/mods_src/exp_tool.c`).
2. Ensure the build compiles it and selects the region (both regional projects
   already carry this):

       target_sources(psx-runtime PRIVATE "<src>/mods_src/exp_tool.c")
       target_compile_definitions(psx-runtime PRIVATE DW3_GAME_REGION_EU)   # or _US

3. Relink: `cmake --build build --config Release --parallel` (seconds
   incrementally - only `exp_tool.c` and the link are redone).
4. Copy the new executable into the launch directory.

ONE source registers all three plugin ids (`dev.exp-1.2x`, `dev.exp-1.5x`,
`dev.exp-2x`), so one relink serves all three packages; only enabled packages
actually run.

## 3. Enabling it (the state file)

`EXE_DIR/mods/state.toml`, `format_version = 2`:

    format_version = 2

    [[package]]
    id = "dev.exp-2x"
    version = "1.0.0"

    [[feature]]
    package_id = "dev.exp-2x"
    id = "exp2"
    enabled = true

**Enable only ONE** multiplier package. All three declare each other in
`conflicts`, so the launcher refuses a plan with two enabled; if two ever run the
plugin logs a warning and applies only the largest. A missing/empty/malformed
state file leaves the mod OFF (`default_enabled = false`).

## 4. What it changes, and how it was verified

See `plugin/exp_tool.c` for the full rationale. EXP is a 32-bit integer; the
report overlay's reward table (`STFGTREP_rewards[]`, 335 rows,
`{ s32 digimonExp; s32 exp; s32 money; }`) supplies the battle's EXP, and this
mod scales its two exp columns in guest RAM while the report overlay (mode
0x1400) is resident. The scaling is idempotent (each written value is computed
from the mod's own compiled-in copy of the original table, never from the
current content), so it can never compound, and it refuses to act unless the RAM
at the overlay address matches those originals - which doubles as the region
check.

Measured in game (headless, report screen booted with a one-partner victory
payload, no accessory, reward row 1 = 120 EXP):

| build      | multiplier | awarded EXP |
|------------|------------|-------------|
| EU / OFF   | 1x         | 120         |
| EU         | 1.2x       | 144         |
| EU         | 1.5x       | 180         |
| EU         | 2x         | 240         |
| USA        | 1.2x       | 144         |
| USA        | 2x         | 240         |

Dev/test env hooks (no effect on normal play): `DW3_EXP_OFF=1` (disable),
`DW3_EXP_WATCH=1` (log each partner's stored EXP change), `DW3_EXP_PROBE=1`
(periodic state), `DW3_EXP_DUMP=1` (dump the RAM reward table once),
`DW3_EXP_BOOT=<mode>`, `DW3_EXP_REPORT=1` (boot straight to a one-partner report
on reward row 1).
