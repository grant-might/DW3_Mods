# dev.save-anywhere 1.0.0 - installer contract

This package is a **ZIP whose archive root contains `manifest.toml`** - exactly
the container the runtime's own installer accepts
(`ModPackageManager::install_archive`, `psxrecomp/runtime/src/mod_packages.cpp`).
It extracts the archive to `<mods>/packages/<id>/<version>/`.

## 1. Where the files go

    EXE_DIR/mods/packages/dev.save-anywhere/1.0.0/manifest.toml
    EXE_DIR/mods/packages/dev.save-anywhere/1.0.0/plugin/save_tool.c
    EXE_DIR/mods/packages/dev.save-anywhere/1.0.0/INSTALL.md

The runtime only reads `manifest.toml`; the other files make the package
self-contained for the code step below.

## 2. The code step (this mod is a compiled plugin)

`dev.save-anywhere` is a **plugin**: native code registered by a constructor
inside the runtime executable (`PSX_MOD_CONSTRUCTOR` in `plugin/save_tool.c`).
The manifest's `[[plugin]]` block is only an *id reference*; the runtime will
not load a binary from the package. So installing the ZIP alone does not create
the mod's behaviour - the plugin must be **linked into the target build**:

1. Copy `plugin/save_tool.c` to `<project>/modbuild/mods_src/save_tool.c`
   (USA: `<project>/mods_src/save_tool.c`).
2. Ensure the build's `CMakeLists.txt` compiles it into `psx-runtime` with the
   correct region define:

       target_sources(psx-runtime PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/mods_src/save_tool.c")
       target_compile_definitions(psx-runtime PRIVATE DW3_GAME_REGION_EU)   # or _US

3. Relink: `cmake --build build --config Release --parallel` (~seconds
   incrementally - only `save_tool.c` + the final link are redone).
4. Copy the new executable into the launch directory.

Both regional projects already carry steps 1-2, so on those trees step 3 is the
only one needed.

## 3. Turning it on / off (the state file)

`EXE_DIR/mods/state.toml`, `format_version = 2`. The runtime reads it on every
launch and rewrites it canonically after a mod commit. To enable:

    format_version = 2

    [[package]]
    id = "dev.save-anywhere"
    version = "1.0.0"

    [[feature]]
    package_id = "dev.save-anywhere"
    id = "save"
    enabled = true

Set `enabled = false` to switch it off. A missing state file runs every feature
at its manifest default; `default_enabled = false` for this mod, so a missing,
empty or malformed state leaves the mod OFF.

## 4. Using it

In the field, hold **SELECT** and press **SQUARE** (keyboard: hold Right Shift,
press Z). D-pad picks SAVE GAME or CANCEL, **X** (keyboard X) confirms,
**Triangle** (A) or **START** (Enter) exits. Confirming runs the game's OWN
memory-card save screen (mode MODE_CONTINUE 0xC00 with a negative argument);
the game writes the save itself.
