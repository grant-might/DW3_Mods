/*
 * dev.exp-1.2x / dev.exp-1.5x / dev.exp-2x  -  Digimon World 3 / 2003 EXPERIENCE MULTIPLIER.
 *
 * A trusted static plugin (format-5 [[plugin]]; mod_plugins.h) compiled into the
 * runtime. ONE source registers all three plugin ids so one relink serves all
 * three packages; the manifest's [[plugin]] block only selects which id is
 * active, so a package can ship without any loader.
 *
 * WHERE THE GAME AWARDS EXPERIENCE (the award point)
 *   The post-battle report is the overlay STFGTREP (mode MODE_BATTLE_REPORT
 *   = 0x1400).  It takes the battle's reward from the data table
 *
 *       BattleReward STFGTREP_rewards[335]  = { s32 digimonExp; s32 exp; s32 money; }
 *
 *   keyed by BATTLE_RESULT.battle, splits a battle's "exp" among the partners
 *   who fought (1 fighter: full; 2: *6/10; 3: /3), adds a fifth if the partner
 *   wears the exp accessory 0x141 (STFGTREP_boostExp), then hands the result to
 *   STFGTREP_addExp(), which does
 *
 *       stats->exp += exp;   if (stats->exp > 999999) stats->exp = 999999;
 *
 *   and levels the partner while
 *
 *       (level*level*level + level*5 - 6) * digimon->expRate / 10
 *           + STFGTREP_levelExp[tier]   <   stats->exp
 *
 *   (integer arithmetic; STFGTREP_levelExp = {0,50,800,3000} for the level tiers
 *   <5, <20, <40, <100).  A second, separate path (STFGTREP_addDigimonExp via
 *   STFGTREP_getDigimonExp) gives the individual Digimon used an exp that is
 *   HARD-CAPPED at 10 (or 50 past its expLevel), so that column barely moves.
 *
 *   This mod scales the reward AT THE SOURCE - the two exp columns of
 *   STFGTREP_rewards[] while the overlay is resident - so the game's own
 *   split, accessory boost, level-up comparison and the report's own display
 *   (the "EXP" number and the rolling bar) all run on the multiplied value.
 *   Nothing is added after the fact and no arithmetic is re-implemented.
 *
 * WHY THE MULTIPLIER IS EXACT-ENOUGH (see INSTALL.md for the full table)
 *   EXP is an integer and awards are small (real rows: 4 .. 2365, mostly
 *   100..800).  x2 is always exact; x1.5 and x1.2 are not representable for
 *   every award, so the value is multiplied and then divided with ONE explicit
 *   integer rule:
 *
 *       scaled = round(value * num / den)      (round to nearest, halves up)
 *              = (value * num * 2 + den) / (2 * den)      [integer]
 *
 *   Round-to-nearest is chosen over truncation because truncation collapses
 *   x1.2 to +0% on the handful of 4-EXP awards (4*6/5 = 4.8 -> 4) and
 *   under-delivers everywhere, while round-to-nearest gives x1.2 a real change
 *   on all 334 real awards (min +16.7%, mean +19.9%) and is within one EXP of
 *   nominal.  This matters because the owner asked whether x1.2 is honest: it
 *   is, with rounding, and the three factors stay distinct on every single real
 *   battle (1.2x, 1.5x and 2x never produce the same number).
 *
 * REGIONS
 *   Europe (SLES-03936) and USA (SLUS-01436) have different binaries AND
 *   different reward tables (24 rows differ), so the table is compiled per
 *   region (-DDW3_GAME_REGION_EU / _US) and a missing define is a #error.  The
 *   table SHIPPED here doubles as the region check: the mod only scales when the
 *   guest RAM at the overlay address matches these originals (or this mod's own
 *   already-scaled output); otherwise it says so once and does nothing.
 *
 * SAFETY
 *   - Only the report overlay's reward table is touched, and only while the
 *     report mode is up; writing is idempotent (computed from the compiled
 *     originals, never from the current content) so it can never compound.
 *   - No overflow: the largest reward (2365) x2 = 4730, far inside s32, and
 *     addExp already clamps stats->exp at 999999.
 *   - If two of the three packages are enabled at once the mod logs a warning
 *     and applies the largest only; the manifests also declare mutual
 *     `conflicts` so the launcher refuses that plan.
 */

#include "mod_plugins.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

/* ==========================================================================
 * REGION TABLE
 * ======================================================================== */
typedef struct ExpRegion {
    const char *name;
    const char *serial;
    uint32_t game;            /* GAME base                            */
    uint32_t off_mode;        /* GameState.mode offset within GAME    */
    uint32_t rewards;         /* STFGTREP_rewards[] (overlay data)    */
    uint32_t root_task;       /* main.c's ROOT_TASK (dev boot jump)   */
    uint32_t battle_result;   /* BATTLE_RESULT (dev report jump)      */
} ExpRegion;

static const ExpRegion kRegions[] = {
    { "Europe (SLES-03936)", "SLES-03936",
      0x80048D34u, 0x26C4u, 0x80086A88u, 0x8005CCBCu, 0x80042B84u },
    { "USA (SLUS-01436)", "SLUS-01436",
      0x800484E8u, 0x26BCu, 0x80086174u, 0x8005C458u, 0x80042790u },
};
#if defined(DW3_GAME_REGION_US)
#define EXP_REGION_INDEX 1
#elif defined(DW3_GAME_REGION_EU)
#define EXP_REGION_INDEX 0
#else
#error "exp_tool.c: define DW3_GAME_REGION_EU or DW3_GAME_REGION_US for this build (see the region table)."
#endif

static const ExpRegion *s_reg = &kRegions[EXP_REGION_INDEX];

#define GAME_BASE   (s_reg->game)
#define GAME_MODE   (GAME_BASE + s_reg->off_mode)          /* s32 GameState.mode    */
#define GAME_NEXT   (GAME_BASE + s_reg->off_mode + 4u)     /* s32 GameState.nextMode*/
#define GAME_PARTY  (GAME_BASE + 0x0070u)                  /* s32 party[3]          */
#define GAME_EXP(p) (GAME_BASE + 0x0780u + (uint32_t)(p) * 0x3D8u) /* PartnerStats.exp */
#define REWARDS     (s_reg->rewards)
#define ROOT_TASK   (s_reg->root_task)
#define BATTLE_RESULT (s_reg->battle_result)

#define MODE_BATTLE_REPORT 0x1400u
#define TASK_REGISTRY_MAX  100u

/* ==========================================================================
 * THE REWARD TABLE (compiled-in originals; region selected by the build).
 * ======================================================================== */
#define EXP_ROWS 335

#if defined(DW3_GAME_REGION_US)
/* VERSION_US STFGTREP_rewards[]: the digimonExp (col 0) and exp (col 1) of all 335 rows,
   transcribed from the matching decomp (src/stfgtrep/stfgtrep.c, VERSION_US block).
   Index 0 is the all-zero 'no battle' row; money (col 2) is never scaled. */
static const short kOrigDigimonExp[EXP_ROWS] = {
    0, 12, 14, 11, 14, 27, 29, 32, 32, 34, 35, 40, 43, 45, 41, 46,
    43, 47, 46, 46, 47, 48, 49, 55, 57, 50, 52, 52, 53, 56, 99, 53,
    57, 57, 1, 1, 3, 4, 8, 2, 4, 2, 3, 3, 4, 4, 16, 5,
    13, 5, 6, 6, 6, 8, 8, 9, 31, 13, 10, 18, 29, 20, 27, 40,
    24, 20, 12, 23, 20, 20, 22, 44, 45, 22, 22, 25, 29, 23, 23, 24,
    24, 25, 26, 47, 47, 27, 27, 46, 29, 30, 29, 31, 36, 43, 34, 38,
    35, 35, 45, 34, 36, 36, 45, 37, 44, 35, 34, 36, 39, 36, 41, 41,
    41, 41, 41, 43, 46, 43, 49, 43, 43, 44, 44, 44, 43, 43, 44, 44,
    54, 49, 45, 45, 44, 45, 45, 55, 47, 48, 56, 47, 55, 56, 49, 55,
    56, 9, 30, 8, 21, 22, 33, 33, 19, 41, 21, 37, 22, 36, 37, 35,
    47, 42, 46, 48, 46, 31, 39, 43, 43, 44, 40, 43, 45, 32, 40, 48,
    36, 41, 47, 44, 48, 48, 44, 48, 47, 54, 54, 49, 29, 29, 29, 32,
    29, 44, 55, 49, 50, 51, 53, 50, 1, 4, 41, 7, 7, 6, 9, 43,
    6, 7, 10, 10, 10, 40, 17, 9, 41, 38, 38, 38, 40, 40, 41, 42,
    58, 42, 42, 34, 35, 35, 35, 35, 36, 35, 44, 44, 44, 45, 44, 44,
    45, 45, 45, 52, 52, 52, 52, 52, 52, 53, 57, 53, 53, 1, 1, 1,
    1, 1, 1, 1, 1, 1, 1, 10, 17, 26, 28, 29, 28, 28, 28, 19,
    6, 11, 17, 24, 25, 25, 23, 36, 33, 26, 34, 13, 31, 34, 31, 29,
    36, 40, 44, 37, 19, 23, 5, 41, 42, 30, 37, 40, 23, 7, 11, 29,
    43, 40, 42, 45, 50, 12, 14, 32, 32, 34, 40, 44, 45, 46, 47, 55,
    57, 53, 28, 15, 68, 70, 70, 7, 12, 17, 27, 37, 42, 47, 47,
};

static const short kOrigExp[EXP_ROWS] = {
    0, 120, 140, 176, 216, 268, 435, 325, 320, 340, 718, 380, 440, 450, 627, 460,
    649, 470, 705, 703, 715, 719, 737, 550, 570, 757, 788, 783, 795, 842, 990, 530,
    1224, 1700, 6, 5, 17, 19, 39, 10, 20, 11, 16, 15, 21, 22, 80, 27,
    66, 25, 31, 30, 29, 41, 40, 46, 154, 96, 50, 91, 145, 98, 136, 200,
    118, 101, 58, 116, 100, 102, 112, 220, 223, 109, 110, 125, 147, 115, 117, 123,
    120, 124, 129, 235, 234, 135, 134, 233, 145, 152, 146, 155, 225, 215, 168, 189,
    176, 175, 225, 172, 183, 179, 225, 185, 221, 174, 170, 180, 196, 180, 205, 204,
    205, 205, 206, 215, 230, 218, 244, 217, 214, 223, 221, 223, 215, 216, 220, 222,
    273, 247, 225, 224, 222, 226, 227, 276, 235, 243, 280, 235, 277, 282, 246, 277,
    279, 45, 150, 40, 105, 112, 167, 165, 76, 205, 104, 186, 158, 180, 184, 175,
    236, 210, 232, 242, 231, 222, 299, 344, 366, 399, 201, 215, 227, 160, 250, 241,
    179, 203, 235, 221, 240, 239, 220, 243, 236, 271, 272, 245, 291, 299, 451, 160,
    289, 672, 558, 493, 503, 770, 530, 508, 4, 65, 661, 125, 79, 103, 45, 737,
    100, 109, 101, 105, 100, 700, 269, 158, 205, 569, 565, 595, 607, 682, 642, 210,
    904, 641, 638, 342, 524, 533, 357, 523, 361, 544, 665, 664, 656, 454, 671, 669,
    680, 456, 458, 791, 800, 525, 814, 786, 791, 813, 977, 529, 535, 6, 6, 6,
    6, 6, 6, 6, 6, 6, 6, 161, 160, 250, 280, 300, 280, 280, 280, 200,
    63, 173, 255, 243, 379, 375, 240, 538, 336, 394, 520, 204, 468, 339, 475, 445,
    544, 406, 448, 566, 297, 230, 77, 621, 635, 466, 601, 399, 230, 108, 171, 435,
    660, 607, 634, 687, 763, 120, 140, 325, 320, 340, 380, 450, 450, 460, 470, 550,
    570, 530, 144, 153, 4, 4, 4, 35, 60, 85, 135, 185, 210, 235, 235,
};

#else
/* VERSION_EU STFGTREP_rewards[]: the digimonExp (col 0) and exp (col 1) of all 335 rows,
   transcribed from the matching decomp (src/stfgtrep/stfgtrep.c, VERSION_EU block).
   Index 0 is the all-zero 'no battle' row; money (col 2) is never scaled. */
static const short kOrigDigimonExp[EXP_ROWS] = {
    0, 12, 14, 11, 14, 27, 29, 32, 32, 34, 35, 40, 43, 45, 41, 46,
    43, 47, 46, 46, 47, 48, 49, 55, 57, 50, 52, 52, 53, 56, 99, 53,
    57, 57, 1, 1, 3, 4, 8, 2, 4, 2, 3, 3, 4, 4, 16, 5,
    13, 5, 6, 6, 6, 8, 8, 9, 31, 13, 10, 18, 29, 20, 27, 40,
    24, 20, 12, 23, 20, 20, 22, 44, 45, 22, 22, 25, 29, 23, 23, 24,
    24, 25, 26, 47, 47, 27, 27, 46, 29, 30, 29, 31, 36, 43, 34, 38,
    35, 35, 45, 34, 36, 36, 45, 37, 44, 35, 34, 36, 39, 36, 41, 41,
    41, 41, 41, 43, 46, 43, 49, 43, 43, 44, 44, 44, 43, 43, 44, 44,
    54, 49, 45, 45, 44, 45, 45, 55, 47, 48, 56, 47, 55, 56, 49, 55,
    56, 9, 30, 8, 21, 22, 33, 33, 19, 41, 21, 37, 22, 36, 37, 35,
    47, 42, 46, 48, 46, 31, 39, 43, 43, 44, 40, 43, 45, 32, 40, 48,
    36, 41, 47, 44, 48, 48, 44, 48, 47, 54, 54, 49, 29, 29, 29, 32,
    29, 44, 55, 49, 50, 51, 53, 50, 1, 4, 41, 7, 7, 6, 9, 43,
    6, 7, 10, 10, 10, 40, 17, 9, 41, 38, 38, 38, 40, 40, 41, 42,
    58, 42, 42, 34, 35, 35, 35, 35, 36, 35, 44, 44, 44, 45, 44, 44,
    45, 45, 45, 52, 52, 52, 52, 52, 52, 53, 57, 53, 53, 1, 1, 1,
    1, 1, 1, 1, 1, 1, 94, 10, 17, 26, 28, 29, 28, 28, 28, 19,
    6, 43, 43, 44, 44, 45, 23, 36, 33, 26, 34, 13, 31, 34, 31, 29,
    36, 40, 44, 37, 19, 23, 5, 41, 42, 30, 37, 40, 23, 60, 60, 65,
    60, 75, 75, 75, 75, 60, 70, 70, 70, 34, 40, 44, 65, 65, 70, 70,
    75, 75, 28, 15, 68, 70, 70, 7, 12, 17, 27, 37, 42, 47, 47,
};

static const short kOrigExp[EXP_ROWS] = {
    0, 120, 140, 176, 216, 268, 435, 325, 320, 340, 718, 380, 440, 450, 627, 460,
    649, 470, 705, 703, 715, 719, 737, 550, 570, 757, 788, 783, 795, 842, 990, 530,
    1224, 1700, 6, 5, 17, 19, 39, 10, 20, 11, 16, 15, 21, 22, 80, 27,
    66, 25, 31, 30, 29, 41, 40, 46, 154, 96, 50, 91, 145, 98, 136, 200,
    118, 101, 58, 116, 100, 102, 112, 220, 223, 109, 110, 125, 147, 115, 117, 123,
    120, 124, 129, 235, 234, 135, 134, 233, 145, 152, 146, 155, 225, 215, 168, 189,
    176, 175, 225, 172, 183, 179, 225, 185, 221, 174, 170, 180, 196, 180, 205, 204,
    205, 205, 206, 215, 230, 218, 244, 217, 214, 223, 221, 223, 215, 216, 220, 222,
    273, 247, 225, 224, 222, 226, 227, 276, 235, 243, 280, 235, 277, 282, 246, 277,
    279, 45, 150, 40, 105, 112, 167, 165, 76, 205, 104, 186, 158, 180, 184, 175,
    236, 210, 232, 242, 231, 222, 299, 344, 366, 399, 201, 215, 227, 160, 250, 241,
    179, 203, 235, 221, 240, 239, 220, 243, 236, 271, 272, 245, 291, 299, 451, 160,
    289, 672, 558, 493, 503, 770, 530, 508, 4, 65, 661, 125, 79, 103, 45, 737,
    100, 109, 101, 105, 100, 700, 269, 158, 205, 569, 565, 595, 607, 682, 642, 210,
    904, 641, 638, 342, 524, 533, 357, 523, 361, 544, 665, 664, 656, 454, 671, 669,
    680, 456, 458, 791, 800, 525, 814, 786, 791, 813, 977, 529, 535, 6, 6, 6,
    6, 6, 6, 6, 6, 6, 2365, 161, 160, 250, 280, 300, 280, 280, 280, 200,
    63, 215, 216, 223, 221, 225, 240, 538, 336, 394, 520, 204, 468, 339, 475, 445,
    544, 406, 448, 566, 297, 230, 77, 621, 635, 466, 601, 399, 230, 565, 577, 684,
    621, 1855, 1857, 1541, 1503, 600, 700, 700, 320, 340, 380, 450, 650, 650, 700, 700,
    750, 750, 144, 153, 4, 4, 4, 35, 60, 85, 135, 185, 210, 235, 235,
};

#endif

/* ==========================================================================
 * THE MULTIPLIER
 * ======================================================================== */
#define EXP_MULTS 3
static const int  kNum[EXP_MULTS] = { 6, 3, 2 };
static const int  kDen[EXP_MULTS] = { 5, 2, 1 };
static const char *kLabel[EXP_MULTS] = { "1.2x", "1.5x", "2.0x" };

/* multiply then divide, round to nearest with halves up, integer arithmetic
   only.  Equivalent to floor((v * num + den/2) / den) but exact for odd den. */
static int exp_scale(int value, int num, int den) {
    if (value <= 0) return value;
    return (int)(((long long)value * num * 2 + den) / (2LL * den));
}

/* ==========================================================================
 * STATE
 * ======================================================================== */
static int s_req_mask = 0;            /* which multiplier callbacks fired      */
static int s_warned = 0;
static int s_mismatch_logged = 0;
static int s_scaled_logged = 0;
static int s_in_report = 0;

/* dev / test hooks (env; see INSTALL.md) */
static int s_off = 0;                 /* DW3_EXP_OFF=1    : do nothing         */
static int s_watch = 0;               /* DW3_EXP_WATCH=1  : log partner exp    */
static int s_dump = 0;                /* DW3_EXP_DUMP=1   : dump the table once*/
static int s_boot = 0;                /* DW3_EXP_BOOT=<mode>                   */
static int s_booted = 0;
static int s_report = 0;              /* DW3_EXP_REPORT=1 : jump to a report   */
static int s_reported = 0;
static int s_last_exp[8];
static int s_last_init = 0;

/* ==========================================================================
 * TABLE ACCESS
 * ======================================================================== */
static int exp_read_field(uint32_t base, int row, int field) {
    return (int)psx_mod_read_word(base + (uint32_t)row * 12u + (uint32_t)field * 4u);
}

static int exp_active_index(void) {
    int i, idx = 0;
    for (i = 0; i < EXP_MULTS; i++)
        if (s_req_mask & (1 << i)) idx = i;   /* the largest enabled wins */
    return idx;
}

/* The shown/unshown scaler.  Idempotent by construction: every written value is
   computed from the compiled originals, never from the current table content,
   so repeated frames or a cached-then-reloaded overlay can never compound. */
static void exp_apply(int mine) {
    int idx, num, den, row, matched = 0, written = 0;

    if (s_off) return;
    if (!psx_mod_game_started()) return;

    s_req_mask |= (1 << mine);
    idx = exp_active_index();
    num = kNum[idx];
    den = kDen[idx];

    if (!s_warned) {
        int n = ((s_req_mask & 1) ? 1 : 0) + ((s_req_mask & 2) ? 1 : 0) +
                ((s_req_mask & 4) ? 1 : 0);
        if (n > 1)
            fprintf(stderr,
                    "exp-multiplier: WARNING - %d of the three multiplier packages are "
                    "enabled at once; applying only the largest (%s). Enable exactly one.\n",
                    n, kLabel[idx]);
        s_warned = 1;
    }

    /* only the post-battle report overlay owns this table */
    if (((int)psx_mod_read_word(GAME_MODE) & 0xFF00) != (int)MODE_BATTLE_REPORT) {
        s_in_report = 0;
        return;
    }
    s_in_report = 1;

    /* Residency / region check: the table is recognised when every row's two exp
       columns equal our compiled originals (freshly loaded) or this mod's own
       scaled output (already done).  Anything else means the overlay is not
       resident at this address or this is not the table we built for. */
    for (row = 0; row < EXP_ROWS; row++) {
        int ode = kOrigDigimonExp[row], oe = kOrigExp[row];
        int sde = exp_scale(ode, num, den), se = exp_scale(oe, num, den);
        int cde = exp_read_field(REWARDS, row, 0);
        int ce  = exp_read_field(REWARDS, row, 1);
        if ((cde == ode && ce == oe) || (cde == sde && ce == se)) matched++;
    }
    if (matched < EXP_ROWS - 4) {
        if (!s_mismatch_logged) {
            s_mismatch_logged = 1;
            fprintf(stderr,
                    "exp-multiplier: %s reward table NOT recognised at 0x%08X "
                    "(%d/%d rows match) - not scaling. Wrong region build, or the "
                    "STFGTREP overlay is not resident yet.\n",
                    s_reg->name, (unsigned)REWARDS, matched, EXP_ROWS);
        }
        return;
    }
    s_mismatch_logged = 0;

    for (row = 0; row < EXP_ROWS; row++) {
        int sde = exp_scale(kOrigDigimonExp[row], num, den);
        int se  = exp_scale(kOrigExp[row], num, den);
        if (exp_read_field(REWARDS, row, 0) != sde) {
            psx_mod_write_word(REWARDS + (uint32_t)row * 12u + 0u, (uint32_t)sde);
            written++;
        }
        if (exp_read_field(REWARDS, row, 1) != se) {
            psx_mod_write_word(REWARDS + (uint32_t)row * 12u + 4u, (uint32_t)se);
            written++;
        }
    }

    if (written != 0 && !s_scaled_logged) {
        s_scaled_logged = 1;
        fprintf(stderr,
                "exp-multiplier: %s -> scaled STFGTREP_rewards[%d] at 0x%08X (%d fields) "
                "with round(value * %d / %d).\n",
                kLabel[idx], EXP_ROWS, (unsigned)REWARDS, written, num, den);
    }
}

/* Optional verification aid: log every change of a partner's stored EXP, which
   is where the awarded value lands (STFGTREP_addExp: stats->exp += exp). */
static void exp_watch(void) {
    int p;
    if (!s_watch) return;
    for (p = 0; p < 8; p++) {
        int v = (int)psx_mod_read_word(GAME_EXP(p));
        if (!s_last_init) { s_last_exp[p] = v; continue; }
        if (v != s_last_exp[p]) {
            fprintf(stderr, "exp-watch: partner %d stored EXP %d -> %d (awarded %d)\n",
                    p, s_last_exp[p], v, v - s_last_exp[p]);
            s_last_exp[p] = v;
        }
    }
    s_last_init = 1;
}

/* Periodic probe (DW3_EXP_PROBE=1): absolute state, so a stalled report is
   visible rather than silent. */
static int s_probe = 0;
static void exp_probe(void) {
    static unsigned s_pf = 0;
    if (!s_probe) return;
    if ((s_pf++ % 60u) != 0u) return;
    fprintf(stderr,
            "exp-probe: mode 0x%X party %d/%d/%d  p0 lev/exp %d/%d  p1 lev/exp %d/%d  "
            "p2 lev/exp %d/%d  BR battle=%d fought0=%d\n",
            (unsigned)psx_mod_read_word(GAME_MODE),
            (int)psx_mod_read_word(GAME_PARTY + 0u),
            (int)psx_mod_read_word(GAME_PARTY + 4u),
            (int)psx_mod_read_word(GAME_PARTY + 8u),
            (int)psx_mod_read_word(GAME_EXP(0) + 0x1C), (int)psx_mod_read_word(GAME_EXP(0)),
            (int)psx_mod_read_word(GAME_EXP(1) + 0x1C), (int)psx_mod_read_word(GAME_EXP(1)),
            (int)psx_mod_read_word(GAME_EXP(2) + 0x1C), (int)psx_mod_read_word(GAME_EXP(2)),
            (int)psx_mod_read_word(BATTLE_RESULT + 0u),
            (int)psx_mod_read_word(BATTLE_RESULT + 6u) & 0xFF);
}

/* ==========================================================================
 * DEV BOOT HOOKS (headless testing)
 * ======================================================================== */
static void exp_dev_boot(void) {
    static unsigned s_cnt = 0;
    if (!psx_mod_game_started()) return;
    s_cnt++;
    if (s_boot != 0 && !s_booted && (int)psx_mod_read_word(GAME_MODE) != 0) {
        s_booted = 1;
        fprintf(stderr, "exp-multiplier: dev boot jump -> mode 0x%X\n", (unsigned)s_boot);
        psx_mod_write_word(GAME_NEXT, (uint32_t)s_boot);
        psx_mod_write_word(ROOT_TASK, 0u);
    }
    if (s_report && !s_reported && (int)psx_mod_read_word(GAME_MODE) != 0) {
        /* set up a one-partner, no-accessory battle on reward row 1 and request
           the report; repeat until it actually commits (the game may overwrite
           the party during its own start-up). */
        if ((s_cnt % 30u) == 0u) {
            psx_mod_write_word(GAME_PARTY + 0u, 0u);
            psx_mod_write_word(GAME_PARTY + 4u, 0xFFFFFFFFu);
            psx_mod_write_word(GAME_PARTY + 8u, 0xFFFFFFFFu);
            psx_mod_write_word(BATTLE_RESULT + 0u, 1u);          /* battle = 1      */
            psx_mod_write_word(BATTLE_RESULT + 4u, 0u);          /* member = 0      */
            psx_mod_write_word(BATTLE_RESULT + 6u, 0x00000001u); /* partners[0].fought=1, used=0 */
            psx_mod_write_word(GAME_NEXT, (uint32_t)MODE_BATTLE_REPORT);
            psx_mod_write_word(ROOT_TASK, 0u);
        }
        if (((int)psx_mod_read_word(GAME_MODE) & 0xFF00) == (int)MODE_BATTLE_REPORT) {
            s_reported = 1;
            fprintf(stderr, "exp-multiplier: dev report jump ENTERED mode 0x1400\n");
        }
    }
}

static void exp_dump_table(void) {
    static int s_orig_sum = -1;
    int row, sum = 0, matched = 0;
    if (!s_dump) return;
    if (((int)psx_mod_read_word(GAME_MODE) & 0xFF00) != (int)MODE_BATTLE_REPORT) return;
    if (s_orig_sum < 0) {
        for (row = 0; row < EXP_ROWS; row++) s_orig_sum += kOrigExp[row];
    }
    for (row = 0; row < EXP_ROWS; row++) {
        int v = exp_read_field(REWARDS, row, 1);
        sum += v;
        if (v == kOrigExp[row]) matched++;
    }
    fprintf(stderr,
            "exp-multiplier: DUMP 0x%08X: RAM exp-column sum = %d (compiled originals %d), "
            "%d/%d rows equal the originals; row1 d/e/money = %d/%d/%d\n",
            (unsigned)REWARDS, sum, s_orig_sum, matched, EXP_ROWS,
            exp_read_field(REWARDS, 1, 0), exp_read_field(REWARDS, 1, 1),
            exp_read_field(REWARDS, 1, 2));
    s_dump = 0;
}

/* ==========================================================================
 * VBANK WRAPPERS - one per plugin id
 * ======================================================================== */
static void exp_vblank_12(void) { exp_dev_boot(); exp_watch(); exp_probe(); exp_apply(0); exp_dump_table(); }
static void exp_vblank_15(void) { exp_dev_boot(); exp_watch(); exp_probe(); exp_apply(1); exp_dump_table(); }
static void exp_vblank_20(void) { exp_dev_boot(); exp_watch(); exp_probe(); exp_apply(2); exp_dump_table(); }

static void exp_activate(void) {
    const char *env;
    env = getenv("DW3_EXP_OFF");   if (env && *env && env[0] != '0') s_off = 1;
    env = getenv("DW3_EXP_WATCH"); if (env && *env && env[0] != '0') s_watch = 1;
    env = getenv("DW3_EXP_PROBE"); if (env && *env && env[0] != '0') s_probe = 1;
    env = getenv("DW3_EXP_DUMP");  if (env && *env && env[0] != '0') s_dump = 1;
    env = getenv("DW3_EXP_BOOT");  if (env && *env) s_boot = (int)strtol(env, NULL, 0);
    env = getenv("DW3_EXP_REPORT");if (env && *env && env[0] != '0') s_report = 1;
    fprintf(stderr,
            "exp-multiplier: active for %s (%s); packages 1.2x/1.5x/2.0x; report reward "
            "table 0x%08X; off=%d watch=%d\n",
            s_reg->name, s_reg->serial, (unsigned)REWARDS, s_off, s_watch);
}

PSX_MOD_CONSTRUCTOR(exp_multiplier_register) {
    psx_mod_register_activation_plugin("dev.exp-1.2x", exp_activate);
    psx_mod_register_vblank_plugin("dev.exp-1.2x", exp_vblank_12);
    psx_mod_register_activation_plugin("dev.exp-1.5x", exp_activate);
    psx_mod_register_vblank_plugin("dev.exp-1.5x", exp_vblank_15);
    psx_mod_register_activation_plugin("dev.exp-2x", exp_activate);
    psx_mod_register_vblank_plugin("dev.exp-2x", exp_vblank_20);
}
