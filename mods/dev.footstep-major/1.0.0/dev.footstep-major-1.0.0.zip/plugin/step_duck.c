/*
 * dev.footstep-major - Digimon World 3/2003 player
 * footstep volume reduction (statically linked trusted plugin).
 *
 * WHAT THE OWNER ASKED FOR
 *   A package that makes ONLY the player's own footstep sound quieter and
 *   changes nothing else: a 50% reduction ("major footstep reduction mod").
 *   No other sound, no music, no effects.
 *
 * HOW THE FOOTSTEP IS TRIGGERED AND WHAT CONTROLS ITS VOLUME
 *   The footstep is SOUND_PLAYER00 (sound id 0x8004583C) played by
 *   FIELDSTG_playStepSounds() in src/fieldstg/actor_control.c:
 *
 *       SOUND.playSound(SOUND_PLAYER00);            // every 8 frames while
 *                                                   // the player moves
 *
 *   Unpacking that id (include/dw3/sound.h): bit31 = key-on of ONE VAB tone,
 *   bank = 1 (the system/player bank, SOUND_FILES_01, always loaded into SPU
 *   slot 0), program = 0x0B, tone = 0, note = 60.  It is the only sound that
 *   function plays for the player's own character.
 *
 *   The game passes NO volume and NO pan.  playSound() (src/main/sound/
 *   sound.c) hard-codes the key-on path:
 *
 *       SsUtKeyOn(..., fine, SOUND_VOLUME_MAX, SOUND_VOLUME_MAX);
 *
 *   i.e. every key-on sound is mixed at the engine ceiling 0x7F.  The only
 *   thing that can therefore set the footstep's loudness is the volume the
 *   SPU holds for the voice that plays that tone.  Measured on both discs,
 *   the guest writes the footstep voice's L/R volume registers to 0x1D3E and
 *   then keys the voice on, with start-address register 3 = 0x4E80, i.e. SPU
 *   byte address 0x27400 (VAB bank 1 loads to SPU 0x1010 and the footstep's
 *   VAG body sits at offset 0x263F0).  That start address is identical on the
 *   Europe (SLES-03936) and USA (SLUS-01436) discs.
 *
 * WHAT THE PLUGIN DOES
 *   It asks the runtime's own mixer to scale the output of EXACTLY that one
 *   sample.  The mixer hook (spu_set_sample_volume_scale, runtime/src/spu.c)
 *   applies num/den to the L/R volume registers of a voice the instant it is
 *   keyed on WITH THAT START ADDRESS, before any output sample is produced.
 *   That is an exact, linear scale of that voice's contribution to the mix,
 *   applied only to the footstep tone: other voices, other samples, other
 *   registers and the music all keep the volume the game gave them.  Nothing
 *   in the game's own code or data is modified, and with no package enabled
 *   the hook is never armed, so the mixer is byte-for-byte stock.
 *
 *   This package asks for 50/100.
 */

#include "mod_plugins.h"
#include "spu.h"

#include <stdint.h>
#include <stdio.h>
#include <string.h>

#if defined(DW3_GAME_REGION_EU)
#define STEP_DUCK_REGION "Europe (SLES-03936)"
#elif defined(DW3_GAME_REGION_US)
#define STEP_DUCK_REGION "USA (SLUS-01436)"
#else
#error "step_duck.c: define DW3_GAME_REGION_EU or DW3_GAME_REGION_US for this build."
#endif

/* Package / feature / plugin ids, exactly as the manifest declares them. */
#define STEP_MAJOR_PKG "dev.footstep-major"
#define STEP_MAJOR_FEAT "footstep"

/*
 * The player's footstep SFX, as a byte address in SPU RAM.  This is the
 * VAG body's start address for VAB bank 1 / program 0x0B / tone 0, which is
 * what SOUND_PLAYER00 keys on.  Measured on both discs by watching the SPU
 * KEYON ring while the player walks (see INSTALL.md): every 8 frames the
 * guest keys a voice with start register 3 = 0x4E80 -> 0x27400.
 */
#define STEP_DUCK_SPU_ADDR 0x27400u

static void step_major_activate(void) {
    spu_set_sample_volume_scale(STEP_DUCK_SPU_ADDR, 50u, 100u);
    fprintf(stderr,
            "footstep-volume: %s active for %s; footstep SFX %s/%s "
            "(SPU 0x%05X) mixed at 50%% of normal, nothing else touched\n",
            STEP_MAJOR_PKG, STEP_DUCK_REGION, STEP_MAJOR_FEAT, "1.0.0",
            (unsigned)STEP_DUCK_SPU_ADDR);
}

PSX_MOD_CONSTRUCTOR(step_duck_register) {
    fprintf(stderr, "footstep-volume: registering plugins\n");
    psx_mod_register_activation_plugin(STEP_MAJOR_PKG, step_major_activate);
}
