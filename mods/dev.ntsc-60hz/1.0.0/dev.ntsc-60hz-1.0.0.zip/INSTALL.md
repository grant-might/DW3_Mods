# dev.ntsc-60hz - 60 Hz / NTSC patch for the European recomp (SLES-03936)

What the standard PAL to NTSC disc conversion does to the retail EXE, mapped onto the
recompiled build and implemented the simple way.

## The mapping (PAL to NTSC conversion to decomp symbols)

The standard PAL to NTSC conversion flips
two bytes in the PAL executable `SLES_039.36`:

| file offset | patch        | what it is |
|---|---|---|
| `0x4D4AC` | `00 -> 01` | `NTSC_MODE` |
| `0x4D4B0` | `01 -> 00` | `SHIFT_PAL_SCREEN` |

It also swaps the disc's `license_data.dat` for the NTSC one - **disc-level and
irrelevant to the recomp**: the runtime does not revalidate a mounted image's
licence region, and it never touches the game's own files. Not implemented.

A PS-X EXE loads its image at `0x80010000` after the 2048-byte header, so on
this disc `vaddr = 0x80010000 + (file − 0x800)`:

| file | -> guest | symbol (`config/eu/symbols.txt`) | retail value |
|---|---|---|---|
| `0x4D4AC` | `0x8005CCAC` | `NTSC_MODE` | `0` (PAL 50 Hz) |
| `0x4D4B0` | `0x8005CCB0` | `SHIFT_PAL_SCREEN` | `1` (offset on) |

They are **initial values of small-data variables**, not code: the region from
`0x4D350` (`0x8005CB50` = `HEAP_START`) is the `.sdata` block a structural pass
re-typed `.data -> .sdata`, and `src/main/data/game_3.c` contains exactly:

```c
s32 NTSC_MODE = 0;
s32 SHIFT_PAL_SCREEN = 1;
```

So the conversion simply changes two C initialisers. Everything else the
patch does is derived from them:

* `NTSC_MODE` (`src/main/gfx/display.c`, `main.c`, `fieldstg/actor.c`, `sound.c`)
  * `main()`: `SetVideoMode(MODE_NTSC)` instead of `MODE_PAL`
  * `vsyncCallback` / `drawFrame`: time counters step `0x100` (60 Hz) not `0x133`
  * `FIELDSTG_createActor`: `actor->speed = 0x400` not `0x4CC`
  * flight cap `0x200` (`FLIGHT_SPEED_MAX`) not `0x266` (`..._PAL`)
  * `SsSetTickMode(SS_NOTICK)` not `| 50`; fade decrescendo `0x3C` not `0x32`
* `SHIFT_PAL_SCREEN` (`src/main/gfx/display.c`, `cardgame_*.c`)
  * `setDisplayMode`: `GFX.disp[0/1].screen.y = 0x18` (24 lines down) when nonzero
  * card-game layout tables (PAL- vs NTSC-relative)

## Recommended form - data-only `[[patch]]` (no relink)

Copy `package/dev.ntsc-60hz/1.0.0/manifest.toml` to
`<exe_dir>/mods/packages/dev.ntsc-60hz/1.0.0/` (or unzip
`dist/dev.ntsc-60hz-1.0.0.zip` there - its `manifest.toml` is at the ZIP root,
as `ModPackageManager::install_archive` requires), then enable it in
`mods/state.toml`:

```toml
[[package]]
id = "dev.ntsc-60hz"
version = "1.0.0"

[[feature]]
package_id = "dev.ntsc-60hz"
id = "ntsc"
enabled = true
```

No plugin, no source change, no relink. The runtime applies the two words with
an expected-byte guard the first time the guest dispatches the game entry point
(`mod_runtime_on_dispatch`), i.e. after the data image is loaded and before
`main()`. It also re-applies them after a savestate/rewind restore.

## Alternative form - trusted plugin (needs a relink)

`mods_src/ntsc_tool.c` is the same change as a statically linked plugin
(`dev.ntsc-60hz`). Integration lines (delivered, **not** applied to the shared
`modbuild`):

Build wiring - add next to the existing `dev.warp-tool` / `dev.save-anywhere`
entries in `modbuild/CMakeLists.txt` (or use the sibling tree `ntscmod/`):

```cmake
target_sources(psx-runtime PRIVATE
  "${CMAKE_CURRENT_SOURCE_DIR}/mods_src/ntsc_tool.c")
target_compile_definitions(psx-runtime PRIVATE DW3_GAME_REGION_EU)
```

Package - copy `package-plugin/dev.ntsc-60hz/1.0.0/manifest.toml` under
`<exe_dir>/mods/packages/dev.ntsc-60hz/1.0.0/` and enable the same `state.toml`
block above. **The plugin id is not loaded from the package**; unlinking it
makes the runtime refuse to launch (`trusted plugin is unavailable:
dev.ntsc-60hz`).

Prebuilt binary from this isolated tree:
`ntscmod/build/Digimon_World_2003_Recompiled.exe` (EU, debug-tools ON, only
`ntsc_tool.c` added).

## What "60 Hz" means here - verified, honestly

The runtime's frame pacer is a host-side constant
(`PSX_FRAME_PERIOD_MS = 1000.0/59.94`, `runtime/src/main.cpp`); it is **not**
derived from `NTSC_MODE`/`SetVideoMode`. So the patch does **not** change the
refresh rate - the emulated PS1 is already paced at ~59.94 Hz either way. What
it changes is the game's own logic, all of which the PAL image tuned for 50 Hz:

1. **The game clock runs ~20 % fast in the un-patched EU build.** `vsyncCallback`
   adds `0x133` per vblank in PAL mode (a 60/50 compensation for 50 Hz), so at a
   ~60 Hz vblank cadence the 8.8 counters advance `0x133/0x100 = 1.199x` too
   fast; NTSC-mode `0x100` is correct.
2. **Actor / flight speeds are ~20 % fast** for the same reason (`0x4CC` per
   frame, `0x266` cap).
3. **A 24-line down-shift** (`GFX.disp[].screen.y = 0x18`) that NTSC does not have.

### Evidence (EU build, `PSX_HEADLESS=1`, TCP debug server, one request per connection)

Time-counter step is measured as Δ`GFX.frameCounter` / (256 · Δ`vblank_rate.delivered`)
- exact per-vblank arithmetic, immune to the headless frame rate.

| | `NTSC_MODE` | `SHIFT_PAL_SCREEN` | `GFX.disp0.screen.y` | clock step | `GPUSTAT` bit 20 |
|---|---|---|---|---|---|
| mod **off** (retail) | `00 00 00 00` | `01 00 00 00` | `24` | **1.1992** | `1` (PAL) |
| `[[patch]]` **on** | `01 00 00 00` | `00 00 00 00` | `0` | **0.9988** | `0` (NTSC) |
| plugin **on** | `01 00 00 00` | `00 00 00 00` | `0` | **1.0014** | `0` (NTSC) |

`gpu_state` corroborates: `v_display [43,283] -> [16,256]`, `h_display [624,3184] -> [600,3160]`
(PAL vs NTSC display ranges). A 36 s soak with the patch active reaches game mode
`0x1600` (CNTY_SEL) and holds `NTSC_MODE=1 SHIFT=0 disp0.y=0` with no crash.

**Late-write control (why boot-time matters for the offset).** Booting retail and
then poking both values once the game is running (what a plugin can only do after
its first vblank) flips the clock `1.1992 -> 0.9943` but leaves `disp0.y = 24` -
`setDisplayMode` already ran. Both delivered forms write before `main()`, so both
get `disp.y = 0`; a plugin that started mid-session would not (the tested plugin
starts at power-on, so it is fine).

### Not exercised

* **Windowed/GL present path** - all tests are headless (`gr_backend()` still
  reports OpenGL there but the presenter is not run). A human should confirm the
  picture on a real window: no 24-line letterbox shift, and NTSC-speed movement.
* **Post-title gameplay** - verification reaches CNTY_SEL (mode `0x1600`);
  in-field actor/flight speeds are asserted from the decomp source, not played.
* **Audio tick** (`SsSetTickMode`) - set once in `SOUND.init()`; the flags are
  proven correct before `main()`, but the resulting music tempo was not listened to.
* The USA build is NTSC already and has neither flag; the package targets
  `SLES-03936` only.
